--!strict
local InvulRuntime=require(script.Parent:WaitForChild("EGGRUMBLE_InvulRuntime"))
-- EGGRUMBLE V3: seven role-specific A/B/C skills in THE SAME castle/egg/horde match.
-- Studio-only isolated gameplay scaffold; NOT final animations/art, RC, PvP, mobile QA.
-- WARRIOR etc internal IDs remain stable. 3 server-owned cooldown Tools per role.
local RunService=game:GetService("RunService")
local Debris=game:GetService("Debris")
local CombatBalance=require(script.Parent:WaitForChild("EGGRUMBLE_CombatBalance"))
local SkillFX=require(script.Parent:WaitForChild("EGGRUMBLE_SkillFX"))
local ImpactFeedback=require(script.Parent:WaitForChild("EGGRUMBLE_ImpactFeedback"))
local WeaponSilhouettes=require(script.Parent:WaitForChild("EGGRUMBLE_WeaponSilhouettes"))
local DivineMantle=require(script.Parent:WaitForChild("EGGRUMBLE_DivineMantle"))
local AttackGeometry=require(script.Parent:WaitForChild("EGGRUMBLE_AttackGeometry"))
local StatusTickFence=require(script.Parent:WaitForChild("EGGRUMBLE_StatusTickFence"))
local HeroCombat={}
local ZombieCommander=(function()
-- GQ-ZOMBIE-COMMAND: server-side, deterministic orders; no Remote/HP/reward authority.
-- Pure policy is usable in native Luau. Only the existing combat author may apply hits.
local Policy = {}

local LIMIT = 3
local LIFETIME = 14
local MELEE_RANGE = 5
local ACQUIRE_RANGE = 48
local GUARD_LEASH = 12 -- castle-defense order must not attack while outside its local perimeter
local HIT_COOLDOWN = 1.5
local SQUAD_COOLDOWN = 0.4

local VALID = { FOLLOW = true, GUARD = true, FOCUS = true }
local ENEMY = { ENEMY_PLAYER = true, ENEMY_BOT = true, NEUTRAL = true }

local function distance(a, b)
    local dx, dz = a.x - b.x, a.z - b.z
    return math.sqrt(dx * dx + dz * dz)
end

local function eligible(target, matchToken)
    return target ~= nil
        and target.active == true
        and target.matchToken == matchToken
        and target.friendly ~= true
        and ENEMY[target.kind] == true
        and type(target.id) == "string"
        and type(target.x) == "number"
        and type(target.z) == "number"
end

function Policy.new(matchToken, ownerId, startedAt)
    assert(type(matchToken) == "string" and #matchToken > 0, "match token required")
    assert(type(ownerId) == "string" and #ownerId > 0, "owner id required")
    assert(type(startedAt) == "number", "server time required")
    return {
        matchToken = matchToken,
        ownerId = ownerId,
        startedAt = startedAt,
        active = true,
        order = "FOLLOW",
        focusId = nil,
        units = {},
        count = 0,
        lastSquadHit = -math.huge,
    }
end

function Policy.enlist(state, unitId, now, position)
    if not state.active or now - state.startedAt >= LIFETIME
        or state.count >= LIMIT or state.units[unitId] ~= nil then
        return false
    end
    if type(unitId) ~= "string" or #unitId == 0 then return false end
    state.units[unitId] = {
        x = position.x, z = position.z,
        lastHit = -math.huge,
        expiresAt = math.min(state.startedAt + LIFETIME, now + LIFETIME),
    }
    state.count += 1
    return true
end

function Policy.issue(state, order, focusId)
    if not state.active or not VALID[order] then return false end
    if order == "FOCUS" and (type(focusId) ~= "string" or focusId == "") then
        return false
    end
    state.order = order
    state.focusId = if order == "FOCUS" then focusId else nil
    return true
end

function Policy.retire(state)
    state.active = false
    state.units = {}
    state.count = 0
    state.focusId = nil
end

function Policy.locate(state, unitId, position)
    local unit = state.units[unitId]
    if not unit then return false end
    unit.x, unit.z = position.x, position.z
    return true
end

local function selectTarget(state, unit, snapshot)
    local best = nil
    local guardAnchor = if state.order == "GUARD" then (snapshot.guardPoint or snapshot.ownerPosition) else nil
    local bestDistance = ACQUIRE_RANGE
    for _, candidate in ipairs(snapshot.targets or {}) do
        if eligible(candidate, state.matchToken)
            and (state.order ~= "GUARD" or (guardAnchor ~= nil and distance(candidate, guardAnchor) <= GUARD_LEASH)) then
            local d = distance(unit, candidate)
            if d <= ACQUIRE_RANGE then
                if state.order == "FOCUS" then
                    if candidate.id == state.focusId then return candidate, d end
                elseif d < bestDistance then
                    best, bestDistance = candidate, d
                end
            end
        end
    end
    return best, bestDistance
end

-- snapshot is server-trusted only. Targets must be filtered for session/team/life.
-- Returns movement requests or ATTACK permits, never directly changes HP/rewards.
function Policy.step(state, now, snapshot)
    if not state.active then return {} end
    if snapshot.matchToken ~= state.matchToken or snapshot.phase ~= "ACTIVE"
        or snapshot.ownerAlive ~= true or snapshot.ownerId ~= state.ownerId
        or now >= state.startedAt + LIFETIME then
        Policy.retire(state)
        return {}
    end
    local actions = {}
    for unitId, unit in pairs(state.units) do
        if now >= unit.expiresAt then
            state.units[unitId] = nil
            state.count -= 1
            table.insert(actions, { kind = "DESPAWN", unitId = unitId })
        else
            -- Returning defenders never stall outside their castle chasing / hitting roadside enemies.
            local guardAnchor = if state.order == "GUARD" then (snapshot.guardPoint or snapshot.ownerPosition) else nil
            if guardAnchor and distance(unit, guardAnchor) > GUARD_LEASH then
                table.insert(actions, { kind = "MOVE", unitId = unitId,
                    x = guardAnchor.x, z = guardAnchor.z })
            else
            local target, d = selectTarget(state, unit, snapshot)
            if target and d <= MELEE_RANGE then
                local canSee = snapshot.visible ~= nil
                    and snapshot.visible(unit.x, unit.z, target.x, target.z) == true
                if canSee and now - unit.lastHit >= HIT_COOLDOWN
                    and now - state.lastSquadHit >= SQUAD_COOLDOWN then
                    unit.lastHit, state.lastSquadHit = now, now
                    table.insert(actions, {
                        kind = "ATTACK", unitId = unitId, targetId = target.id,
                        matchToken = state.matchToken, damage = 6,
                    })
                end
            else
                local waypoint = nil
                if state.order == "GUARD" then waypoint = guardAnchor
                elseif target then waypoint = { x = target.x, z = target.z }
                else waypoint = snapshot.ownerPosition end
                if waypoint then
                    table.insert(actions, {
                        kind = "MOVE", unitId = unitId,
                        x = waypoint.x, z = waypoint.z,
                    })
                end
            end
            end -- guard-return fence
        end
    end
    return actions
end

Policy.MAX_UNITS = LIMIT
Policy.TTL_SECONDS = LIFETIME
Policy.HIT_COOLDOWN_SECONDS = HIT_COOLDOWN
Policy.GUARD_LEASH_STUDS = GUARD_LEASH

-- PRIVATE CANDIDATE ONLY: opt-in server adapter for the existing ZOMBIE role Skill C.
-- Never installs another Game, Combat, Damage, Remote, Store, or SCORE authority.
-- The existing Combat author must call begin() and provide its authoritative hit().
local Runtime = {}
local active = setmetatable({}, { __mode = "k" })

local function buildMinion(parent: Instance, position: Vector3, name: string): (Model, Humanoid, BasePart)
    local model = Instance.new("Model")
    model.Name = name
    local root = Instance.new("Part")
    root.Name = "HumanoidRootPart"
    root.Size = Vector3.new(2.4, 3.4, 2)
    root.Color = Color3.fromRGB(106, 165, 133)
    root.Material = Enum.Material.SmoothPlastic
    root.CanCollide = true
    root.CFrame = CFrame.new(position + Vector3.new(0, 2, 0))
    root.Parent = model
    local head = Instance.new("Part")
    head.Name = "Head"
    head.Shape = Enum.PartType.Ball
    head.Size = Vector3.new(2, 2, 2)
    head.Color = Color3.fromRGB(174, 194, 151)
    head.CanCollide = false
    head.CFrame = root.CFrame * CFrame.new(0, 2.5, 0)
    head.Parent = model
    local weld = Instance.new("WeldConstraint")
    weld.Part0 = root
    weld.Part1 = head
    weld.Parent = root
    local humanoid = Instance.new("Humanoid")
    humanoid.WalkSpeed = 14
    humanoid.MaxHealth = 20
    humanoid.Health = 20
    humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
    humanoid.Parent = model
    model.PrimaryPart = root
    model.Parent = parent
    -- Server owns movement; never grant client network ownership.
    pcall(function() root:SetNetworkOwner(nil) end)
    return model, humanoid, root
end

-- opts: matchToken, ownerId, world, snapshot(player), hit(player,targetId,damage,token)
-- The hit callback MUST revalidate current-mode membership, LOS, HP and reward owner.
function Runtime.begin(player: Player, opts: any): (boolean, string?)
    assert(RunService:IsServer(), "zombie commander is server-only")
    assert(type(opts) == "table" and type(opts.matchToken) == "string")
    assert(type(opts.snapshot) == "function" and type(opts.hit) == "function")
    if active[player] then Runtime.stop(player) end
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart") :: BasePart?
    if not root or not opts.world or not opts.world.Parent then return false, "NO_WORLD_OR_AVATAR" end
    local epoch = tostring(opts.matchToken)
    local ownerId = tostring(opts.ownerId or player.UserId)
    local policy = Policy.new(epoch, ownerId, os.clock())
    local units: {[string]: {model:Model, humanoid:Humanoid, root:BasePart}} = {}
    local folder = Instance.new("Folder")
    folder.Name = "EGGRUMBLE_ZombieServants_" .. tostring(player.UserId)
    folder.Parent = opts.world
    local connection: RBXScriptConnection? = nil
    local ended = false
    local function stop()
        if ended then return end
        ended = true
        Policy.retire(policy)
        if connection then connection:Disconnect() end
        folder:Destroy()
        if active[player] and active[player].stop == stop then active[player] = nil end
    end
    for i = 1, Policy.MAX_UNITS do
        local position = root.Position + Vector3.new((i-2)*3.2, 0, -4)
        local id = tostring(player.UserId) .. "-z" .. tostring(i)
        local model, hum, part = buildMinion(folder, position, "SummonedZombie_" .. tostring(i))
        units[id] = { model = model, humanoid = hum, root = part }
        assert(Policy.enlist(policy, id, os.clock(), { x=part.Position.X, z=part.Position.Z }))
    end
    active[player] = { stop = stop, policy = policy }
    local elapsed = 0
    connection = RunService.Heartbeat:Connect(function(dt)
        elapsed += dt
        if elapsed < 0.25 then return end
        elapsed = 0
        if ended or player.Character ~= character or not player.Parent then stop(); return end
        local ok, snapshot = pcall(opts.snapshot, player)
        if not ok or type(snapshot) ~= "table" then stop(); return end
        for id, data in pairs(units) do
            if data.model.Parent and data.root.Parent and data.humanoid.Health > 0 then
                Policy.locate(policy, id, { x=data.root.Position.X, z=data.root.Position.Z })
            else
                stop(); return
            end
        end
        local actions = Policy.step(policy, os.clock(), snapshot)
        if not policy.active then stop(); return end
        for _, action in ipairs(actions) do
            local data = units[action.unitId]
            if data and data.model.Parent then
                if action.kind == "MOVE" then
                    -- MoveTo uses Roblox collision/path blockers; no wall teleport.
                    data.humanoid:MoveTo(Vector3.new(action.x, data.root.Position.Y, action.z))
                elseif action.kind == "ATTACK" then
                    -- The single original server Combat authority decides actual damage/credit.
                    local authorized = pcall(opts.hit, player, action.targetId, action.damage, epoch, data.root)
                    if not authorized then stop(); return end
                elseif action.kind == "DESPAWN" then
                    data.model:Destroy()
                    units[action.unitId] = nil
                end
            end
        end
    end)
    return true, nil
end

function Runtime.order(player: Player, order: string, focusId: string?): boolean
    local state = active[player]
    if not state then return false end
    -- Caller must be the server authority, not a raw client Remote argument.
    return Policy.issue(state.policy, order, focusId)
end

function Runtime.stop(player: Player)
    local state = active[player]
    if state then state.stop() end
end


return Runtime
end)()
local ORDER={"WARRIOR","MAGE","NINJA","TRAPPER","BUILDER","BEAST","ZOMBIE"}
local JOBS={
 WARRIOR={name="武神",color=Color3.fromRGB(235,105,66),weapon="神太刀",skills={"飛翔斬撃","槍陣突撃","神憑き"}},
 MAGE={name="魔法使い",color=Color3.fromRGB(80,155,240),weapon="魔導杖",skills={"氷弾","爆炎陣","雷光治癒"}},
 NINJA={name="暗殺者",color=Color3.fromRGB(114,112,172),weapon="双刃",skills={"瞬影斬","風走り","千刃旋風"}},
 TRAPPER={name="超能力者",color=Color3.fromRGB(193,101,244),weapon="念動球",skills={"念動衝撃","重力牢獄","空間転移"}},
 BUILDER={name="マッドサイエンティスト",color=Color3.fromRGB(62,218,186),weapon="未来銃",skills={"電磁射撃","多弾ロケット","自動砲塔"}},
 BEAST={name="魔獣使い",color=Color3.fromRGB(243,173,66),weapon="獣笛",skills={"獣牙撃","巨獣餌","分裂餌"}},
 ZOMBIE={name="呪術師",color=Color3.fromRGB(164,78,164),weapon="呪印杖",skills={"呪印波動","疫病霧","不死軍団"}},
}
local lastByPlayer:{[number]:{[string]:number}}={}
local castSequence:{[number]:number}={}
local function makeEffect(parent:Instance,at:Vector3,size:Vector3,color:Color3,lifetime:number):Part
 local p=Instance.new("Part")
 p.Name="ClassSkillVFX";p.Shape=Enum.PartType.Ball;p.Anchored=true
 p.CanCollide=false;p.CanTouch=false;p.CanQuery=false;p.Material=Enum.Material.Neon
 p.Transparency=.5;p.Size=size;p.Color=color;p.Position=at;p.Parent=parent
 Debris:AddItem(p,lifetime)
 return p
end
local function characterOf(p:Player):(Model?,BasePart?,Humanoid?)
 local c=p.Character
 if not c then return nil,nil,nil end
 local r=c:FindFirstChild("HumanoidRootPart")::BasePart?
 local h=c:FindFirstChildOfClass("Humanoid")
 if not r or not h or h.Health<=0 then return nil,nil,nil end
 return c,r,h
end
local function rootAdvance(root:BasePart,dist:number):Vector3
 return root.Position+root.CFrame.LookVector*dist
end
local function lineClear(source:Vector3,to:Vector3,first:Model,second:Model):boolean
 local delta=to-source
 if delta.Magnitude<.01 then return true end
 local ray=RaycastParams.new();ray.FilterType=Enum.RaycastFilterType.Exclude
 ray.FilterDescendantsInstances={first,second};ray.RespectCanCollide=true
 return workspace:Raycast(source,delta,ray)==nil
end
local function hitBotHeroes(session:any,player:Player,root:BasePart,char:Model,center:Vector3,range:number,damage:number,shape:string):number
 local state=session.rules.castles[tostring(player.UserId)]
 if not state or not state.alive then return 0 end
 local count=0
 for id,enemy in pairs(session.botActors or {}) do
  local target=session.rules.castles[id]
  local er=enemy and enemy.PrimaryPart
  local h=enemy and enemy:FindFirstChildOfClass("Humanoid")
  if target and target.alive and (session.mode~="TEAM" or target.team~=state.team)
   and er and h and h.Health>0
   and AttackGeometry.allowed(root.Position,center,er.Position,range,shape)
   and (er.Position-root.Position).Magnitude<=36
   and count<5 and lineClear(root.Position+Vector3.new(0,1.5,0),er.Position,char,enemy) then
   -- War God has a deliberate single-target duelist edge against a lone opponent.
   local loneEnemy=true
   for otherId,other in pairs(session.botActors or {}) do
    if otherId~=id and other.PrimaryPart then
     local otherState=session.rules.castles[otherId]
     if otherState and otherState.alive
      and (session.mode~="TEAM" or otherState.team~=state.team)
      and (other.PrimaryPart.Position-root.Position).Magnitude<22 then
      loneEnemy=false;break
     end
    end
   end
   local duel=if player:GetAttribute("EGGRUMBLE_Role")=="WARRIOR" and loneEnemy then 1.25 else 1
   local mark=if (h:GetAttribute("EGGRUMBLE_MarkedUntil") or 0)>os.clock() then 1.15 else 1
   h:TakeDamage(InvulRuntime.filterDamage(h,damage*duel*mark,"PLAYER",p.UserId))
   ImpactFeedback.hit(enemy,player:GetAttribute("EGGRUMBLE_Role") or "WARRIOR")
   count+=1
  end
 end
 return count
end
-- NINJA stealth stops human targeting as it already stops bots; carrying a real
-- egg always reveals the player. This function never trusts client attributes
-- for egg ownership: caller passes server-owned castle state.
local function humanCombatTargetable(castle:any,player:Player):boolean
 return castle.heldEggs>0 or os.clock()>=(player:GetAttribute("EGGRUMBLE_StealthUntil") or 0)
end
-- #531 is the *only* host-side session-membership authority. Fail closed
-- if the prerequisite callback is absent, invalid, or throws.
local function currentHumanMember(session:any,player:Player):boolean
 if not session or not player then return false end
 local verify=session.isCurrentHuman
 if type(verify)~="function" then return false end
 local ok,allowed=pcall(verify,player)
 return ok and allowed==true
end
local function hitHumanHeroes(session:any,p:Player,root:BasePart,char:Model,center:Vector3,range:number,damage:number,shape:string):number
 local state=session.rules.castles[tostring(p.UserId)]
 if not state or not state.alive then return 0 end
 local count=0
 for _,enemyPlayer in ipairs(game:GetService("Players"):GetPlayers()) do
  local enemyState=session.rules.castles[tostring(enemyPlayer.UserId)]
  local enemyChar,enemyRoot,enemyHum=characterOf(enemyPlayer)
  if enemyPlayer~=p and enemyState and enemyState.alive
   and currentHumanMember(session,enemyPlayer)
   and humanCombatTargetable(enemyState,enemyPlayer)
   and (session.mode~="TEAM" or enemyState.team~=state.team)
   and enemyChar and enemyRoot and enemyHum and enemyHum.Health>0
   and AttackGeometry.allowed(root.Position,center,enemyRoot.Position,range,shape)
   and (enemyRoot.Position-root.Position).Magnitude<=36
   and count<4 and lineClear(root.Position+Vector3.new(0,1.5,0),
    enemyRoot.Position+Vector3.new(0,1,0),char,enemyChar) then
   -- In real PvP, attacking the living opposing hero inflicts actual Humanoid damage;
   -- castle death and hero knockout remain separate match states.
   local duel=if p:GetAttribute("EGGRUMBLE_Role")=="WARRIOR"
    and (enemyRoot.Position-root.Position).Magnitude<=18 then 1.25 else 1
   local mark=if (enemyHum:GetAttribute("EGGRUMBLE_MarkedUntil") or 0)>os.clock() then 1.15 else 1
   local musou=if session.swarm and session.swarm.musouMultiplier then session.swarm.musouMultiplier(p,"HUMAN") else 1
    enemyHum:TakeDamage(InvulRuntime.filterDamage(enemyHum,damage*duel*mark*musou,"PLAYER",p.UserId))
   ImpactFeedback.hit(enemyChar,p:GetAttribute("EGGRUMBLE_Role") or "WARRIOR")
   count+=1
  end
 end
 return count
end
local function neutralAndBotHit(session:any,p:Player,root:BasePart,char:Model,at:Vector3,range:number,damage:number,c:Color3,shape:string):number
 -- Both hit APIs are SERVER-owned; neutral KO credit only comes from Humanoid.Died.
 local count=0
 if session.swarm then count+=session.swarm.damageFromPlayer(p,at,range,damage,shape) end
 count+=hitBotHeroes(session,p,root,char,at,range,damage,shape)
 if session.guardians then count+=session.guardians.damageFromPlayer(p,at,range,damage,shape) end
 count+=hitHumanHeroes(session,p,root,char,at,range,damage,shape)
 -- Unique visual feedback is produced by SkillFX.emit, not a repeated generic orb.
 return count
end
local function safeMove(session:any,char:Model,root:BasePart,amount:number):boolean
 -- Private V3 uses one active arena per mode. Never dash/warp outside its floor.
 local arena=session.world and session.world:FindFirstChild("TacticalBattlefield")
 if not arena or not arena:IsA("BasePart") or not arena.Parent or not arena.CanCollide then return false end
 local v=root.CFrame.LookVector
 local right=root.CFrame.RightVector
 local ray=RaycastParams.new();ray.FilterType=Enum.RaycastFilterType.Exclude
 ray.FilterDescendantsInstances={char};ray.RespectCanCollide=true
 -- Trace a 3x3 cross-section: the old single center/head ray missed low
 -- barriers, narrow side walls and overhangs. Use the nearest collision.
 local distance=amount
 for _,height in ipairs({-1.1,2,4.6}) do
  for _,side in ipairs({-1.3,0,1.3}) do
   local origin=root.Position+Vector3.new(0,height,0)+right*side
   local hit=workspace:Raycast(origin,v*amount,ray)
   if hit then distance=math.min(distance,math.max(0,hit.Distance-3)) end
  end
 end
 if distance<3 then return false end
 local landing=root.Position+v*distance
 -- Existing Studio arena is unrotated; reject exits, including return into
 -- the other match's field/lobby, with a conservative 4.5-stud margin.
 if math.abs(landing.X-arena.Position.X)>arena.Size.X*.5-4.5
  or math.abs(landing.Z-arena.Position.Z)>arena.Size.Z*.5-4.5 then return false end
 local ground=workspace:Raycast(landing+Vector3.new(0,6,0),Vector3.new(0,-17,0),ray)
 if not ground or not ground.Instance.CanCollide then return false end
 if math.abs(landing.Y-ground.Position.Y)>8 then return false end
 local target=Vector3.new(landing.X,ground.Position.Y+3,landing.Z)
 -- The root cannot be embedded inside a wall, player or low roof even
 -- when a single ray found legal ground. The lower edge stays above floor.
 local overlap=OverlapParams.new()
 overlap.FilterType=Enum.RaycastFilterType.Exclude
 overlap.FilterDescendantsInstances={char}
 overlap.RespectCanCollide=true
 for _,part in ipairs(workspace:GetPartBoundsInBox(CFrame.new(target),Vector3.new(3.2,4.5,3.2),overlap)) do
  if part.CanCollide then return false end
 end
 char:PivotTo(CFrame.new(target,target+v))
 return true
end
local function healAllies(session:any,player:Player,root:BasePart)
 local state=session.rules.castles[tostring(player.UserId)]
 local sourceCharacter=player.Character
 if not state or not state.alive or not sourceCharacter then return end
 for _,other in ipairs(game:GetService("Players"):GetPlayers()) do
  local c=session.rules.castles[tostring(other.UserId)]
  local char,otherRoot,h=characterOf(other)
  if c and c.alive and char and otherRoot and h
   and currentHumanMember(session,other)
   and (session.mode~="TEAM" and other==player or session.mode=="TEAM" and c.team==state.team)
   and (otherRoot.Position-root.Position).Magnitude<=22
   and (other==player or lineClear(root.Position+Vector3.new(0,1.5,0),
    otherRoot.Position+Vector3.new(0,1,0),sourceCharacter,char)) then
   h.Health=math.min(h.MaxHealth,h.Health+25)
  end
 end
 -- Team support must also serve existing server-owned companion AI.
 -- No extra healer, Remote, Game or score authority; keep BR strictly self-only.
 if session.mode=="TEAM" then
  for id,bot in pairs(session.botActors or {}) do
   local teammate=session.rules.castles[id]
   local botRoot=bot and bot.PrimaryPart
   local botHum=bot and bot:FindFirstChildOfClass("Humanoid")
   if teammate and teammate.alive and teammate.team==state.team
    and bot and bot.Parent and botRoot and botHum and botHum.Health>0
    and (botRoot.Position-root.Position).Magnitude<=22
    and lineClear(root.Position+Vector3.new(0,1.5,0),
     botRoot.Position+Vector3.new(0,1,0),sourceCharacter,bot) then
    botHum.Health=math.min(botHum.MaxHealth,botHum.Health+25)
   end
  end
 end
end
-- Status effects are real server damage / movement changes (not only colored VFX).
-- Hard caps and team checks keep control roles useful without stun-locking a duel.
local function secondaryEffect(session:any,p:Player,root:BasePart,char:Model,
 center:Vector3,radius:number,effect:string,shape:string)
 if effect~="CHILL_2S" and effect~="SLOW_3S" and effect~="BURN_3S"
  and effect~="MARK" and effect~="PUSH" and effect~="PREDATOR" then return end
 local state=session.rules.castles[tostring(p.UserId)]
 if not state or not state.alive then return end
 local now=os.clock()
 local originalRules=session.rules
 local duration=if effect=="CHILL_2S" then 2 elseif effect=="PUSH" then 1.2 else 3
 local affected=0
 local function apply(h:Humanoid,bot:Model?,targetId:string)
  if h.Health<=0 or affected>=5 then return end
  -- Capture the castle identity at application time, not at deferred callback.
  local castleAtApplication=originalRules.castles and originalRules.castles[targetId]
  affected+=1
  if effect=="CHILL_2S" or effect=="SLOW_3S" or effect=="PUSH" then
   if bot then
    bot:SetAttribute("EGGRUMBLE_SlowUntil",math.max(bot:GetAttribute("EGGRUMBLE_SlowUntil") or 0,now+duration))
   else
    local base=h:GetAttribute("EGGRUMBLE_OriginalWalkSpeed") or h.WalkSpeed
    if type(base)~="number" then return end
    h:SetAttribute("EGGRUMBLE_OriginalWalkSpeed",base)
    h:SetAttribute("EGGRUMBLE_SlowExpiry",now+duration)
    h.WalkSpeed=math.max(8,base*(if effect=="PUSH" then .58 else .72))
    task.delay(duration+.1,function()
     if h.Parent and os.clock()>=(h:GetAttribute("EGGRUMBLE_SlowExpiry") or math.huge) then
      h.WalkSpeed=base
      h:SetAttribute("EGGRUMBLE_OriginalWalkSpeed",nil)
     end
    end)
   end
  elseif effect=="MARK" then
   h:SetAttribute("EGGRUMBLE_MarkedUntil",now+4)
  elseif effect=="BURN_3S" or effect=="PREDATOR" then
   local untilTime=h:GetAttribute("EGGRUMBLE_BurnUntil") or 0
   if now<untilTime then return end
   h:SetAttribute("EGGRUMBLE_BurnUntil",now+3)
   local tick=if effect=="PREDATOR" then 5 else 4
   for i=1,3 do
    task.delay(i,function()
     -- The original round and the original target identity must still own this tick.
     -- A fallen castle, disconnected player, replaced bot/avatar or finished round
     -- is never damaged by a callback scheduled in an older combat state.
     local sameTarget=false
     if bot then
      sameTarget=(session.botActors or {})[targetId]==bot
       and bot:FindFirstChildOfClass("Humanoid")==h
     else
      local player=game:GetService("Players"):GetPlayerByUserId(tonumber(targetId) or -1)
      sameTarget=player~=nil and player.Character~=nil
       and player.Character:FindFirstChildOfClass("Humanoid")==h
     end
     if h.Parent and StatusTickFence.canTick(session.rules,originalRules,
      targetId,castleAtApplication,sameTarget,h.Health>0) then
      h:TakeDamage(InvulRuntime.filterDamage(h,tick,"ENVIRONMENT","STATUS_DOT"))
     end
    end)
   end
  end
 end
 for id,actor in pairs(session.botActors or {}) do
  local target=session.rules.castles[id]
  local enemy=actor and actor.PrimaryPart
  local hum=actor and actor:FindFirstChildOfClass("Humanoid")
  if target and target.alive and enemy and hum
   and (session.mode~="TEAM" or target.team~=state.team)
   and AttackGeometry.allowed(root.Position,center,enemy.Position,radius,shape)
   and (enemy.Position-root.Position).Magnitude<=36
   and lineClear(root.Position+Vector3.new(0,1,0),enemy.Position,char,actor) then
   apply(hum,actor,id)
  end
 end
 for _,targetPlayer in ipairs(game:GetService("Players"):GetPlayers()) do
  local target=session.rules.castles[tostring(targetPlayer.UserId)]
  local enemyChar,enemyRoot,hum=characterOf(targetPlayer)
  if targetPlayer~=p and target and target.alive and enemyChar and enemyRoot and hum
   and currentHumanMember(session,targetPlayer)
   and humanCombatTargetable(target,targetPlayer)
   and (session.mode~="TEAM" or target.team~=state.team)
   and AttackGeometry.allowed(root.Position,center,enemyRoot.Position,radius,shape)
   and (enemyRoot.Position-root.Position).Magnitude<=36
   and lineClear(root.Position+Vector3.new(0,1,0),enemyRoot.Position, char,enemyChar) then
   apply(hum,nil,tostring(targetPlayer.UserId))
  end
 end
end
local BeastEscort=(function()
-- P0D-GQ-BEAST-ESCORT: a real, temporary, server-owned BEAST companion.
-- Source candidate for inlining into the EXISTING SevenRoleCombat; not a 32nd live Script.
-- All damage is delegated to the existing Combat neutralAndBotHit callback.
local BeastEscort = {}
local active: {[number]: any} = {}
local LIFETIME = 12
local LEASH = 28
local SEEK_RADIUS = 26
local MAX_NEUTRAL_SCAN = 56
local ATTACK_COOLDOWN = 1.4

local function eligible(session:any, ownerState:any, id:string):boolean
 local state = session.rules and session.rules.castles and session.rules.castles[id]
 return state ~= nil and state.alive == true
  and (session.mode ~= "TEAM" or state.team ~= ownerState.team)
end

local function validCaster(session:any, player:Player, character:Model,
 humanoid:Humanoid, ownerState:any):boolean
 return player.Parent ~= nil and player.Character == character
  and humanoid.Parent ~= nil and humanoid.Health > 0
  and character.Parent ~= nil and ownerState.alive == true
  and session.rules.phase == "ACTIVE"
  and session.world ~= nil and session.world.Parent ~= nil
  and player:GetAttribute("EGGRUMBLE_Role") == "BEAST"
  and player:GetAttribute("EGGRUMBLE_Eliminated") ~= true
  and (session.isCurrentHuman == nil or session.isCurrentHuman(player) == true)
end

local function makePet(session:any, player:Player, casterRoot:BasePart): (Model, BasePart, Humanoid)
 local pet = Instance.new("Model")
 pet.Name = "EGGRUMBLE_BeastEscort_" .. tostring(player.UserId)
 local root = Instance.new("Part")
 root.Name = "HumanoidRootPart"
 root.Size = Vector3.new(2.8, 3, 4)
 root.Transparency = 1
 root.CanCollide = true
 root.CanTouch = false
 root.CFrame = casterRoot.CFrame * CFrame.new(0, 0, 6)
 root.Parent = pet
 local body = Instance.new("Part")
 body.Name = "Armor"
 body.Size = Vector3.new(4.4, 3.2, 6.2)
 body.Material = Enum.Material.SmoothPlastic
 body.Color = Color3.fromRGB(115, 85, 54)
 body.CanCollide = false
 body.CanTouch = false
 body.Massless = true
 body.CFrame = root.CFrame
 body.Parent = pet
 local bodyWeld = Instance.new("WeldConstraint")
 bodyWeld.Part0 = root
 bodyWeld.Part1 = body
 bodyWeld.Parent = body
 local head = Instance.new("Part")
 head.Name = "Head"
 head.Shape = Enum.PartType.Ball
 head.Size = Vector3.new(3.4, 2.8, 3)
 head.Material = Enum.Material.SmoothPlastic
 head.Color = Color3.fromRGB(206, 164, 103)
 head.CanCollide = false
 head.CanTouch = false
 head.Massless = true
 head.CFrame = root.CFrame * CFrame.new(0, 1.1, -2)
 head.Parent = pet
 local headWeld = Instance.new("WeldConstraint")
 headWeld.Part0 = root
 headWeld.Part1 = head
 headWeld.Parent = head
 local hum = Instance.new("Humanoid")
 hum.MaxHealth = 60
 hum.Health = 60
 hum.WalkSpeed = 17
 hum.JumpPower = 0
 hum.Parent = pet
 pet.PrimaryPart = root
 pet:SetAttribute("EGGRUMBLE_OwnerId", player.UserId)
 pet:SetAttribute("EGGRUMBLE_BeastCompanion", true)
 pet.Parent = session.world
 pcall(function() root:SetNetworkOwner(nil) end)
 return pet, root, hum
end

local function pickTarget(session:any, player:Player, casterState:any,
 petRoot:BasePart): (Model?, BasePart?)
 local bestModel: Model? = nil
 local bestRoot: BasePart? = nil
 local bestD = SEEK_RADIUS
 local function consider(model:Model?)
  if model == nil or model.Parent == nil then return end
  local r = model.PrimaryPart
  local h = model:FindFirstChildOfClass("Humanoid")
  if r == nil or h == nil or h.Health <= 0 then return end
  local d = (r.Position - petRoot.Position).Magnitude
  if d < bestD then bestD = d; bestModel = model; bestRoot = r end
 end
 local horde = session.world:FindFirstChild("NeutralHorde")
 if horde then
  local scanned = 0
  for _, v in ipairs(horde:GetChildren()) do
   if v:IsA("Model") then
    scanned += 1
    if scanned > MAX_NEUTRAL_SCAN then break end
    consider(v)
   end
  end
 end
 for id, model in pairs(session.botActors or {}) do
  if eligible(session, casterState, id) then consider(model) end
 end
 for _, other in ipairs(game:GetService("Players"):GetPlayers()) do
  if other ~= player and eligible(session, casterState, tostring(other.UserId))
   and (session.isCurrentHuman == nil or session.isCurrentHuman(other) == true) then
   consider(other.Character)
  end
 end
 return bestModel, bestRoot
end

function BeastEscort.stop(player:Player)
 local state = active[player.UserId]
 if state == nil then return end
 active[player.UserId] = nil
 state.dead = true
 if state.model and state.model.Parent then state.model:Destroy() end
end

function BeastEscort.begin(session:any, player:Player, character:Model,
 casterRoot:BasePart, casterHumanoid:Humanoid, ownerState:any, hit:any):boolean
 if type(hit) ~= "function" or not validCaster(session, player, character, casterHumanoid, ownerState) then
  return false
 end
 BeastEscort.stop(player)
 local pet, root, hum = makePet(session, player, casterRoot)
 local state = {model = pet, dead = false, session = session}
 active[player.UserId] = state
 task.spawn(function()
  local start = os.clock()
  local lastHit = start - ATTACK_COOLDOWN
  while not state.dead and active[player.UserId] == state and os.clock() - start < LIFETIME do
   if not validCaster(session, player, character, casterHumanoid, ownerState)
    or hum.Health <= 0 or root.Parent == nil then break end
   if (root.Position - casterRoot.Position).Magnitude > LEASH then
    hum:MoveTo(casterRoot.Position + casterRoot.CFrame.RightVector * 4)
   else
    local target, targetRoot = pickTarget(session, player, ownerState, root)
    if target and targetRoot
     and (targetRoot.Position - root.Position).Magnitude <= SEEK_RADIUS
     and lineClear(root.Position + Vector3.new(0, 1.5, 0),
      targetRoot.Position + Vector3.new(0, 1, 0), pet, target) then
     local range = (targetRoot.Position - root.Position).Magnitude
     if range > 4 then
      hum:MoveTo(targetRoot.Position)
     elseif os.clock() - lastHit >= ATTACK_COOLDOWN then
      lastHit = os.clock()
      -- The same Combat authority rechecks real targets, team, world and LOS.
      -- No secondary damage/Remote/KO authority: only the original Combat callback.
      hit(root, pet, targetRoot.Position)
     end
    else
     hum:MoveTo(casterRoot.Position + casterRoot.CFrame.RightVector * 4)
    end
   end
   task.wait(0.35)
  end
  if active[player.UserId] == state then BeastEscort.stop(player) end
 end)
 return true
end

return BeastEscort
end)()
local function execute(session:any,p:Player,role:string,slot:string)
 if session.rules.phase~="ACTIVE" then return end
 local owner=session.rules.castles[tostring(p.UserId)]
 if not owner or not owner.alive then return end
 if not currentHumanMember(session,p) then return end
 if p:GetAttribute("EGGRUMBLE_Eliminated")==true then return end
 if p:GetAttribute("EGGRUMBLE_Role")~=role then return end
 local char,root,h=characterOf(p)
 if not char or not root or not h then return end
 -- GQ_DEAD_CASTER_FENCE: reject death/downed before skill cost, heal or damage.
 if h.Health<=0 or char:GetAttribute("EGGRUMBLE_Downed")==true then return end
 local now=os.clock()
 local perPlayer=lastByPlayer[p.UserId]
 if not perPlayer then perPlayer={};lastByPlayer[p.UserId]=perPlayer end
 local key=session.mode..":"..role..":"..slot
 local spec=CombatBalance.skill(role,slot)
 local cd=spec.cooldown
 if now-(perPlayer[key] or -10000)<cd then return end
 perPlayer[key]=now
 -- One atomic, server-confirmed cast signature for local R6/R15/AJU presentation.
 -- No client request can authorize damage: tools, ownership and cooldown are above.
 castSequence[p.UserId]=(castSequence[p.UserId] or 0)+1
 p:SetAttribute("EGGRUMBLE_SkillCastSignature",
  role..":"..slot..":"..tostring(castSequence[p.UserId]))
 local def=JOBS[role]
 local boost=if role=="WARRIOR" and now<(char:GetAttribute("EGGRUMBLE_KamiUntil") or 0) then 1.6
  elseif role=="BEAST" and now<(char:GetAttribute("EGGRUMBLE_GiantFeedUntil") or 0) then 1.2 else 1
 local function blast(distance:number?,radius:number?,damage:number?):number
  -- Delayed bursts never hit after death, castle elimination or a new character spawn.
  if not p.Parent or p.Character~=char or h.Health<=0
   or not owner.alive or session.rules.phase~="ACTIVE" then return 0 end
  local forward=distance or spec.reach
  local area=radius or spec.radius
  local amount=damage or spec.damage
  local center=rootAdvance(root,forward)
  local hits=neutralAndBotHit(session,p,root,char,center,area,amount*boost,def.color,spec.shape)
  -- The original author-owned StoneGiant is a real optional shared-world enemy,
  -- not a second neutral boss implementation or an invented regular KO.
  local boss=session.boss
  local weakpoint=boss and boss.weakpoint
  if boss and boss.model and boss.model.Parent and weakpoint and weakpoint.Parent
   and AttackGeometry.allowed(root.Position,center,weakpoint.Position,area,spec.shape)
   and lineClear(root.Position+Vector3.new(0,1.5,0),weakpoint.Position,char,boss.model) then
   local validBossHit=boss.damageFrom(p,math.min(100,amount*boost*(if session.swarm and session.swarm.musouMultiplier then session.swarm.musouMultiplier(p,"BOSS") else 1)),true)
   if validBossHit then
    hits+=1
    if boss.model.Parent then ImpactFeedback.hit(boss.model,role) end
   end
  end
  secondaryEffect(session,p,root,char,center,area,spec.effect,spec.shape)
  SkillFX.emit(session.world,role,slot,root.Position,root.CFrame.LookVector,center,area)
  ImpactFeedback.attacker(p,role,slot,hits)
  return hits
 end
 if role=="WARRIOR" then
  if slot=="A" then blast()
  elseif slot=="B" then
   for i=1,3 do
    task.delay((i-1)*.1,function()
     if session.rules.phase=="ACTIVE" and owner.alive and p.Character==char and h.Health>0 and root.Parent then
      blast(spec.reach+(i-2)*6)
     end
    end)
   end
  else
   DivineMantle.activate(p,6)
   blast()
  end
 elseif role=="MAGE" then
  if slot=="A" then blast()
  elseif slot=="B" then blast()
  else healAllies(session,p,root);blast() end
 elseif role=="NINJA" then
  if slot=="A" then blast()
  elseif slot=="B" then
   if owner.heldEggs==0 and safeMove(session,char,root,25) then
    p:SetAttribute("EGGRUMBLE_StealthUntil",now+3)
   end
   blast()
  else
   for i=1,3 do
    task.delay((i-1)*.14,function() if session.rules.phase=="ACTIVE" and owner.alive and root.Parent then blast(spec.reach+(i-2)*2) end end)
   end
  end
 elseif role=="TRAPPER" then
  if slot=="A" then blast()
  elseif slot=="B" then
   blast()
  else
   if owner.heldEggs==0 then safeMove(session,char,root,20) end
   blast()
  end
 elseif role=="BUILDER" then
  if slot=="A" then blast()
  elseif slot=="B" then
   for i=1,3 do
    task.delay(i*.15,function()
     if session.rules.phase=="ACTIVE" and owner.alive and root.Parent then blast(spec.reach+(i-2)*4) end
    end)
   end
  else
   local turret=makeEffect(session.world,rootAdvance(root,6),Vector3.new(4,5,4),def.color,4.2)
   turret.Name="MadScientistTurret"
   for i=1,4 do
    task.delay(i*.72,function()
     if session.rules.phase=="ACTIVE" and owner.alive and root.Parent and turret.Parent then blast() end
    end)
   end
  end
 elseif role=="BEAST" then
  if slot=="A" then blast()
  elseif slot=="B" then
   -- Real one-companion beast; this existing Combat remains sole damage authority.
   if BeastEscort.begin(session,p,char,root,h,owner,function(petRoot:BasePart,pet:Model,at:Vector3)
    if session.rules.phase=="ACTIVE" and owner.alive and p.Character==char
     and h.Health>0 and p:GetAttribute("EGGRUMBLE_Role")=="BEAST"
     and (session.isCurrentHuman==nil or session.isCurrentHuman(p)==true)
     and (petRoot.Position-root.Position).Magnitude<=28 then
     neutralAndBotHit(session,p,petRoot,pet,at,3.5,6,def.color,spec.shape)
    end
   end) then
    char:SetAttribute("EGGRUMBLE_GiantFeedUntil",now+5)
   end
   blast()
  else
   for i=1,3 do
    local angle=i*math.pi*2/3
    local pos=root.Position+Vector3.new(math.cos(angle)*8,3,math.sin(angle)*8)
    local child=makeEffect(session.world,pos,Vector3.new(4,5,4),def.color,2)
    child.Name="BeastFeedSplit_"..i
    task.delay(i*.12,function()
     if session.rules.phase=="ACTIVE" and owner.alive and root.Parent then
      blast(spec.reach+(i-2)*4)
     end
    end)
   end
  end
 elseif role=="ZOMBIE" then
  -- A: retask FOLLOW; B: retask GUARD; C: spawn 3 real Humanoid servants.
  if slot=="A" then
   ZombieCommander.order(p,"FOLLOW",nil)
   blast()
  elseif slot=="B" then
   ZombieCommander.order(p,"GUARD",nil)
   blast()
  else
   local matchToken=tostring(session)
   -- Weak per-instance keys, monotonic IDs: two NeutralHorde models can share Name.
   -- The same model keeps its ID even if a different neutral dies or reorders.
   local neutralIds=setmetatable({}, {__mode="k"})
   local nextNeutralId=0
   local function neutralTargetId(enemy:Model):string
    local id=neutralIds[enemy]
    if id then return id end
    nextNeutralId+=1
    id="N:"..tostring(p.UserId)..":"..tostring(nextNeutralId)
    neutralIds[enemy]=id
    return id
   end
   local function commanderSnapshot(_player:Player):any
    local state=session.rules.castles[tostring(p.UserId)]
    local alive=state~=nil and state.alive and p.Character==char and h.Health>0
     and session.rules.phase=="ACTIVE" and p:GetAttribute("EGGRUMBLE_Role")=="ZOMBIE"
     and (session.isCurrentHuman==nil or session.isCurrentHuman(p)==true)
    local targets={}
    if alive then
     for _,other in ipairs(game:GetService("Players"):GetPlayers()) do
      local c=session.rules.castles[tostring(other.UserId)]
      local theirChar,theirRoot,theirHum=characterOf(other)
      if other~=p and c and c.alive and theirRoot and theirHum
       and theirHum.Health>0
       and (session.isCurrentHuman==nil or session.isCurrentHuman(other)==true)
       and (session.mode~="TEAM" or c.team~=state.team) then
       table.insert(targets,{id="H:"..tostring(other.UserId),kind="ENEMY_PLAYER",
        x=theirRoot.Position.X,z=theirRoot.Position.Z,active=true,
        matchToken=matchToken,friendly=false})
      end
     end
     for id,enemy in pairs(session.botActors or {}) do
      local c=session.rules.castles[id]
      local er=enemy and enemy.PrimaryPart
      local eh=enemy and enemy:FindFirstChildOfClass("Humanoid")
      if c and c.alive and er and eh and eh.Health>0
       and (session.mode~="TEAM" or c.team~=state.team) then
       table.insert(targets,{id="B:"..id,kind="ENEMY_BOT",
        x=er.Position.X,z=er.Position.Z,active=true,
        matchToken=matchToken,friendly=false})
      end
     end
     local horde=session.world:FindFirstChild("NeutralHorde")
     if horde then
      for _,enemy in ipairs(horde:GetChildren()) do
       if enemy:IsA("Model") then
        local er=enemy.PrimaryPart
        local eh=enemy:FindFirstChildOfClass("Humanoid")
        if er and eh and eh.Health>0 then
         table.insert(targets,{id=neutralTargetId(enemy),kind="NEUTRAL",
          x=er.Position.X,z=er.Position.Z,active=true,
          matchToken=matchToken,friendly=false})
        end
       end
      end
     end
    end
    return {
     ownerId=tostring(p.UserId), ownerAlive=alive==true,
     phase=session.rules.phase, matchToken=matchToken,
     ownerPosition={x=root.Position.X,z=root.Position.Z},
     guardPoint=if session.castleLocations[tostring(p.UserId)]
       then {x=session.castleLocations[tostring(p.UserId)].X,
             z=session.castleLocations[tostring(p.UserId)].Z}
       else {x=root.Position.X,z=root.Position.Z},
     targets=targets,
     visible=function(ax:number,az:number,tx:number,tz:number):boolean
      local ray=RaycastParams.new();ray.FilterType=Enum.RaycastFilterType.Exclude
      local servants=session.world:FindFirstChild("EGGRUMBLE_ZombieServants_"..tostring(p.UserId))
      ray.FilterDescendantsInstances=if servants then {char,servants} else {char}
      ray.RespectCanCollide=true
      local origin=Vector3.new(ax,root.Position.Y+2,az)
      local endpoint=Vector3.new(tx,root.Position.Y+2,tz)
      local delta=endpoint-origin
      if delta.Magnitude<.01 then return true end
      local obstruction=workspace:Raycast(origin,delta,ray)
      return obstruction==nil or obstruction.Distance>=delta.Magnitude-2
     end,
    }
   end
   local function commanderHit(player:Player,targetId:string,damage:number,token:string,minionRoot:BasePart):()
    -- Never expose a new damage authority: one existing author Combat decides.
    if player~=p or token~=matchToken or p.Character~=char
     or not minionRoot or not minionRoot:IsDescendantOf(session.world)
     or h.Health<=0 or session.rules.phase~="ACTIVE" or not owner.alive then return end
    if p:GetAttribute("EGGRUMBLE_Role")~="ZOMBIE" then return end
    local fresh=commanderSnapshot(p)
    if fresh.ownerAlive~=true or fresh.phase~="ACTIVE" then return end
    for _,candidate in ipairs(fresh.targets) do
     if candidate.id==targetId and candidate.active and not candidate.friendly then
      local at=Vector3.new(candidate.x,root.Position.Y,candidate.z)
      -- Keep servants inside the original author's player-attack maximum.
      if (at-minionRoot.Position).Magnitude<=6
       and minionRoot.Parent and minionRoot.Parent:IsA("Model")
       and fresh.visible(minionRoot.Position.X,minionRoot.Position.Z,candidate.x,candidate.z)==true then
       -- Hit from the actual summoned body, never remotely from the caster.
       neutralAndBotHit(session,p,minionRoot,minionRoot.Parent,at,3,math.min(damage,6),def.color,spec.shape)
      end
      return
     end
    end
   end
   ZombieCommander.begin(p,{
    matchToken=matchToken,ownerId=tostring(p.UserId),world=session.world,
    snapshot=commanderSnapshot,hit=commanderHit
   })
  end
 end
end
function HeroCombat.roleOrder():{string}
 return table.clone(ORDER)
end
function HeroCombat.info(role:string):any
 return JOBS[role]
end
function HeroCombat.equip(session:any,p:Player,role:string):()
 assert(RunService:IsStudio(),"Seven-role V3 combat is a private Studio source preview only")
 if not JOBS[role] then role="WARRIOR" end
 if session.rules.phase~="ACTIVE" then return end
 local owner=session.rules.castles[tostring(p.UserId)]
 if not owner or not owner.alive or not p.Parent then return end
 local backpack=p:FindFirstChildOfClass("Backpack")
 if not backpack then return end
 local current=p.Character
 if not current then return end
 DivineMantle.cancel(p)
 current:SetAttribute("EGGRUMBLE_GiantFeedUntil",0)
 p:SetAttribute("EGGRUMBLE_Role",role)
 WeaponSilhouettes.attach(p,role)
 for _,container in ipairs({backpack,current}) do
  for _,instance in ipairs(container:GetChildren()) do
   if instance:IsA("Tool") and (string.sub(instance.Name,1,16)=="EGGRUMBLE_SKILL_" or instance.Name=="EGGRUMBLE_MUSOU_AWAKEN") then instance:Destroy() end
  end
 end
 local data=JOBS[role]
 for index,slot in ipairs({"A","B","C"}) do
  local tool=Instance.new("Tool")
  tool.Name="EGGRUMBLE_SKILL_"..slot.."_"..data.skills[index]
  local spec=CombatBalance.skill(role,slot)
  tool.ToolTip=string.format("%s｜%s｜威力%d｜射程%d｜範囲%d｜再使用%.1fs",
   data.name,data.skills[index],spec.damage,spec.reach,spec.radius,spec.cooldown)
  tool.RequiresHandle=false;tool.CanBeDropped=false
  tool.Activated:Connect(function()
   if tool.Parent~=p.Character then return end
   execute(session,p,role,slot)
  end)
  tool.Parent=backpack
 end
 -- Real server-side Tool.Activated: no client Remote or damage parameter.
 -- This is a fourth selectable ability, distinct from the defensive #823 skill.
 local musouTool=Instance.new("Tool")
 musouTool.Name="EGGRUMBLE_MUSOU_AWAKEN"
 musouTool.ToolTip="無双覚醒｜大群連撃で連チャン・確変｜時間で回復"
 musouTool.RequiresHandle=false
 musouTool.CanBeDropped=false
 musouTool.Activated:Connect(function()
  if musouTool.Parent~=p.Character or not currentHumanMember(session,p) then return end
  if p:GetAttribute("EGGRUMBLE_Role")~=role then return end
  if session.swarm and session.swarm.activateMusou then
   session.swarm.activateMusou(p)
  end
 end)
 musouTool.Parent=backpack
end
function HeroCombat.clear(p:Player)
 lastByPlayer[p.UserId]=nil
 ImpactFeedback.clear(p)
 DivineMantle.cancel(p)
 local c=p.Character
 if c then c:SetAttribute("EGGRUMBLE_GiantFeedUntil",0) end
 WeaponSilhouettes.clear(p)
 for _,container in ipairs({p:FindFirstChildOfClass("Backpack"),p.Character}) do
  if container then
   for _,item in ipairs(container:GetChildren()) do
    if item:IsA("Tool") and (string.sub(item.Name,1,16)=="EGGRUMBLE_SKILL_" or item.Name=="EGGRUMBLE_MUSOU_AWAKEN") then item:Destroy() end
   end
  end
 end
end
return HeroCombat
