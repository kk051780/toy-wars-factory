--!strict
-- EGGRUMBLE V3 mobile-conservative *local* hit response.
-- Read-only replicated server-confirmed impact attributes: no RemoteEvent,
-- no authority or camera knockback on missed hits, no always-on large GUI.
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local TweenService=game:GetService("TweenService")
local player=Players.LocalPlayer
if not RunService:IsStudio() then return end
local IMPACT_WINDOW=.115
local MAX_ANGLE=.006 -- radians; protect mobile players from nausea
local MAX_PUSH=.06 -- studs
local RECENT_CD=.12
local lastPulse=-100
local start=-100
local power=0
local pulse=0
-- GQ8_CONFIRMED_HIT_CHAIN_BEGIN
-- Visual feedback only. Count locally from already server-confirmed impact events.
-- This is NOT the neutral KO combo, rewards, or score source of truth.
local chainHits=0
local lastChainAt=-1000000000
local function hitChainCount(now:number):number
 if now<lastChainAt or now-lastChainAt>1.6 then chainHits=0 end
 lastChainAt=now
 chainHits=math.min(30,chainHits+1)
 return chainHits
end
player:GetAttributeChangedSignal("EGGRUMBLE_QueuedMode"):Connect(function()
 chainHits=0
 lastChainAt=-1000000000
end)
-- GQ8_CONFIRMED_HIT_CHAIN_END
local tones={
 WARRIOR=Color3.fromRGB(255,214,91),
 MAGE=Color3.fromRGB(97,212,255),
 NINJA=Color3.fromRGB(177,117,248),
 TRAPPER=Color3.fromRGB(193,116,255),
 BUILDER=Color3.fromRGB(65,243,205),
 BEAST=Color3.fromRGB(255,176,69),
 ZOMBIE=Color3.fromRGB(146,251,153),
}
-- Small, short-lived hit reticle in the center (nothing persists as a large HUD).
local gui=Instance.new("ScreenGui")
gui.Name="EGGRUMBLE_HitConfirmLocal"
gui.ResetOnSpawn=false;gui.IgnoreGuiInset=true;gui.DisplayOrder=18
gui.Parent=player:WaitForChild("PlayerGui")
local mark=Instance.new("Frame")
mark.Name="HitConfirm"
mark.AnchorPoint=Vector2.new(.5,.5)
mark.Position=UDim2.fromScale(.5,.49)
mark.Size=UDim2.fromOffset(12,12)
mark.BackgroundTransparency=1;mark.Visible=false
mark.Parent=gui
local hitToast=Instance.new("TextLabel")
hitToast.Name="ConfirmedHit042"
hitToast.AnchorPoint=Vector2.new(.5,.5)
hitToast.Position=UDim2.new(.5,6,.49,34)
hitToast.Size=UDim2.fromOffset(62,20)
hitToast.BackgroundColor3=Color3.fromRGB(12,20,29)
hitToast.BackgroundTransparency=.28
hitToast.BorderSizePixel=0
hitToast.TextColor3=Color3.new(1,1,1)
hitToast.TextStrokeTransparency=.65
hitToast.TextScaled=true
hitToast.Font=Enum.Font.GothamBold
hitToast.Text="";hitToast.Visible=false
hitToast.Parent=gui
local corners={}
for i=1,4 do
 local v=Instance.new("Frame")
 v.Name="Tick_"..i;v.BorderSizePixel=0
 v.AnchorPoint=Vector2.new(.5,.5)
 v.Size=UDim2.fromOffset(3,10)
 v.BackgroundColor3=tones.WARRIOR
 v.Parent=mark
 v.Rotation=i*90
 local positions={
  UDim2.fromOffset(6,-9),UDim2.fromOffset(21,6),
  UDim2.fromOffset(6,21),UDim2.fromOffset(-9,6),
 }
 v.Position=positions[i]
 table.insert(corners,v)
end
local function reduced():boolean
 return player:GetAttribute("EGGRUMBLE_ReducedEffects")==true
end
-- GQ8_V3_SERVER_ACCEPTED_CAST_CUE_20261117 BEGIN
-- Server-accepted skill activation, intentionally distinct from a confirmed HIT.
-- No input hook, network events or damage; zero always-visible HUD.
local castCue=Instance.new("Frame")
castCue.Name="ServerAcceptedCastCue"
castCue.AnchorPoint=Vector2.new(.5,.5)
castCue.Position=UDim2.fromScale(.5,.56)
castCue.Size=UDim2.fromOffset(20,3)
castCue.BorderSizePixel=0
castCue.BackgroundColor3=Color3.fromRGB(230,230,230)
castCue.BackgroundTransparency=1
castCue.Visible=false
castCue.Parent=gui
local CAST_CUE_MIN_GAP=.12
local lastCastCue=-100
local lastCastSignature=""
local castCueSerial=0
player:GetAttributeChangedSignal("EGGRUMBLE_SkillCastSignature"):Connect(function()
 local sig=player:GetAttribute("EGGRUMBLE_SkillCastSignature")
 if type(sig)~="string" or sig==lastCastSignature then return end
 local role,slot,seq=string.match(sig,"^([A-Z]+):([ABC]):(%d+)$")
 if not role or not slot or not seq then return end
 if not tones[role] then return end
 lastCastSignature=sig
 if player:GetAttribute("EGGRUMBLE_Eliminated")==true or reduced() then return end
 local char=player.Character
 local hum=char and char:FindFirstChildOfClass("Humanoid")
 if not hum or hum.Health<=0 then return end
 local now=os.clock()
 if now-lastCastCue<CAST_CUE_MIN_GAP then return end
 lastCastCue=now
 castCueSerial+=1
 local current=castCueSerial
 castCue.BackgroundColor3=tones[role]
 castCue.BackgroundTransparency=.24
 castCue.Visible=true
 TweenService:Create(castCue,TweenInfo.new(.18,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),
  {BackgroundTransparency=1}):Play()
 task.delay(.19,function()
  if current==castCueSerial and castCue.Parent then castCue.Visible=false end
 end)
end)
-- GQ8_V3_SERVER_ACCEPTED_CAST_CUE_20261117 END
player:GetAttributeChangedSignal("EGGRUMBLE_ImpactSequence"):Connect(function()
 if reduced() then return end
 local now=os.clock()
 if now-lastPulse<RECENT_CD then return end
 lastPulse=now;start=now
 power=math.clamp(player:GetAttribute("EGGRUMBLE_ImpactWeight") or 1,1,3)
 pulse+=1
 local thisPulse=pulse
 local role=player:GetAttribute("EGGRUMBLE_ImpactRole") or "WARRIOR"
 local c=tones[role] or tones.WARRIOR
 mark.Visible=true;mark.Size=UDim2.fromOffset(12,12)
 local chainCount=hitChainCount(now)
 if chainCount>=3 then
  hitToast.Text="CHAIN x"..tostring(chainCount)
  hitToast.TextColor3=c
 else
  hitToast.Text="HIT x"..tostring(math.floor(power))
  hitToast.TextColor3=Color3.new(1,1,1)
 end
 hitToast.Visible=true
 task.delay(.42,function()
  if thisPulse==pulse and hitToast.Parent then hitToast.Visible=false end
 end)
 for _,v in ipairs(corners) do
  v.BackgroundColor3=c;v.BackgroundTransparency=0
  TweenService:Create(v,TweenInfo.new(.16,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),
   {BackgroundTransparency=1}):Play()
 end
 TweenService:Create(mark,TweenInfo.new(.16,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),
  {Size=UDim2.fromOffset(26,26)}):Play()
 task.delay(.17,function()
  if thisPulse==pulse and mark.Parent then mark.Visible=false end
 end)
end)
RunService:BindToRenderStep("EGGRUMBLE_RealHitFeedback",Enum.RenderPriority.Camera.Value+1,function()
 if reduced() then return end
 local camera=workspace.CurrentCamera
 if not camera or camera.CameraType~=Enum.CameraType.Custom then return end
 local elapsed=os.clock()-start
 if elapsed<0 or elapsed>IMPACT_WINDOW then return end
 local envelope=(1-elapsed/IMPACT_WINDOW)*power/3
 local tilt=MAX_ANGLE*envelope
 camera.CFrame=camera.CFrame*
  CFrame.Angles(math.sin(elapsed*80)*tilt,math.cos(elapsed*70)*tilt*.6,0)*
  CFrame.new(0,0,-MAX_PUSH*envelope)
end)
player.AncestryChanged:Connect(function(_,parent)
 if not parent then
  RunService:UnbindFromRenderStep("EGGRUMBLE_RealHitFeedback")
 end
end)

do -- GQ503_SEVEN_ROLE_SECONDARY_FX_LOD_20261117: original #503 budget inline in CombatFeel
 local fxInput=game:GetService("UserInputService")
 local fxTracked=0
 local fxElapsed=0
 local fxRecords:{[BasePart]:{original:number,hidden:boolean}}={}
 -- Exact original #482 secondary names; NEVER include FX_*_FLASH, *_RING or ULTIMATE_*.
local function fxShouldHide(kind:string,distance:number,touch:boolean,reduced:boolean,active:number,wasHidden:boolean?):boolean
 if kind~="SECONDARY" then return false end
 if type(distance)~="number" or distance~=distance or distance==math.huge or distance<0 then return false end
 if distance<=40 then return false end
 local far=if touch then 85 else 130
 if reduced then
  far=if touch then 48 else 70
 elseif active>=96 then
  far*=if touch then .68 else .8
 elseif active>=60 then
  far*=if touch then .84 else .9
 end
 local threshold=if wasHidden then far-9 else far+9
 return distance>math.max(40,threshold)
end

local fxSecondaryNames={
 WarGod_FlyingSlash=true, Mage_CrystalStorm=true, Assassin_ShadowAfterimage=true,
 Esper_PsiOrbit=true, MadScientist_RailShot=true, Beast_FangClaw=true,
 CurseMaster_SoulFlame=true,
}
 local function fxOriginalArena(part:BasePart):boolean
  local current:Instance?=part.Parent
  while current and current~=workspace do
   if (current.Name=="TEAM_Arena" or current.Name=="BATTLE_ROYALE_Arena")
     and current.Parent and current.Parent.Name=="EGGRUMBLE_LOBBY_CASTLE_MODES_PREVIEW" then
    return true
   end
   current=current.Parent
  end
  return false
 end
 local function fxForget(part:BasePart)
  local record=fxRecords[part]
  if not record then return end
  if part.Parent then part.LocalTransparencyModifier=record.original end
  fxRecords[part]=nil
  fxTracked=math.max(0,fxTracked-1)
 end
 local function fxWatch(inst:Instance)
  if fxTracked>=128 or not inst:IsA("BasePart") then return end
  if fxRecords[inst]~=nil or not fxSecondaryNames[inst.Name] then return end
  if not fxOriginalArena(inst) then return end
  fxRecords[inst]={original=inst.LocalTransparencyModifier,hidden=false}
  fxTracked+=1
 end
 local fxAdded=workspace.DescendantAdded:Connect(fxWatch)
 local fxRemoved=workspace.DescendantRemoving:Connect(function(inst)
  if inst:IsA("BasePart") then fxForget(inst) end
 end)
 local fxHeartbeat=RunService.Heartbeat:Connect(function(dt:number)
  fxElapsed+=math.min(dt,.5)
  if fxElapsed<.22 then return end
  fxElapsed=0
  local camera=workspace.CurrentCamera
  if not camera then return end
  local origin=camera.CFrame.Position
  local touch=fxInput.TouchEnabled
  local reduced=player:GetAttribute("EGGRUMBLE_ReducedEffects")==true
  for part,record in pairs(fxRecords) do
   if not part.Parent or not fxOriginalArena(part) then
    fxForget(part)
   else
    local distance=(part.Position-origin).Magnitude
    local hidden=fxShouldHide("SECONDARY",distance,touch,reduced,fxTracked,record.hidden)
    if record.hidden~=hidden then
     record.hidden=hidden
     part.LocalTransparencyModifier=if hidden then 1 else record.original
    end
   end
  end
 end)
 player.AncestryChanged:Connect(function(_,parent)
  if parent~=nil then return end
  fxAdded:Disconnect();fxRemoved:Disconnect();fxHeartbeat:Disconnect()
  for part in pairs(fxRecords) do fxForget(part) end
 end)
end

do -- GQ496_OBJECTIVE_COMPASS_CURRENT31_20261117: ORIGINAL authored #496 independent client kept verbatim
-- EGGRUMBLE GQ independent objective compass; preview-only client presentation.
-- No remotes, reward authority, damage, item effects, or changes to gameplay ownership.
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
if not RunService:IsStudio() then return end -- Private preview. Official enablement belongs to #220.
local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local SOURCE_ROOT = "EGGRUMBLE_LOBBY_CASTLE_MODES_PREVIEW"
local UPDATE_SECONDS = 0.8
local INITIAL_SECONDS = 18
local arrows = {"↑","↗","→","↘","↓","↙","←","↖"}
local roles = {
 WARRIOR="武神", MAGE="魔法使い", NINJA="暗殺者",
 TRAPPER="超能力者", BUILDER="マッドサイエンティスト",
 BEAST="魔獣使い", ZOMBIE="呪術師",
}
if playerGui:FindFirstChild("EGGRUMBLE_GQ_ObjectiveCompass") then return end
local gui = Instance.new("ScreenGui")
gui.Name="EGGRUMBLE_GQ_ObjectiveCompass"
gui.ResetOnSpawn=false
gui.IgnoreGuiInset=false
gui.DisplayOrder=8
gui.Parent=playerGui
local toggle=Instance.new("TextButton")
toggle.Name="ObjectiveToggle"
toggle.Size=UDim2.fromOffset(52,30)
toggle.Position=UDim2.new(0.5,154,0,10)
toggle.BackgroundColor3=Color3.fromRGB(33,39,51)
toggle.BackgroundTransparency=0.15
toggle.Text="目標"
toggle.TextColor3=Color3.fromRGB(240,244,248)
toggle.TextSize=13
toggle.Font=Enum.Font.GothamMedium
toggle.Visible=false
toggle.Parent=gui
Instance.new("UICorner",toggle).CornerRadius=UDim.new(0,8)
-- Manual home guidance only. Server-side carried-egg state is deliberately not inferred.
local returnHome=Instance.new("TextButton")
returnHome.Name="ManualReturnHome"
returnHome.Size=UDim2.fromOffset(48,30)
returnHome.BackgroundColor3=Color3.fromRGB(51,63,78)
returnHome.BackgroundTransparency=.12
returnHome.Text="帰城"
returnHome.TextColor3=Color3.fromRGB(245,238,197)
returnHome.TextSize=12
returnHome.Font=Enum.Font.GothamMedium
returnHome.Visible=false
returnHome.Parent=gui
Instance.new("UICorner",returnHome).CornerRadius=UDim.new(0,8)
local bar=Instance.new("TextLabel")
bar.Name="OneLineObjective"
bar.AnchorPoint=Vector2.new(0.5,0)
bar.Position=UDim2.new(0.5,-29,0,10)
bar.Size=UDim2.fromOffset(294,30)
bar.BackgroundColor3=Color3.fromRGB(22,29,41)
bar.BackgroundTransparency=0.12
bar.TextColor3=Color3.fromRGB(248,250,255)
bar.TextSize=13
bar.Font=Enum.Font.GothamMedium
bar.TextTruncate=Enum.TextTruncate.AtEnd
bar.Text="目的地を確認中"
bar.Visible=false
bar.Parent=gui
Instance.new("UICorner",bar).CornerRadius=UDim.new(0,8)
local marker=Instance.new("BillboardGui")
marker.Name="ObjectiveWorldMarker"
marker.Size=UDim2.fromOffset(124,31)
marker.StudsOffsetWorldSpace=Vector3.new(0,8,0)
marker.AlwaysOnTop=false -- Respect walls and level geometry.
marker.MaxDistance=380
marker.Enabled=false
marker.Parent=playerGui
local markText=Instance.new("TextLabel")
markText.Size=UDim2.fromScale(1,1)
markText.BackgroundColor3=Color3.fromRGB(28,35,49)
markText.BackgroundTransparency=0.2
markText.TextColor3=Color3.fromRGB(255,236,167)
markText.Font=Enum.Font.GothamBold
markText.TextSize=12
markText.Text="目的地"
markText.Parent=marker
Instance.new("UICorner",markText).CornerRadius=UDim.new(0,9)
local expanded=true
local visibleSince=os.clock()
local lastMode=""
local manuallyReturning=false
local currentTarget:BasePart?=nil

local function isEnemy(mode:string, own:Model, other:Model, arena:Instance):boolean
 if own==other then return false end
 if mode=="BATTLE_ROYALE" then return true end
 if mode~="TEAM" then return false end
 local battlefield=arena:FindFirstChild("TacticalBattlefield")
 local ownVault=own:FindFirstChild("EggVault",true)
 local otherVault=other:FindFirstChild("EggVault",true)
 if not battlefield or not battlefield:IsA("BasePart")
    or not ownVault or not ownVault:IsA("BasePart")
    or not otherVault or not otherVault:IsA("BasePart") then return false end
 -- Opposing castle districts lie on different sides of the existing center road.
 -- Fail closed if the scene layout changes; never mark an unverified ally as enemy.
 return (ownVault.Position.X-battlefield.Position.X)
       *(otherVault.Position.X-battlefield.Position.X)<0
end

local function nearestActiveItem(arena:Instance, at:Vector3):(BasePart?,number)
 local items=arena:FindFirstChild("EGGRUMBLE_FieldItems")
 if not items then return nil,math.huge end
 local nearest:BasePart?=nil
 local best=math.huge
 for _,child in ipairs(items:GetChildren()) do
  if child:IsA("BasePart") and child.CanQuery and child.Transparency<0.5 then
   local distance=(child.Position-at).Magnitude
   if distance<best then best=distance;nearest=child end
  end
 end
 return nearest,best
end

local function pickObjective(mode:string,arena:Instance,own:Model,at:Vector3,homeSelected:boolean):(BasePart?,string)
 if homeSelected then
  local home=own:FindFirstChild("OwnEggDeposit",true)
  if home and home:IsA("BasePart") then return home,"自城へ帰還（手動）" end
  return nil,"自城へ帰還（手動）"
 end
 local item,itemDistance=nearestActiveItem(arena,at)
 if item and itemDistance<=32 then return item,"近くの物資を取る" end
 local boss=arena:FindFirstChild("NEUTRAL_BOSS_STONE_GIANT",true)
 if boss and boss:IsA("Model") then
  local core=boss:FindFirstChild("WeakCore",true) or boss:FindFirstChildWhichIsA("BasePart",true)
  if core and core:IsA("BasePart") and (core.Position-at).Magnitude<=65 then
   return core,"巨人の弱点を狙う"
  end
 end
 local closest:BasePart?=nil
 local best=math.huge
 for _,model in ipairs(arena:GetChildren()) do
  if model:IsA("Model") and model.Name:sub(1,7)=="Castle_"
      and isEnemy(mode,own,model,arena) then
   local vault=model:FindFirstChild("EggVault",true)
   if vault and vault:IsA("BasePart") then
    local dist=(vault.Position-at).Magnitude
    if dist<best then best=dist;closest=vault end
   end
  end
 end
 if closest then return closest,"敵城の卵を奪う → 自城へ納入" end
 local deposit=own:FindFirstChild("OwnEggDeposit",true)
 if deposit and deposit:IsA("BasePart") then return deposit,"自城を防衛・卵を納入" end
 return nil,"敵城の卵を奪って自城へ戻る"
end

local function directionTo(from:Vector3,to:Vector3):string
 local camera=workspace.CurrentCamera
 if not camera then return "•" end
 local delta=Vector3.new(to.X-from.X,0,to.Z-from.Z)
 if delta.Magnitude<0.1 then return "•" end
 local unit=delta.Unit
 local look=camera.CFrame.LookVector
 local right=camera.CFrame.RightVector
 local angle=math.atan2(right:Dot(unit),look:Dot(unit))
 local octant=(math.floor(angle/(math.pi/4)+0.5)%8+8)%8+1
 return arrows[octant]
end

-- Keep the single objective row and mobile touch toggle on narrow Android screens.
local function layoutForViewport()
 local camera=workspace.CurrentCamera
 local width=if camera then camera.ViewportSize.X else 360
 -- Two short touch controls fit even a 320-pixel screen.
 local barWidth=math.min(294,math.max(90,width-132))
 local groupWidth=barWidth+116
 local left=math.max(4,(width-groupWidth)/2)
 bar.Size=UDim2.fromOffset(barWidth,30)
 bar.Position=UDim2.fromOffset(left+barWidth/2,10)
 returnHome.Position=UDim2.fromOffset(left+barWidth+6,10)
 toggle.Position=UDim2.fromOffset(left+barWidth+60,10)
end

local function refresh()
 layoutForViewport()
 local mode=player:GetAttribute("EGGRUMBLE_QueuedMode")
 local world=workspace:FindFirstChild(SOURCE_ROOT)
 local arena=if typeof(mode)=="string" and world then world:FindFirstChild(mode.."_Arena") else nil
 local own=if arena then arena:FindFirstChild("Castle_"..tostring(player.UserId)) else nil
 local battlefield=if arena then arena:FindFirstChild("TacticalBattlefield") else nil
 local character=player.Character
 local root=if character then character:FindFirstChild("HumanoidRootPart") else nil
 local h=if character then character:FindFirstChildOfClass("Humanoid") else nil
 local inArena=false
 if battlefield and battlefield:IsA("BasePart") and root and root:IsA("BasePart") then
  local dx=math.abs(root.Position.X-battlefield.Position.X)
  local dz=math.abs(root.Position.Z-battlefield.Position.Z)
  inArena=dx<=battlefield.Size.X/2+25 and dz<=battlefield.Size.Z/2+25
 end
 if not inArena or not own or not own:IsA("Model")
   or not h or h.Health<=0 or player:GetAttribute("EGGRUMBLE_Eliminated")==true then
  toggle.Visible=false;bar.Visible=false;returnHome.Visible=false;marker.Enabled=false;marker.Adornee=nil
  currentTarget=nil;lastMode="";manuallyReturning=false
  return
 end
 if mode~=lastMode then
  lastMode=mode;expanded=true;visibleSince=os.clock();manuallyReturning=false
 end
 local target,objective=pickObjective(mode,arena,own,root.Position,manuallyReturning)
 currentTarget=target
 if expanded and os.clock()-visibleSince>INITIAL_SECONDS then expanded=false end
 toggle.Visible=true
 toggle.Text=if expanded then "閉じる" else "目標"
 returnHome.Visible=expanded
 returnHome.Text=if manuallyReturning then "攻略" else "帰城"
 bar.Visible=expanded
 local role=player:GetAttribute("EGGRUMBLE_SelectedRole")
 local roleText=if typeof(role)=="string" then (roles[role] or "") else ""
 local suffix=if roleText~="" then " / "..roleText else ""
 if target then
  local dist=math.floor((target.Position-root.Position).Magnitude+0.5)
  bar.Text=directionTo(root.Position,target.Position).." "..objective.." "..tostring(dist).."stud"..suffix
  marker.Adornee=target
  markText.Text=objective
 else
  bar.Text=objective..suffix
  marker.Adornee=nil
 end
 marker.Enabled=expanded and target~=nil
end

returnHome.Activated:Connect(function()
 if not toggle.Visible then return end
 manuallyReturning=not manuallyReturning
 expanded=true
 visibleSince=os.clock()
 refresh()
end)
toggle.Activated:Connect(function()
 if not toggle.Visible then return end
 expanded=not expanded
 visibleSince=os.clock()
 refresh()
end)
UserInputService.InputBegan:Connect(function(input:InputObject,processed:boolean)
 if processed or not toggle.Visible then return end
 if input.KeyCode==Enum.KeyCode.H then
  manuallyReturning=not manuallyReturning
  expanded=true
 elseif input.KeyCode==Enum.KeyCode.G then
  expanded=not expanded
 else
  return
 end
 visibleSince=os.clock()
 refresh()
end)
local elapsed=UPDATE_SECONDS
RunService.Heartbeat:Connect(function(dt:number)
 elapsed+=dt
 if elapsed<UPDATE_SECONDS then return end
 elapsed=0
 refresh()
end)

end

-- GQ504_CONFIRMED_HIT_AUDIO_INLINE_BEGIN_20261117
do
-- EGGRUMBLE QUALITY: real server-confirmed hit sound, seven distinct role profiles.
-- Optional Studio-only LocalScript. Never creates damage/remotes/rewards or changes world state.
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local SoundService=game:GetService("SoundService")
local player=Players.LocalPlayer
if not RunService:IsStudio() then return end
local GROUP="EGGRUMBLE_GQ_ConfirmedHitAudio"
local MIN_GAP=.14
local WINDOW_SECONDS=1
local MAX_PER_WINDOW=6
local MAX_VOICES=4
local MAX_VOLUME=.30
-- Roblox built-in character sound assets; preliminary, not premium final SFX.
local profiles={
 WARRIOR={id="rbxasset://sounds/action_jump_land.mp3",speed=.78,volume=.27},
 MAGE={id="rbxasset://sounds/impact_water.mp3",speed=1.36,volume=.23},
 NINJA={id="rbxasset://sounds/action_jump.mp3",speed=1.80,volume=.19},
 TRAPPER={id="rbxasset://sounds/action_get_up.mp3",speed=1.44,volume=.21},
 BUILDER={id="rbxasset://sounds/action_footsteps_plastic.mp3",speed=.76,volume=.22},
 BEAST={id="rbxasset://sounds/uuhhh.mp3",speed=1.55,volume=.16},
 ZOMBIE={id="rbxasset://sounds/action_swim.mp3",speed=.82,volume=.24},
}
-- Fail closed on accidental duplicate scripts to avoid double sound.
if SoundService:FindFirstChild(GROUP) then
 warn("[EGGRUMBLE GQ AUDIO] duplicate sound module; newer script inactive")
 return
end
local folder=Instance.new("Folder")
folder.Name=GROUP
folder.Parent=SoundService
local voices:{Sound}={}
for i=1,MAX_VOICES do
 local voice=Instance.new("Sound")
 voice.Name="ConfirmedHit_"..i
 voice.Looped=false
 voice.Volume=0
 voice.PlayOnRemove=false
 voice.Parent=folder
 table.insert(voices,voice)
end
local lastSequence=player:GetAttribute("EGGRUMBLE_ImpactSequence")
local lastPlayed=-math.huge
local windowStart=-math.huge
local windowCount=0
local nextVoice=1
local closed=false
local function isEligible():boolean
 if closed or player:GetAttribute("EGGRUMBLE_SFXMuted")==true
  or player:GetAttribute("EGGRUMBLE_Eliminated")==true then return false end
 local character=player.Character
 local humanoid=character and character:FindFirstChildOfClass("Humanoid")
 return humanoid~=nil and humanoid.Health>0
end
local function confirmedHit()
 local sequence=player:GetAttribute("EGGRUMBLE_ImpactSequence")
 if type(sequence)~="number" or sequence~=sequence or sequence<=0
  or (type(lastSequence)=="number" and sequence<=lastSequence) then return end
 lastSequence=sequence
 if not isEligible() then return end
 local now=os.clock()
 if now-lastPlayed<MIN_GAP then return end
 if now-windowStart>=WINDOW_SECONDS then windowStart=now;windowCount=0 end
 if windowCount>=MAX_PER_WINDOW then return end
 local role=player:GetAttribute("EGGRUMBLE_ImpactRole")
 local profile=if type(role)=="string" then profiles[role] else nil
 if not profile then return end
 local weight=player:GetAttribute("EGGRUMBLE_ImpactWeight")
 if type(weight)~="number" or weight~=weight then weight=1 end
 weight=math.clamp(weight,1,3)
 local slot=player:GetAttribute("EGGRUMBLE_ImpactSlot")
 local slotPitch=if slot=="C" then .91 elseif slot=="B" then 1.05 else 1
 local voice=voices[nextVoice]
 nextVoice=nextVoice%MAX_VOICES+1
 voice:Stop()
 voice.SoundId=profile.id
 voice.PlaybackSpeed=math.clamp(profile.speed*slotPitch,.5,2)
 voice.Volume=math.min(MAX_VOLUME,profile.volume*(.85+weight*.08))
 lastPlayed=now
 windowCount+=1
 voice:Play()
end
local function stopVoices()
 for _,voice in ipairs(voices) do voice:Stop() end
end
-- A settings change must silence already-playing audio, not only future hits.
local onMute=player:GetAttributeChangedSignal("EGGRUMBLE_SFXMuted"):Connect(function()
 if player:GetAttribute("EGGRUMBLE_SFXMuted")==true then stopVoices() end
end)
local onEliminated=player:GetAttributeChangedSignal("EGGRUMBLE_Eliminated"):Connect(function()
 if player:GetAttribute("EGGRUMBLE_Eliminated")==true then stopVoices() end
end)
-- Character death/respawn may precede the match-wide Eliminated attribute.
-- Bind per-Humanoid and disconnect on replacement so old deaths cannot mute a new life.
local onHealth:RBXScriptConnection?=nil
local onDied:RBXScriptConnection?=nil
local function clearHumanoidBindings()
 if onHealth then onHealth:Disconnect();onHealth=nil end
 if onDied then onDied:Disconnect();onDied=nil end
end
local function bindCharacter(character:Model)
 clearHumanoidBindings()
 stopVoices()
 local humanoid=(character:FindFirstChildOfClass("Humanoid")
  or character:WaitForChild("Humanoid",5))::Humanoid?
 if closed or player.Character~=character or not humanoid then return end
 onHealth=humanoid.HealthChanged:Connect(function(health)
  if health<=0 then stopVoices() end
 end)
 onDied=humanoid.Died:Connect(stopVoices)
 if humanoid.Health<=0 then stopVoices() end
end
local onCharacterAdded=player.CharacterAdded:Connect(bindCharacter)
local onCharacterRemoving=player.CharacterRemoving:Connect(function()
 stopVoices()
 clearHumanoidBindings()
end)
if player.Character then bindCharacter(player.Character) end
local onHit=player:GetAttributeChangedSignal("EGGRUMBLE_ImpactSequence"):Connect(confirmedHit)
local onRemove:RBXScriptConnection?=nil
onRemove=player.AncestryChanged:Connect(function(_,parent)
 if parent then return end
 closed=true
 onHit:Disconnect()
 onMute:Disconnect()
 onEliminated:Disconnect()
 onCharacterAdded:Disconnect()
 onCharacterRemoving:Disconnect()
 clearHumanoidBindings()
 if onRemove then onRemove:Disconnect() end
 stopVoices()
 if folder.Parent then folder:Destroy() end
end)
end
-- GQ504_CONFIRMED_HIT_AUDIO_INLINE_END_20261117
