--!strict
-- EGGRUMBLE V3 Studio-only match-end feedback; no persistent HUD, datastore or paid rewards.
-- Displays only source-true server results (castle outcome, actual neutral KO, egg delivery).
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local ScoreBalance=require(script.Parent:WaitForChild("EGGRUMBLE_ScoreBalance"))
-- GQ unique: bounded retries for a transient missing PlayerGui at authentic match end.
-- This pure helper creates NO GUI, score, round or player authority.
local ResultRetry = {}
ResultRetry.MAX_RETRIES = 8
ResultRetry.INTERVAL_SECONDS = 0.25

-- isCurrent(): only this original finished session, real joined player and existing world.
-- renderOnce(): original #487 makeResultGui; true only after actual GUI parented.
-- delay(): server task.delay supplied by original ResultService.
function ResultRetry.deliver(isCurrent: () -> boolean, renderOnce: () -> boolean, delay: (number, () -> ()) -> ()): boolean
 assert(type(isCurrent) == "function" and type(renderOnce) == "function" and type(delay) == "function",
  "server callbacks are required")
 local finished = false
 local delivered = false
 local retries = 0
 local function attempt()
  if finished then return end
  -- Never place an old result into a new mode/round or a disconnected player.
  local validOK, valid = pcall(isCurrent)
  if not validOK or valid ~= true then
   finished = true
   return
  end
  local renderOK, rendered = pcall(renderOnce)
  if renderOK and rendered == true then
   finished = true
   delivered = true
   return
  end
  if retries >= ResultRetry.MAX_RETRIES then
   finished = true
   return
  end
  retries += 1
  delay(ResultRetry.INTERVAL_SECONDS, attempt)
 end
 attempt()
 return delivered -- only synchronous genuine GUI delivery yields true
end

local ResultService={}
local DISPLAY_SECONDS=8

local function castleEliminations(events:{any},attackerId:string):number
 local n=0
 for _,event in ipairs(events) do
  if event.type=="CASTLE_FALL" and event.attacker==attackerId then n+=1 end
 end
 return n
end

local function resultText(session:any,player:Player,mode:string,ranking:any):(string,string)
 local id=tostring(player.UserId)
 local castle=session.rules.castles[id]
 if not castle then return "試合終了","観戦をありがとう" end
 local won=if mode=="TEAM" then session.rules.winner==castle.team
  else session.rules.winner==id
-- GQ_DRAW_LABEL_RESULT: the original server-authoritative draw must not appear as a loss.
 local status=if session.rules.winner=="DRAW" then "引き分け"
  elseif won then (if castle.alive then "勝利！" else "チーム勝利！")
  else "試合終了"
 local kos=0
 if session.swarm and session.swarm.kills then kos=session.swarm.kills[id] or 0 end
 local eggs=castle.depositedEggs or 0
 local fallen=castleEliminations(session.rules.events or {},id)
 local place=0;local points=0;local stolen=0;local secured=0;local teamSiege=0;local specialty="参加"
 for index,row in ipairs(ranking.rows) do
  if row.id==id then
   place=index;points=row.score;stolen=row.stolen;secured=row.securedSteals
   teamSiege=row.teamCastleSupport;specialty=row.specialty
   break
  end
 end
 -- Never occupy the active-game HUD. Keep the author's compact eight-second
 -- result only; BR has no teammate, so never show a meaningless "team 0".
-- GQ8_BOSS_RESULT_TRUE_CREDIT_20261118
 local rawBoss=player:GetAttribute("EGGRUMBLE_BossDefeats")
 local boss=if type(rawBoss)=="number" and rawBoss==rawBoss
  and rawBoss>=1 and rawBoss<math.huge then math.min(99,math.floor(rawBoss)) else 0
 local bossSuffix=if boss>0 then " 巨"..tostring(boss) else ""
 if mode=="TEAM" then
  return status.."・"..specialty,string.format("%d位 %d点｜KO%d 奪%d(帰%d) 納%d 城%d 団%d",
   place,points,kos,stolen,secured,eggs,fallen,teamSiege)..bossSuffix
 end
 return status.."・"..specialty,string.format("%d位 %d点｜KO%d 奪%d(帰%d) 納%d 城%d",
  place,points,kos,stolen,secured,eggs,fallen)..bossSuffix
end

local function makeResultGui(player:Player,title:string,stats:string,won:boolean):boolean
 local container=player:FindFirstChildOfClass("PlayerGui")
 if not container then return false end
 local old=container:FindFirstChild("EGGRUMBLE_MatchResult")
 if old then old:Destroy() end

 local gui=Instance.new("ScreenGui")
 gui.Name="EGGRUMBLE_MatchResult"
 gui.ResetOnSpawn=false
 gui.IgnoreGuiInset=true
 gui.DisplayOrder=35
 gui.Parent=container

 local frame=Instance.new("Frame")
 frame.Name="CompactResult"
 frame.AnchorPoint=Vector2.new(.5,1)
 frame.Position=UDim2.new(.5,0,1,-22)
 frame.Size=UDim2.new(.82,0,0,94)
 frame.BackgroundColor3=Color3.fromRGB(23,34,48)
 frame.BackgroundTransparency=.06
 frame.BorderSizePixel=0
 frame.Parent=gui
 local constraint=Instance.new("UISizeConstraint")
 constraint.MaxSize=Vector2.new(480,94)
 constraint.MinSize=Vector2.new(245,94)
 constraint.Parent=frame
 local corner=Instance.new("UICorner")
 corner.CornerRadius=UDim.new(0,14)
 corner.Parent=frame

 local titleLabel=Instance.new("TextLabel")
 titleLabel.Name="ResultTitle"
 titleLabel.BackgroundTransparency=1
 titleLabel.Size=UDim2.new(1,-24,0,45)
 titleLabel.Position=UDim2.fromOffset(12,4)
 titleLabel.Font=Enum.Font.GothamBlack
 titleLabel.TextScaled=true
 titleLabel.TextColor3=if won then Color3.fromRGB(250,223,119)
  else Color3.fromRGB(230,236,245)
 titleLabel.Text="EGGRUMBLE  "..title
 titleLabel.Parent=frame

 local statsLabel=Instance.new("TextLabel")
 statsLabel.Name="VerifiedPersonalStats"
 statsLabel.BackgroundTransparency=1
-- GQ8_RESULT_MOBILE_READABILITY_20261118
 statsLabel.Position=UDim2.fromOffset(12,49)
 statsLabel.Size=UDim2.new(1,-24,0,41)
 statsLabel.Font=Enum.Font.GothamBold
 statsLabel.TextColor3=Color3.fromRGB(232,236,245)
 statsLabel.TextScaled=false
 statsLabel.TextSize=15
 statsLabel.TextWrapped=true
 statsLabel.TextYAlignment=Enum.TextYAlignment.Center
 statsLabel.Text=stats:gsub(" 納","\n納",1)
 statsLabel.Parent=frame

 task.delay(DISPLAY_SECONDS,function()
  if gui.Parent then gui:Destroy() end
 end)
 return true
end

function ResultService.showIfFinished(session:any,queue:{Player},mode:string):boolean
 assert(RunService:IsStudio(),"match result preview is Studio-only")
 if session.resultsDelivered or session.rules.phase~="FINISHED"
  or session.rules.winner==nil then return false end
 -- Consume a finished round once so repeated refresh cannot spam the result overlay.
 session.resultsDelivered=true
 local ranking=ScoreBalance.build(session.rules,session.swarm and session.swarm.kills or {})
 for _,player in ipairs(queue) do
  if player.Parent==Players then
   local castle=session.rules.castles[tostring(player.UserId)]
   if castle then
    local title,stats=resultText(session,player,mode,ranking)
    local won=if mode=="TEAM" then session.rules.winner==castle.team
     else session.rules.winner==tostring(player.UserId)
    -- Preserve the exact existing SCORE/result payload. Only transient GUI absence retries.
    ResultRetry.deliver(function()
     return player.Parent==Players and player:GetAttribute("EGGRUMBLE_QueuedMode")==mode
      and session.mode==mode and session.rules.phase=="FINISHED" and session.rules.winner~=nil
      and session.world~=nil and session.world.Parent~=nil
    end,function()
     return makeResultGui(player,title,stats,won)
    end,task.delay)
   end
  end
 end
 return true
end

return ResultService
