--!strict
local InvulRuntime=require(script.Parent:WaitForChild("EGGRUMBLE_InvulRuntime"))
-- EGGRUMBLE V3: standalone lightweight neutral-horde combat controller.
-- Studio-only, server-attributed real Humanoid deaths; NOT production optimized nor tested.
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local Debris=game:GetService("Debris")
local AttackGeometry=require(script.Parent:WaitForChild("EGGRUMBLE_AttackGeometry"))
local ImpactFeedback=require(script.Parent:WaitForChild("EGGRUMBLE_ImpactFeedback"))
local TweenService=game:GetService("TweenService")
local NeutralFinisherPolicy=require(script.Parent:WaitForChild("EGGRUMBLE_NeutralFinisherPolicy"))
local Musou=require(script.Parent:WaitForChild("EGGRUMBLE_MusouFeverPolicy"))
local CurseConversionPolicy=require(script.Parent:WaitForChild("EGGRUMBLE_CurseConversionPolicy"))
local KoFence=(function()
-- EGGRUMBLE V3 neutral death-credit guard: pure policy + server-owned identity.
-- No new horde, KO counter, damage or score authority.
local Fence = {}

-- Pure negative-first decision for native Luau / offline tests.
function Fence.decide(phase: any, winner: any, attackerAlive: any, neutralInCurrentHorde: any, liveSession: any): boolean
    return phase == "ACTIVE"
        and winner == nil
        and attackerAlive == true
        and neutralInCurrentHorde == true
        and liveSession == true
end

-- Invoke only INSIDE the original SwarmCombat h.Died callback; never from clients.
-- The original callback still owns attribution, impact visuals and KO tally.
function Fence.mayCredit(session: any, id: any, model: any, hordeFolder: any): boolean
    if type(id) ~= "string" or id == "" then return false end
    if not session or not session.rules or not session.rules.castles then return false end
    local castle = session.rules.castles[id]
    if not castle then return false end
    if not model or not hordeFolder or not session.world then return false end
    if hordeFolder.Parent ~= session.world or session.world.Parent == nil then return false end
    if not session.swarm then return false end
    -- A Model from a previous match / separate TEAM-BR arena cannot earn points here.
    if not model:IsDescendantOf(hordeFolder) then return false end
    if model:GetAttribute("EGGRUMBLE_Neutral") ~= true then return false end
    return Fence.decide(session.rules.phase, session.rules.winner, castle.alive,
        true, true)
end

return Fence
end)()
local Melee=require(script.Parent:WaitForChild("EGGRUMBLE_NeutralMeleePolicy"))
local SpawnPacing=require(script.Parent:WaitForChild("EGGRUMBLE_NeutralSpawnPacing"))
local EncounterFair=require(script.Parent:WaitForChild("EGGRUMBLE_NeutralEncounterFairness"))
local Swarm={}
local LIMIT=110
local SPAWN_TICK=.18
local MAX_HITS=24
local MAX_LOS_RAYS_PER_ATTACK=48 -- source-only safety/performance cap; measure on Android
local NEUTRAL_HEALTH=32
local NEUTRAL_SPEED=7
-- Original #482 Swarm remains the ONLY neutral spawner/HP/KO authority.
-- Exactly eight #801 taxonomy IDs. Selection is round-robin to guarantee visibility,
-- independent of random seed and without multiplying the existing 110-model cap.
local SPECIES_IDS=NeutralFinisherPolicy.listSpecies()
assert(#SPECIES_IDS==8,"GQ800: original neutral taxonomy must contain eight species")
local SPECIES_VISUAL={
 ACORN_IMP={color=Color3.fromRGB(157,111,57),accent=Color3.fromRGB(93,160,79),speed=8,scale=.75},
 BABY_GOLEM={color=Color3.fromRGB(117,125,138),accent=Color3.fromRGB(205,188,144),speed=5,scale=1.15},
 BANNER_KNIGHT={color=Color3.fromRGB(102,126,164),accent=Color3.fromRGB(235,194,79),speed=7,scale=1},
 ICE_SLIME={color=Color3.fromRGB(118,203,238),accent=Color3.fromRGB(225,248,255),speed=5.5,scale=.72},
 SHY_WRAITH={color=Color3.fromRGB(162,148,214),accent=Color3.fromRGB(225,224,248),speed=8,scale=.84},
 SPARK_GOBLIN={color=Color3.fromRGB(234,125,52),accent=Color3.fromRGB(255,227,87),speed=9,scale=.85},
 SPIKE_BOAR={color=Color3.fromRGB(151,89,72),accent=Color3.fromRGB(239,203,151),speed=8,scale=.95},
 TINY_SHIELD={color=Color3.fromRGB(105,160,115),accent=Color3.fromRGB(221,216,171),speed=7.5,scale=.77},
}
local SWARM_RANGE=240
local BOT_ATTACK_CD=.62
local function piece(parent:Instance,name:string,pos:Vector3,size:Vector3,color:Color3):Part
 local p=Instance.new("Part");p.Name=name;p.Anchored=true;p.CanCollide=false
 p.Position=pos;p.Size=size;p.Color=color;p.Material=Enum.Material.SmoothPlastic;p.Parent=parent
 return p
end
local function soldier(parent:Instance,at:Vector3,serial:number):Model
 local m=Instance.new("Model")
 m.Name="HordeSoldier";m:SetAttribute("EGGRUMBLE_Neutral",true);m.Parent=parent
 local speciesId=SPECIES_IDS[(serial-1)%#SPECIES_IDS+1]
 local profile=NeutralFinisherPolicy.species(speciesId)
 local visual=SPECIES_VISUAL[speciesId]
 assert(profile and visual,"GQ800 species source lock")
 m:SetAttribute("EGGRUMBLE_NeutralSpecies",speciesId)
 m:SetAttribute("EGGRUMBLE_NeutralPersonality",profile.personality)
 m:SetAttribute("EGGRUMBLE_NeutralReaction",profile.motion)
 m:SetAttribute("EGGRUMBLE_NeutralSpeed",visual.speed)
 local sc=visual.scale
 local root=piece(m,"HumanoidRootPart",at+Vector3.new(0,2*sc,0),Vector3.new(1.7,2.5,1.5)*sc,visual.color)
 root.CanTouch=false
 local head=piece(m,"Head",root.Position+Vector3.new(0,1.85*sc,0),Vector3.new(1.3,1.3,1.3)*sc,visual.accent)
 head.Shape=Enum.PartType.Ball;head.CanTouch=false
 local accent=piece(m,"SpeciesAccent",root.Position+Vector3.new(-1.1*sc,-.1*sc,-.25*sc),Vector3.new(.5,1.5,1.4)*sc,visual.accent)
 -- One extra, small no-collision visual per NPC. Keep low-spec Part budgets bounded.
 if speciesId=="ICE_SLIME" or speciesId=="ACORN_IMP" then
  root.Shape=Enum.PartType.Ball
 elseif speciesId=="SPIKE_BOAR" then
  accent.Shape=Enum.PartType.Ball
 elseif speciesId=="SHY_WRAITH" then
  root.Transparency=.34;head.Transparency=.24
 elseif speciesId=="BANNER_KNIGHT" then
  accent.Size=Vector3.new(.28,3.2,1.1)*sc
 elseif speciesId=="BABY_GOLEM" then
  head.Size=Vector3.new(1.7,1.5,1.55)*sc
 elseif speciesId=="SPARK_GOBLIN" then
  head.Shape=Enum.PartType.Ball
 elseif speciesId=="TINY_SHIELD" then
  accent.Size=Vector3.new(.55,1.8,1.7)*sc
 end
 m.PrimaryPart=root
 local h=Instance.new("Humanoid");h.Name="Humanoid";h.RequiresNeck=false
 -- Stable neutral baseline: species are readability/personality variants, not
 -- eight new HP/spawn budgets. Gameplay balance remains in original Swarm.
 h.MaxHealth=NEUTRAL_HEALTH;h.Health=NEUTRAL_HEALTH;h.BreakJointsOnDeath=false;h.Parent=m
 return m
end
-- Low-cost server-driven physical reaction on the existing accent only.
-- Distinct species-specific pulses; never allocate a new Part per impact.
local REACTION_SCALE={
 BOW_STUMBLE=1.13,SHIELD_TUMBLE=1.26,ROLLING_BOAR=1.32,
 JUMP_SPIN=1.42,PUFF_SMOKE=1.09,JELLY_WOBBLE=1.38,
 SPARK_SPRINT=1.19,FLAT_THEN_POP=1.46,
}
local function playActualReaction(model:Model,cue:any)
 local accent=model:FindFirstChild("SpeciesAccent")
 if not accent or not accent:IsA("BasePart") then return end
 local now=os.clock()
 local last=tonumber(model:GetAttribute("EGGRUMBLE_LastMotionAt")) or -100
 if cue.kind~="KO" and now-last<.16 then return end
 model:SetAttribute("EGGRUMBLE_LastMotionAt",now)
 local serial=(tonumber(model:GetAttribute("EGGRUMBLE_MotionSerial")) or 0)+1
 model:SetAttribute("EGGRUMBLE_MotionSerial",serial)
 local base=accent:GetAttribute("EGGRUMBLE_BaseAccentSize")
 if typeof(base)~="Vector3" then
  base=accent.Size
  accent:SetAttribute("EGGRUMBLE_BaseAccentSize",base)
 end
 local factor=REACTION_SCALE[cue.expression] or 1.18
 if cue.kind=="KO" then factor+=.18 end
 TweenService:Create(accent,TweenInfo.new(.11,Enum.EasingStyle.Back,Enum.EasingDirection.Out),{
  Size=base*factor,
 }):Play()
 if cue.kind=="KO" then
  -- Original singleton Swarm keeps all Humanoid/KO/despawn ownership.
  accent.Material=Enum.Material.Neon
 else
  task.delay(.13,function()
   if model.Parent and accent.Parent and model:GetAttribute("EGGRUMBLE_MotionSerial")==serial then
    TweenService:Create(accent,TweenInfo.new(.12,Enum.EasingStyle.Quad,Enum.EasingDirection.Out),{
     Size=base,
    }):Play()
   end
  end)
 end
end
local function labelKo(p:Player,n:number)
 p:SetAttribute("EGGRUMBLE_NeutralKOs",n)
 local stats=p:FindFirstChild("leaderstats")
 if not stats then
  stats=Instance.new("Folder");stats.Name="leaderstats";stats.Parent=p
 end
 local value=stats:FindFirstChild("NeutralKO")
 if not value then
  value=Instance.new("IntValue");value.Name="NeutralKO";value.Parent=stats
 end
 if value:IsA("IntValue") then value.Value=n end
end
function Swarm.start(session:any)
 assert(RunService:IsStudio(),"Studio-only neutral controller")
  local all=Instance.new("Folder");all.Name="NeutralHorde";all.Parent=session.world
  if session.neutralBudget and session.neutralBudgetEpoch then
   -- Manual folder destruction must not leak tickets before closeRound.
   all.Destroying:Connect(function()
    if session.neutralBudgetEpoch then
     session.neutralBudget:retire(session.mode,session.neutralBudgetEpoch)
    end
   end)
  end
 local live:{[Model]:Humanoid}={}
 local kills:{[string]:number}={}
 local lastBotHit:{[string]:number}={}
 local lastMeleeSwing:{[Model]:number}=setmetatable({}, {__mode="k"}) :: any
 local lastVictimHit:{[Humanoid]:number}=setmetatable({}, {__mode="k"}) :: any
  local encounterFairState={}
 local total=0
 local comboById:{[string]:number}={}
 local lastKillAt:{[string]:number}={}
 local bestCombo:{[string]:number}={}
 local ended=false
  local spawnSerial=0
  local hitSerial=0
 local curseEpoch=tostring(session.world)

 local musouRound=Musou.newRound(tostring(session.world),os.clock())
 local musouNotices:{[string]:number}={}
 local function musouContext(user:Player,now:number)
  local uid=tostring(user.UserId)
  local castle=session.rules.castles[uid]
  local ch=user.Character
  local hum=ch and ch:FindFirstChildOfClass("Humanoid")
  local realMember=false
  if type(session.isCurrentHuman)=="function" then
   local ok,accepted=pcall(session.isCurrentHuman,user)
   realMember=ok and accepted==true
  end
  -- Cargo is read from the one server CastleMatchRules owner, never client HUD.
  local carry=castle~=nil and type(castle.heldEggs)=="number" and castle.heldEggs>0
  local activeShieldUntil=user:GetAttribute("EGGRUMBLE_ShieldUntil")
  local shield=(ch~=nil and ch:FindFirstChildOfClass("ForceField")~=nil)
   or (type(activeShieldUntil)=="number" and activeShieldUntil>now)
  -- ONLY the actual #830 V2 authoritative server-ledger snapshot can block MUSOU.
  -- The guard's ARMED stance is mutually exclusive too (not yet damage immunity).
  local defense=InvulRuntime.currentPolicySnapshot(user)
  local invul=defense.phase=="ARMED" or defense.phase=="AWAKENED"
  local ctx={
   epoch=tostring(session.world),playerId=uid,avatarEpoch=tostring(ch),
   now=now,mode=session.mode,phase=session.rules.phase,
   serverCurrent=realMember,roleVerified=user:GetAttribute("EGGRUMBLE_Role")~=nil,
   role=user:GetAttribute("EGGRUMBLE_Role"),characterAlive=hum~=nil and hum.Health>0,
   castleAlive=castle~=nil and castle.alive==true,
   downed=ch~=nil and ch:GetAttribute("EGGRUMBLE_Downed")==true,
   eliminated=user:GetAttribute("EGGRUMBLE_Eliminated")==true,
   carryingEgg=carry,shieldActive=shield,invulnerable=invul,
  }
  if carry or shield or invul or not ctx.characterAlive or not ctx.castleAlive
     or ctx.downed or ctx.eliminated or session.rules.phase~="ACTIVE" then
   Musou.cancel(musouRound,ctx)
  end
  return ctx
 end
 local function musouReflect(user:Player)
  local uid=tostring(user.UserId)
  local ctx=musouContext(user,os.clock())
  local snap=Musou.snapshot(musouRound,ctx)
  local phase=if snap.active then snap.phase else "OFF"
  user:SetAttribute("EGGRUMBLE_MusouPhase",phase)
  user:SetAttribute("EGGRUMBLE_MusouRole",ctx.role)
  user:SetAttribute("EGGRUMBLE_MusouRemaining",if snap.active then snap.remaining else 0)
  user:SetAttribute("EGGRUMBLE_MusouReadyIn",snap.readyIn)
  if snap.active then
   local count=(musouNotices[uid] or 0)+1
   musouNotices[uid]=count
   -- One bounded expiry task per phase/real KO; stale tasks are invalidated.
   task.delay(math.min(20.1,math.max(.05,snap.remaining+.04)),function()
    if musouNotices[uid]==count and session.rules.phase=="ACTIVE" then
     musouReflect(user)
    end
   end)
  end
 end
 local curseStates:{[string]:any}={}
 local charmedByModel:{[Model]:any}={}
 local neutralById:{[string]:Model}={}
 local lastCharmAttack:{[Model]:number}={}
 local function currentZombie(user:Player?):boolean
  if not user or user:GetAttribute("EGGRUMBLE_Role")~="ZOMBIE" then return false end
  if not session.isCurrentHuman or session.isCurrentHuman(user)~=true then return false end
  local c=session.rules.castles[tostring(user.UserId)]
  local ch=user.Character
  local h=ch and ch:FindFirstChildOfClass("Humanoid")
  return c~=nil and c.alive==true and ch~=nil and h~=nil and h.Health>0
 end
 local function releaseCharmed(model:Model)
  local rec=charmedByModel[model]
  if not rec then return end
  charmedByModel[model]=nil
  lastCharmAttack[model]=nil
  model:SetAttribute("EGGRUMBLE_NeutralFriendlyOwnerId",nil)
  model:SetAttribute("EGGRUMBLE_NeutralCharmUntil",nil)
  model:SetAttribute("EGGRUMBLE_NeutralSeals",nil)
  local accent=model:FindFirstChild("SpeciesAccent")
  if accent and accent:IsA("BasePart") then accent.Color=rec.originalColor end
 end
 assert(LIMIT==SpawnPacing.MAX_ALIVE,"horde/planner live cap drift")
 local planner=SpawnPacing.new(session.world.Name..":"..tostring(os.clock()))
 local function credit(id:string)
  kills[id]=(kills[id] or 0)+1
  total+=1
  local n=kills[id]
  local now=os.clock()
  local combo=if now-(lastKillAt[id] or -100)<4 then (comboById[id] or 0)+1 else 1
  comboById[id]=combo
  lastKillAt[id]=now
  bestCombo[id]=math.max(bestCombo[id] or 0,combo)
  local p=Players:GetPlayerByUserId(tonumber(id) or -1)
  if p then
   labelKo(p,n)
   p:SetAttribute("EGGRUMBLE_BattleLevel",math.min(50,1+math.floor(n/25)))
   p:SetAttribute("EGGRUMBLE_Combo",combo)
   p:SetAttribute("EGGRUMBLE_BestCombo",bestCombo[id])
   if combo%25==0 then
    local character=p.Character
    local root=character and character:FindFirstChild("HumanoidRootPart")::BasePart?
    if root then
     -- Light diegetic KO celebration, never a giant permanently blocking mobile HUD.
     local gui=Instance.new("BillboardGui")
     gui.Name="EGGRUMBLE_ComboBurst";gui.Size=UDim2.fromOffset(150,45)
     gui.StudsOffset=Vector3.new(0,4,0);gui.AlwaysOnTop=false;gui.Parent=root
     local txt=Instance.new("TextLabel")
     txt.Size=UDim2.fromScale(1,1);txt.BackgroundTransparency=1
     txt.TextColor3=Color3.fromRGB(255,216,78)
     txt.TextStrokeTransparency=.15;txt.Font=Enum.Font.GothamBlack
     txt.TextScaled=true;txt.Text=tostring(combo).." COMBO!"
     txt.Parent=gui;Debris:AddItem(gui,.95)
    end
   end
   p:SetAttribute("EGGRUMBLE_SlashEvolution",if n>=100 then "TEMPEST" elseif n>=40 then "WAVE" else "BASE")
  end
  session.neutralTotal=total
 end
 -- GQ8_NEUTRAL_SPAWN_CLEARANCE_BEGIN
 -- Bound spawn checks: no new AI owner, loop, player state or remote.
 local SPAWN_ATTEMPTS=3
 local spawnFloor=session.world:FindFirstChild("TacticalBattlefield")
 local spawnOverlap=OverlapParams.new()
 spawnOverlap.FilterType=Enum.RaycastFilterType.Exclude
 spawnOverlap.FilterDescendantsInstances={all}
 spawnOverlap.RespectCanCollide=true
 local function neutralWithinArena(point:Vector3,floor:BasePart):boolean
  local margin=6
  return floor.Size.X>margin*2 and floor.Size.Z>margin*2
   and math.abs(point.X-floor.Position.X)<=floor.Size.X*.5-margin
   and math.abs(point.Z-floor.Position.Z)<=floor.Size.Z*.5-margin
 end
 local function neutralSpawnClear(point:Vector3):boolean
  if not spawnFloor or not spawnFloor:IsA("BasePart") then return false end
  if not neutralWithinArena(point,spawnFloor) then return false end
  -- Keep entire lightweight 5-stud-tall neutral body out of collidable parts.
  local parts=workspace:GetPartBoundsInBox(
   CFrame.new(point+Vector3.new(0,2.6,0)),Vector3.new(2.8,5.1,2.8),spawnOverlap)
  for _,obstacle in ipairs(parts) do
   if obstacle.CanCollide then return false end
  end
  return true
 end
 -- GQ8_NEUTRAL_SPAWN_CLEARANCE_END
 local function addEnemy(at:Vector3)
  -- Validate BEFORE reserving neutral budget or creating a Humanoid.
  local usable:Vector3?=nil
  for _attempt=1,SPAWN_ATTEMPTS do
   local point=if _attempt==1 then at else
    at+Vector3.new(math.random(-12,12),0,math.random(-12,12))
   if neutralSpawnClear(point) then
    usable=point
    break
   end
  end
  if not usable then return end
  at=usable
  -- PRIVATE GQ528 ON: reserve one global live-model ticket BEFORE creating an NPC.
  local ticket:string?=nil
  if session.neutralBudget then
   local permit,_reason=session.neutralBudget:acquire(session.mode,session.neutralBudgetEpoch)
   if not permit then return end
   ticket=permit
  end
  spawnSerial+=1
   local constructed,model=pcall(soldier,all,at,spawnSerial)
  if not constructed then
   if ticket then session.neutralBudget:release(ticket) end
   warn("[GQ528] neutral spawn rejected",model)
   return
  end
  local m=model :: Model
  local h=m:FindFirstChildOfClass("Humanoid") :: Humanoid
  if not h then
   if ticket then session.neutralBudget:release(ticket) end
   m:Destroy()
   return
  end
  if ticket then
   m.Destroying:Connect(function() session.neutralBudget:release(ticket) end)
  end
  live[m]=h
  local neutralId=tostring(spawnSerial)
  m:SetAttribute("EGGRUMBLE_NeutralInstanceId",neutralId)
  neutralById[neutralId]=m
   h.Died:Connect(function()
    if ticket then session.neutralBudget:release(ticket) end
    live[m]=nil
    neutralById[neutralId]=nil
    local wasCharmed=charmedByModel[m]~=nil
    releaseCharmed(m)
   lastMeleeSwing[m]=nil
   local id=h:GetAttribute("LastAttackerId")
   if type(id)=="string" and session.rules.phase=="ACTIVE"
    and session.rules.castles[id] and session.rules.castles[id].alive
    and KoFence.mayCredit(session,id,m,all) then
    local attacker=Players:GetPlayerByUserId(tonumber(id) or -1)
    ImpactFeedback.ko(all,m,attacker and (attacker:GetAttribute("EGGRUMBLE_Role") or "WARRIOR") or "WARRIOR")
    credit(id)
     -- The genuine existing KoFence just accepted this single death and score.
     -- No synthetic KO or duplicate scoring; the neutralId is session-unique.
     if attacker and not wasCharmed then
      local context=musouContext(attacker,os.clock())
      local ok=Musou.onConfirmedKO(musouRound,context,{
       serverConfirmed=true,enemyConfirmed=true,creditVerified=true,
       scoreEligible=true,creditedPlayerId=id,
       victimId=neutralId,receiptId=curseEpoch..":"..neutralId,
       targetKind="NEUTRAL",isSummoned=false,isConverted=false,
      })
      if ok then musouReflect(attacker) end
     end
   end
   task.delay(.25,function() if m.Parent then m:Destroy() end end)
  end)
 end
 local function aliveTargets():({Vector3},{string})
  local a={}
  local kinds:{string}={}
  for _,p in ipairs(Players:GetPlayers()) do
   local c=session.rules.castles[tostring(p.UserId)]
   if c and c.alive then
    local ch=p.Character
    local root=ch and ch:FindFirstChild("HumanoidRootPart")::BasePart?
    local hum=ch and ch:FindFirstChildOfClass("Humanoid")
     if root and hum and hum.Health>0 and session.isCurrentHuman~=nil and session.isCurrentHuman(p) then
      table.insert(a,root.Position)
      table.insert(kinds,"HUMAN")
     end
   end
  end
  for id,m in pairs(session.botActors or {}) do
   local c=session.rules.castles[id]
   local hum=m and m:FindFirstChildOfClass("Humanoid")
    if c and c.alive and m.Parent and m.PrimaryPart and hum and hum.Health>0 then
     table.insert(a,m.PrimaryPart.Position)
     table.insert(kinds,"BOT")
    end
  end
  return a,kinds
 end
 local function liveMeleeVictims():{any}
  local victims={}
  for _,p in ipairs(Players:GetPlayers()) do
   local castle=session.rules.castles[tostring(p.UserId)]
   local ch=p.Character
   local root=ch and ch:FindFirstChild("HumanoidRootPart")::BasePart?
   local hum=ch and ch:FindFirstChildOfClass("Humanoid")
   if p.Parent and session.isCurrentHuman~=nil and session.isCurrentHuman(p)
    and castle and castle.alive and root and hum and hum.Health>0 then
    table.insert(victims,{root=root,humanoid=hum})
   end
  end
  for id,actor in pairs(session.botActors or {}) do
   local castle=session.rules.castles[id]
   local root=actor and actor.PrimaryPart
   local hum=actor and actor:FindFirstChildOfClass("Humanoid")
   if castle and castle.alive and actor.Parent and root and hum and hum.Health>0 then
    table.insert(victims,{root=root,humanoid=hum})
   end
  end
  return victims
 end
 local function meleeLineClear(mob:Model,target:BasePart):boolean
  local root=mob.PrimaryPart
  if not root or not target.Parent then return false end
  local from=root.Position+Vector3.new(0,1,0)
  local delta=(target.Position+Vector3.new(0,1,0))-from
  if delta.Magnitude<=.01 then return true end
  local params=RaycastParams.new()
  params.FilterType=Enum.RaycastFilterType.Exclude
  params.FilterDescendantsInstances={mob,target.Parent}
  params.RespectCanCollide=true
  return workspace:Raycast(from,delta,params)==nil
 end
 -- Area skills have a visible area, not the ability to hit through solid castle walls.
 local function lineOfSightToNeutral(origin:Vector3,attacker:Model,target:Model):boolean
  local root=target.PrimaryPart
  if not root then return false end
  local params=RaycastParams.new()
  params.FilterType=Enum.RaycastFilterType.Exclude
  params.FilterDescendantsInstances={attacker,target}
  params.RespectCanCollide=true
  local delta=(root.Position+Vector3.new(0,1,0))-origin
  if delta.Magnitude<=.01 then return true end
  return workspace:Raycast(origin,delta,params)==nil
 end
 local function strike(id:string,at:Vector3,radius:number,damage:number,origin:Vector3,attacker:Model,shape:string):number
  if session.rules.phase~="ACTIVE" then return 0 end
  local player=session.rules.castles[id]
  if not player or not player.alive then return 0 end
  local nearest={}
  for m,h in pairs(live) do
   if m.Parent and h.Health>0 and m.PrimaryPart and not charmedByModel[m] then
    local delta=m.PrimaryPart.Position-at
    local dis=math.sqrt(delta.X*delta.X+delta.Z*delta.Z)
    if AttackGeometry.allowed(origin,at,m.PrimaryPart.Position,radius,shape) then
     table.insert(nearest,{target=h,dist=dis})
    end
   end
  end
  table.sort(nearest,function(x,y)return x.dist<y.dist end)
  -- A blocked target never consumes a KO/HIT slot; guard CPU with a fixed ray budget.
  local hits=0
  local rays=0
  for _,candidate in ipairs(nearest) do
   if hits>=MAX_HITS or rays>=MAX_LOS_RAYS_PER_ATTACK then break end
   rays+=1
   local h=candidate.target
   local model=h.Parent
   if model and model:IsA("Model") and lineOfSightToNeutral(origin,attacker,model) then
    local oldAttacker=h:GetAttribute("LastAttackerId")
    h:SetAttribute("LastAttackerId",id)
    local before=h.Health
    local directUser=Players:GetPlayerByUserId(tonumber(id) or -1)
    local isCurseAttack=currentZombie(directUser) and directUser.Character==attacker
    local effectiveDamage=damage
    if isCurseAttack and h.Health>0 then
     local cap=if model:GetAttribute("EGGRUMBLE_NeutralSpecies")=="BABY_GOLEM" then 7 else 11
     effectiveDamage=math.min(math.max(0,damage),cap)
    end
    h:TakeDamage(InvulRuntime.filterDamage(h,effectiveDamage,"PLAYER","SWARM_ATTACKER")) -- ONE existing Humanoid damage authority
    -- ForceField or zero-damage requests must not fabricate hits or steal KO credit.
    if h.Health>=before then
     h:SetAttribute("LastAttackerId",oldAttacker)
     continue
    end
    local user=Players:GetPlayerByUserId(tonumber(id) or -1)
    if h.Health<before then
     hitSerial+=1
     local role=user and (user:GetAttribute("EGGRUMBLE_Role") or "WARRIOR") or "WARRIOR"
     local cue=NeutralFinisherPolicy.select({
      serverConfirmed=true,uniqueHitId=tostring(hitSerial),targetIsNeutral=true,
      isFriendly=false,matchActive=session.rules.phase=="ACTIVE",epochCurrent=true,
      role=role,species=model:GetAttribute("EGGRUMBLE_NeutralSpecies"),
      ko=h.Health<=0,element="NONE",distanceStuds=(model.PrimaryPart.Position-origin).Magnitude,
      visible=true,deviceTier="LOW",combo=0,targetId=tostring(hitSerial),
     })
     if cue then
      model:SetAttribute("EGGRUMBLE_NeutralReaction",cue.expression)
      model:SetAttribute("EGGRUMBLE_NeutralFinisher",cue.finisher)
      model:SetAttribute("EGGRUMBLE_NeutralHitSerial",hitSerial)
      playActualReaction(model,cue)
      if cue.kind=="KO" then
       local part=model:FindFirstChild("SpeciesAccent")
       if part and part:IsA("BasePart") then part.Material=Enum.Material.Neon end
      end
     end
    end
    if isCurseAttack and user and h.Health>0 and h.MaxHealth>0 and model.PrimaryPart then
     local ownerId=tostring(user.UserId)
     local state=curseStates[ownerId]
     if not state or not state.active then
      -- Dead avatar, role switch, or epoch change retires the previous policy state.
      -- A verified living ZOMBIE re-entry starts with a clean seal ledger.
      state=CurseConversionPolicy.new(curseEpoch,ownerId)
      curseStates[ownerId]=state
     end
     local targetId=model:GetAttribute("EGGRUMBLE_NeutralInstanceId")
     local actualDistance=(model.PrimaryPart.Position-origin).Magnitude
     local numSummoned=tonumber(user:GetAttribute("EGGRUMBLE_ZombieSummonedCount"))
     -- No connected summon receipt: reserve three slots rather than risk overfill.
     if type(targetId)=="string" and actualDistance<=32 then
      local decision=CurseConversionPolicy.seal(state,os.clock(),{
       serverConfirmedHit=true,role="ZOMBIE",epoch=curseEpoch,ownerId=ownerId,
       phase=session.rules.phase,ownerAlive=true,avatarCurrent=true,
       targetKind="NEUTRAL",targetAlive=true,targetFriendly=false,
       isBoss=false,isPlayer=false,sameTeam=false,inLineOfSight=true,
       distance=actualDistance,targetId=targetId,
       species=model:GetAttribute("EGGRUMBLE_NeutralSpecies"),
       hpFraction=h.Health/h.MaxHealth,uniqueHitId=ownerId..":"..tostring(hitSerial),
       existingSummoned=if numSummoned then math.clamp(math.floor(numSummoned),0,3) else 3,
      })
      if decision and decision.kind=="CHARM" then
       -- Exactly the pre-existing actual neutral Model changes allegiance.
       local accent=model:FindFirstChild("SpeciesAccent")
       charmedByModel[model]={ownerId=ownerId,neutralId=targetId,
        originalColor=if accent and accent:IsA("BasePart") then accent.Color else Color3.new(1,1,1),
        guardPoint=model.PrimaryPart.Position}
       model:SetAttribute("EGGRUMBLE_NeutralFriendlyOwnerId",ownerId)
       model:SetAttribute("EGGRUMBLE_NeutralCharmUntil",decision.expires)
       h:SetAttribute("LastAttackerId",nil) -- no stale false KO on allegiance flip
       if accent and accent:IsA("BasePart") then accent.Color=Color3.fromRGB(110,232,165) end
      elseif decision and decision.kind=="SEAL" then
       model:SetAttribute("EGGRUMBLE_NeutralSeals",decision.stacks)
      end
     end
    end
    ImpactFeedback.hit(model,user and (user:GetAttribute("EGGRUMBLE_Role") or "WARRIOR") or "WARRIOR")
    hits+=1
   end
  end
  return hits
 end
 local api={
  activateMusou=function(user:Player)
   local ctx=musouContext(user,os.clock())
   local ok,decision=Musou.activate(musouRound,ctx)
   musouReflect(user)
   return ok,decision
  end,
  musouMultiplier=function(user:Player,kind:string)
   return Musou.attackMultiplier(musouRound,musouContext(user,os.clock()),kind)
  end,
  musouActive=function(user:Player):boolean
   local snap=Musou.snapshot(musouRound,musouContext(user,os.clock()))
   return snap.active==true
  end,
  kills=kills,
  damageFromPlayer=function(player:Player,at:Vector3,radius:number,damage:number,shape:string?):number
   local character=player.Character
   local root=character and character:FindFirstChild("HumanoidRootPart")::BasePart?
   local humanoid=character and character:FindFirstChildOfClass("Humanoid")
   if not character or not root or not humanoid or humanoid.Health<=0 then return 0 end
   -- Splash center is server-generated and stays in reach of the living attacker.
   if (at-root.Position).Magnitude>36 then return 0 end
   -- Survival-like neutral-only momentum: max +12%, NEVER affects human PvP/castle HP.
   local currentCombo=if os.clock()-(lastKillAt[tostring(player.UserId)] or -100)<4
    then (comboById[tostring(player.UserId)] or 0) else 0
   local bonus=if currentCombo>=60 then 1.12 elseif currentCombo>=20 then 1.06 else 1
   local power=Musou.attackMultiplier(musouRound,musouContext(player,os.clock()),"NEUTRAL")
   return strike(tostring(player.UserId),at,radius,damage*bonus*power,
    root.Position+Vector3.new(0,1,0),character,shape or "CIRCLE")
  end,
  damageFromBot=function(botId:string,at:Vector3):number
   local actor=session.botActors and session.botActors[botId]
   local root=actor and actor.PrimaryPart
   local h=actor and actor:FindFirstChildOfClass("Humanoid")
   if not actor or not root or not h or h.Health<=0 then return 0 end
   if (root.Position-at).Magnitude>5 then return 0 end
   local now=os.clock()
   if now-(lastBotHit[botId] or 0)<BOT_ATTACK_CD then return 0 end
   lastBotHit[botId]=now
   local center=root.Position+root.CFrame.LookVector*3
   return strike(botId,center,9,NEUTRAL_HEALTH,root.Position+Vector3.new(0,1,0),actor,"FANG")
  end,
  orderCharmed=function(user:Player,order:string,focusId:string?):boolean
   if not currentZombie(user) then return false end
   local state=curseStates[tostring(user.UserId)]
   if not state then return false end
   if order=="FOCUS" and (not focusId or not neutralById[focusId]
     or charmedByModel[neutralById[focusId]]) then return false end
   return CurseConversionPolicy.order(state,order,focusId)
  end,
  getAliveCount=function():number
   local n=0;for m,h in pairs(live) do if m.Parent and h.Health>0 then n+=1 end end
   return n
  end,
  getTotal=function():number return total end,
 }
 session.swarm=api
 local lastSpawnAt=os.clock()
 task.spawn(function()
  while all.Parent and session.rules.phase=="ACTIVE" do
   local candidates,kinds=aliveTargets()
   local now=os.clock()
   local elapsed=now-lastSpawnAt
   lastSpawnAt=now
   local batch=SpawnPacing.step(planner,{
    matchId=planner.matchId,phase=session.rules.phase,dt=elapsed,
    live=api.getAliveCount(),activeHeroes=#candidates,
    tickMs=math.max(0,(elapsed-SPAWN_TICK)*1000),
   })
   if batch>0 then
    for _=1,batch do
     local selected=EncounterFair.chooseIndex(encounterFairState,session,kinds)
      if selected==nil then break end
      local target=candidates[selected]
     local a=math.random()*math.pi*2
     local d=math.random(21,58)
     local at=target+Vector3.new(math.cos(a)*d,0,math.sin(a)*d)
     -- Always in the same wide battle district as its current moving hero.
     addEnemy(Vector3.new(at.X,session.groundY or target.Y-4,at.Z))
    end
   end
   task.wait(SPAWN_TICK)
  end
  EncounterFair.clear(encounterFairState)
  ended=true
 end)
 task.spawn(function()
  while all.Parent and session.rules.phase=="ACTIVE" do
   local candidates=aliveTargets()
   local victims=liveMeleeVictims()
   local meleeRays=0
   local meleeNow=os.clock()
   if #candidates>0 then
    for m,h in pairs(live) do
     if m.Parent and m.PrimaryPart and h.Health>0 and not charmedByModel[m] then
      local at=m:GetPivot().Position
      local near=nil;local best=SWARM_RANGE
      for _,target in ipairs(candidates) do
       local delta=Vector3.new(target.X-at.X,0,target.Z-at.Z)
       if delta.Magnitude<best then near=delta;best=delta.Magnitude end
      end
      if near and best>3 then
       local actualSpeed=tonumber(m:GetAttribute("EGGRUMBLE_NeutralSpeed")) or NEUTRAL_SPEED
       local travel=math.min(actualSpeed*.38,best)
       local forward=near.Unit*travel
       local params=RaycastParams.new()
       params.FilterType=Enum.RaycastFilterType.Exclude
       params.FilterDescendantsInstances={all}
       params.RespectCanCollide=true
       local origin=at+Vector3.new(0,1,0)
       local function free(step:Vector3):boolean
        if step.Magnitude<=.01 then return false end
        return workspace:Raycast(origin,step+step.Unit*.35,params)==nil
       end
       local chosen:Vector3?=nil
       if free(forward) then
        chosen=forward
       else
        -- NPCs take a small sidestep, never ghost through a solid gate or wall.
        local sideways=Vector3.new(-near.Unit.Z,0,near.Unit.X)*travel
        if free(sideways) then chosen=sideways
        elseif free(-sideways) then chosen=-sideways end
       end
       if chosen then
        local next=at+chosen
        -- Keep neutral feet on walkable ground and reject void/steep wall transitions.
        -- Existing species rig starts with its root 2*scale above the floor.
        local scale=(m.PrimaryPart and m.PrimaryPart.Size.Y/2.5) or 1
        local ground=workspace:Raycast(next+Vector3.new(0,3,0),Vector3.new(0,-8,0),params)
        if ground and ground.Normal.Y>=.72 then
         local desiredY=ground.Position.Y+2*scale
         if math.abs(desiredY-at.Y)<=1.4 then
          local grounded=Vector3.new(next.X,desiredY,next.Z)
          m:PivotTo(CFrame.lookAt(grounded,grounded+near.Unit))
         end
        end
       end
      end
      -- Same existing Swarm tick/neutral owner; capped melee is NOT a second AI loop.
      if meleeRays<Melee.MAX_RAYS_PER_TICK and session.rules.phase=="ACTIVE" then
       local mobRoot=m.PrimaryPart
       if mobRoot then
        -- Select the nearest READY candidate, not merely the nearest body.
        -- A victim on cooldown or behind a solid wall must not starve others.
        local eligible={}
        for index,victim in ipairs(victims) do
         local dist=(mobRoot.Position-victim.root.Position).Magnitude
         if Melee.ready(lastMeleeSwing,lastVictimHit,m,victim.humanoid,
          meleeNow,dist,true,h.Health>0,victim.humanoid.Health>0) then
          table.insert(eligible,{victim=victim,distance=dist,slot=index})
         end
        end
        table.sort(eligible,function(a,b)
         if a.distance==b.distance then return a.slot<b.slot end
         return a.distance<b.distance
        end)
        for _,candidate in ipairs(eligible) do
         if meleeRays>=Melee.MAX_RAYS_PER_TICK then break end
         meleeRays+=1
         if meleeLineClear(m,candidate.victim.root) then
          Melee.commit(lastMeleeSwing,lastVictimHit,m,candidate.victim.humanoid,meleeNow)
          -- Roblox Humanoid:TakeDamage respects ForceField.
          candidate.victim.humanoid:TakeDamage(InvulRuntime.filterDamage(candidate.victim.humanoid,Melee.DAMAGE,"NEUTRAL","SWARM_MELEE"))
          break -- One real hit per soldier swing.
         end
        end
       end
      end
     end
    end
   end
   local now=os.clock()
   local snapNeutrals={}
   for m,rec in pairs(charmedByModel) do
    local h=live[m]
    snapNeutrals[rec.neutralId]={
     alive=m.Parent~=nil and h~=nil and h.Health>0,
     friendlyOwnerId=rec.ownerId,epoch=curseEpoch,
    }
   end
   for ownerId,state in pairs(curseStates) do
    local user=Players:GetPlayerByUserId(tonumber(ownerId) or -1)
    local current=currentZombie(user)
    local actions=CurseConversionPolicy.step(state,now,{
     epoch=curseEpoch,ownerId=ownerId,phase=session.rules.phase,
     ownerAlive=current,avatarCurrent=current,neutrals=snapNeutrals,
    })
    for _,action in ipairs(actions) do
     local model=neutralById[action.targetId]
     if action.kind=="RELEASE" and model then
      releaseCharmed(model)
     elseif action.kind=="ORDER" and model and charmedByModel[model] then
      local rec=charmedByModel[model]
      local root=model.PrimaryPart
      local ownerRoot=user and user.Character and user.Character:FindFirstChild("HumanoidRootPart")
      if root and ownerRoot and ownerRoot:IsA("BasePart") then
       local goal:Vector3=ownerRoot.Position
       if action.order=="GUARD" then goal=rec.guardPoint end
       if action.order=="FOCUS" and action.focusId then
        local focus=neutralById[action.focusId]
        if focus and focus.PrimaryPart and not charmedByModel[focus] then
         goal=focus.PrimaryPart.Position
        end
       end
       local delta=Vector3.new(goal.X-root.Position.X,0,goal.Z-root.Position.Z)
       if delta.Magnitude>4 then
        local step=delta.Unit*math.min(3.3,delta.Magnitude-4)
        local ray=RaycastParams.new()
        ray.FilterType=Enum.RaycastFilterType.Exclude
        ray.FilterDescendantsInstances={all}
        ray.RespectCanCollide=true
        if not workspace:Raycast(root.Position+Vector3.new(0,1,0),step,ray) then
         local next=root.Position+step
         -- Same #819 ground safety as unconverted neutrals; never ghost/float across void.
         local scale=(root.Size.Y/2.5)
         local ground=workspace:Raycast(next+Vector3.new(0,3,0),Vector3.new(0,-8,0),ray)
         if ground and ground.Normal.Y>=.72 then
          local desiredY=ground.Position.Y+2*scale
          if math.abs(desiredY-root.Position.Y)<=1.4 then
           local grounded=Vector3.new(next.X,desiredY,next.Z)
           model:PivotTo(CFrame.lookAt(grounded,grounded+delta.Unit))
          end
         end
        end
       end
       if now-(lastCharmAttack[model] or -100)>=1.2 then
        -- Same Swarm strike, same 24-target and ray caps, no extra writer.
        local dealt=strike(ownerId,root.Position,5,7,
         root.Position+Vector3.new(0,1,0),model,"CIRCLE")
        -- Charge cadence for every authorized attempt, including an empty swing.
        -- Otherwise up to 3 allies raycast every .38s on low-end Android.
        lastCharmAttack[model]=now
       end
      end
     end
    end
   end
   task.wait(.38)
  end
  for model in pairs(charmedByModel) do releaseCharmed(model) end
  for _,state in pairs(curseStates) do CurseConversionPolicy.retire(state) end
 end)
 print("[EGGRUMBLE_SWARM] attached to actual two-mode preview; live neutral cap",LIMIT,
  "KO counts are real deaths, not multiplier rewards")
 return api
end
return Swarm
