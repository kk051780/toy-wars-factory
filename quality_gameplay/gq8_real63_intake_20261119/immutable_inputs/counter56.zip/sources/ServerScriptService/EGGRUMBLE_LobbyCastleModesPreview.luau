--!strict
-- EGGRUMBLE V3 private Studio-only: two queue gates, AI fill, multi-egg, castle-elimination match.
-- Requires a sibling ModuleScript named EGGRUMBLE_CastleMatchRules, containing that file's source.
-- Play ALONE in a separate private Place; no production Game/Store/Remote/paid products.
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local Debris=game:GetService("Debris")
if not RunService:IsStudio() then return end
local Rules=require(script.Parent:WaitForChild("EGGRUMBLE_CastleMatchRules"))
local SiegeBridge=require(script.Parent:WaitForChild("EGGRUMBLE_CastleSiegeBridge"))
local GuardianRuntime=require(script.Parent:WaitForChild("EGGRUMBLE_CastleGuardianRuntime"))
local DropBounds=(function()
-- GQ FIELD-EGG-RECOVERY V1. Pure server-side TEAM/BR drop position policy.
-- Source-only candidate. No egg counts, attribution, remotes, item effects, or currency.
local Drop={}
local WORLD_X={TEAM=-620,BATTLE_ROYALE=620}
local HALF_X=445
local HALF_Z=525
local CENTER_Z=465
local MARGIN=40 -- protects all 3 released-egg parts, each shifted at most 3 studs

local function finite(value:any):boolean
 return type(value)=="number" and value==value and value~=math.huge and value~=-math.huge
end
local function clamp(value:number,low:number,high:number):number
 return math.max(low,math.min(value,high))
end

function Drop.recover(mode:string,rootX:number,rootZ:number,
 impactX:any,impactZ:any,homeX:any,homeZ:any):any
 local offset=WORLD_X[mode]
 assert(offset~=nil,"unknown TEAM/BR mode")
 assert(finite(rootX) and finite(rootZ),"invalid server world root")
 local centerX=rootX+offset
 local centerZ=rootZ+CENTER_Z
 local minX=centerX-HALF_X+MARGIN
 local maxX=centerX+HALF_X-MARGIN
 local minZ=centerZ-HALF_Z+MARGIN
 local maxZ=centerZ+HALF_Z-MARGIN
 -- The fall may have destroyed the character root before the Died callback.
 -- Fallback is exclusively the server's own preexisting castle coordinate.
 local x=if finite(impactX) then impactX
  elseif finite(homeX) then homeX else centerX
 local z=if finite(impactZ) then impactZ
  elseif finite(homeZ) then homeZ else centerZ
 local finalX=clamp(x,minX,maxX)
 local finalZ=clamp(z,minZ,maxZ)
 return {x=finalX,z=finalZ,corrected=finalX~=impactX or finalZ~=impactZ,
  minX=minX,maxX=maxX,minZ=minZ,maxZ=maxZ}
end
return Drop
end)()
local BotActors=require(script.Parent:WaitForChild("EGGRUMBLE_BotActors"))
local CastleDefense=(function()
local Policy=(function()
-- EGGRUMBLE V3 isolated personal-castle defense policy.
-- Pure Luau: this file does not create Game, Remote, DataStore or paid advantages.
local Policy={}
Policy.TICK_SECONDS=0.35
Policy.MAX_CASTLES=16
Policy.CONFIG={
 TURRET={cooldown=2.4,range=35,damage=12,needsLOS=true},
 TRAP={cooldown=7.0,range=9,damage=8,needsLOS=true},
 SENSOR={cooldown=1.0,range=30,damage=0,needsLOS=false},
}
Policy.ORDER={"SENSOR","TRAP","TURRET"}

local function finite(n:any):boolean
 return type(n)=="number" and n==n and n~=math.huge and n~=-math.huge
end

function Policy.hasModule(owner:any,kind:string):boolean
 if not owner or not Policy.CONFIG[kind] then return false end
 for _,name in ipairs(owner.modules or {}) do
  if name==kind then return true end
 end
 return false
end

function Policy.canTarget(mode:string,owner:any,intruder:any):boolean
 if mode~="TEAM" and mode~="BATTLE_ROYALE" then return false end
 if not owner or not intruder or owner.id==nil or intruder.id==nil then return false end
 if owner.alive~=true or intruder.alive~=true or tostring(owner.id)==tostring(intruder.id) then return false end
 if mode=="TEAM" then
  if (owner.team~="RED" and owner.team~="BLUE")
   or (intruder.team~="RED" and intruder.team~="BLUE") then return false end
  if owner.team==intruder.team then return false end
 end
 return true
end

function Policy.mayActivate(kind:string,phase:string,now:number,last:number?,
 distance:number,hasLOS:boolean):boolean
 local config=Policy.CONFIG[kind]
 if not config or phase~="ACTIVE" then return false end
 if not finite(now) or not finite(distance) or distance<0 or distance>config.range then return false end
 if last~=nil and (not finite(last) or now<last or now-last<config.cooldown) then return false end
 return not config.needsLOS or hasLOS==true
end

-- Transparent Assassin bypasses automatic turret/trap targeting until detected.
-- The SENSOR is a counterpick and fires only against genuinely invisible human heroes.
function Policy.canAcquire(kind:string,now:number,stealthUntil:any):boolean
 if not Policy.CONFIG[kind] or not finite(now) or not finite(stealthUntil) then return false end
 local invisible=stealthUntil>now
 if kind=="SENSOR" then return invisible end
 return not invisible
end

return Policy
end)()
-- EGGRUMBLE V3 PERSONAL-CASTLE live defense; isolated optional SOURCE candidate.
-- Integrate once into the EXISTING author-owned V3 session after BotActors.start().
-- This module never creates a parallel Game, damage Remote, currency or paid product.
local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local Debris=game:GetService("Debris")
local Defense={}

local OFFSETS={
 TURRET=Vector3.new(19,6,-18),
 TRAP=Vector3.new(0,1,-30),
 SENSOR=Vector3.new(-19,4,-18),
}
local COLORS={
 TURRET=Color3.fromRGB(251,148,71),
 TRAP=Color3.fromRGB(181,102,241),
 SENSOR=Color3.fromRGB(84,220,210),
}

local function aliveTarget(session:any,id:string):(Model?,Humanoid?,BasePart?,Player?)
 local c=session.rules.castles[id]
 if not c or not c.alive then return nil,nil,nil,nil end
 local model:Model?=nil
 local player:Player?=nil
 if c.isAI then
  model=session.botActors and session.botActors[id] or nil
 else
  local userId=tonumber(id)
  player=userId and Players:GetPlayerByUserId(userId) or nil
  -- GQ8_CASTLE_DEFENSE_CURRENT_HUMAN_20261117
  -- Do not acquire a human who left/rejoined this specific round.
  if not player or type(session.isCurrentHuman)~="function"
   or session.isCurrentHuman(player)~=true then
   return nil,nil,nil,nil
  end
  model=player and player.Character or nil
 end
 local h=model and model:FindFirstChildOfClass("Humanoid")
 local at=model and model:FindFirstChild("HumanoidRootPart")
 if not h or h.Health<=0 or not at or not at:IsA("BasePart") then
  return nil,nil,nil,nil
 end
 return model,h,at,player
end

local function clearRay(from:Vector3,point:Vector3,model:Model,defenseFolder:Instance):boolean
 local direction=point-from
 if direction.Magnitude<=0.01 then return true end
 local params=RaycastParams.new()
 params.FilterType=Enum.RaycastFilterType.Exclude
 params.FilterDescendantsInstances={model,defenseFolder}
 params.RespectCanCollide=true
 return workspace:Raycast(from,direction,params)==nil
end

local function pulse(parent:Instance,pos:Vector3,color:Color3)
 local ring=Instance.new("Part")
 ring.Name="DefenseImpact"
 ring.Shape=Enum.PartType.Ball;ring.Anchored=true
 ring.CanCollide=false;ring.CanTouch=false;ring.CanQuery=false
 ring.Material=Enum.Material.Neon;ring.Color=color;ring.Transparency=.42
 ring.Size=Vector3.new(4,4,4);ring.Position=pos;ring.Parent=parent
 Debris:AddItem(ring,.22)
end

local function snare(session:any,model:Model,hum:Humanoid,now:number,isAI:boolean)
 local expires=now+1.1
 if isAI then
  -- Reuse the original BotActors speed-reduction contract.
  model:SetAttribute("EGGRUMBLE_SlowUntil",
   math.max(model:GetAttribute("EGGRUMBLE_SlowUntil") or 0,expires))
  return
 end
 -- Reuse original SevenRoleCombat slow attributes rather than create an
 -- independent speed authority. RoundReplay clears these after the match.
 local previous=hum:GetAttribute("EGGRUMBLE_OriginalWalkSpeed")
 local base=if type(previous)=="number" and previous>=8 and previous<=32
  then previous else hum.WalkSpeed
 if type(base)~="number" or base<8 or base>32 then return end
 hum:SetAttribute("EGGRUMBLE_OriginalWalkSpeed",base)
 hum:SetAttribute("EGGRUMBLE_SlowExpiry",
  math.max(hum:GetAttribute("EGGRUMBLE_SlowExpiry") or 0,expires))
 hum.WalkSpeed=math.max(8,math.min(hum.WalkSpeed,base*.72))
 task.delay(1.2,function()
  -- A delayed callback must not overwrite a new round's movement baseline.
  if session.rules.phase=="ACTIVE" and session.world.Parent
   and hum.Parent and hum.Health>0
   and os.clock()>=(hum:GetAttribute("EGGRUMBLE_SlowExpiry") or math.huge)
   and hum:GetAttribute("EGGRUMBLE_OriginalWalkSpeed")==base then
   hum.WalkSpeed=base
   hum:SetAttribute("EGGRUMBLE_OriginalWalkSpeed",nil)
  end
 end)
end

local function defenseAnchor(parent:Instance,kind:string,origin:Vector3):BasePart
 local p=Instance.new("Part")
 p.Name="CastleDefense_"..kind
 p.Size=if kind=="TRAP" then Vector3.new(5,.65,5) else Vector3.new(3.5,3.5,3.5)
 p.Shape=if kind=="TRAP" then Enum.PartType.Block else Enum.PartType.Ball
 p.Material=Enum.Material.Neon;p.Color=COLORS[kind];p.Transparency=.16
 p.Anchored=true;p.CanCollide=false;p.CanTouch=false;p.CanQuery=false
 p.Position=origin+OFFSETS[kind]
 p.Parent=parent
 return p
end

function Defense.start(session:any):()->()
 assert(RunService:IsStudio(),"castle defense preview may only run in private Studio")
 assert(session and session.rules and session.world and session.castleLocations
  and session.castleModels,"existing castle match required")
 assert(#session.roster<=Policy.MAX_CASTLES,"mobile hero/defense budget exceeded")
 local folder=Instance.new("Folder")
 folder.Name="EGGRUMBLE_CastleDefenseLive";folder.Parent=session.world
 local stations:{[string]:{[string]:BasePart}}={}
 local last:{[string]:{[string]:number}}={}
 local active=true
 for id,owner in pairs(session.rules.castles) do
  local castle=session.castleModels[id]
  local origin=session.castleLocations[id]
  if origin and castle and castle.model and castle.model.Parent then
   local available:{[string]:BasePart}={}
   for _,kind in ipairs(Policy.ORDER) do
    if Policy.hasModule(owner,kind) then
     available[kind]=defenseAnchor(folder,kind,origin)
    end
   end
   stations[id]=available
   last[id]={}
  end
 end
 local function stillRunning():boolean
  return active and folder.Parent~=nil and session.world.Parent~=nil
   and session.rules.phase=="ACTIVE"
 end
 local function tickOne(id:string,owner:any,kind:string,part:BasePart,now:number)
  if not owner.alive or not part.Parent or not Policy.hasModule(owner,kind) then return end
  local closest:{id:string,model:Model,hum:Humanoid,root:BasePart,player:Player?}?=nil
  local best=math.huge
  -- Source-locked same-session roster only; never scan unrelated match folders.
  for enemyId,enemy in pairs(session.rules.castles) do
   if Policy.canTarget(session.mode,owner,enemy) then
    local model,hum,root,player=aliveTarget(session,enemyId)
    if model and hum and root then
     local distance=(root.Position-part.Position).Magnitude
     if distance<=Policy.CONFIG[kind].range
      and (distance<best or (distance==best and closest and enemyId<closest.id)) then
      local los=kind=="SENSOR" or clearRay(part.Position,root.Position,model,folder)
      if Policy.mayActivate(kind,"ACTIVE",now,last[id][kind],distance,los) then
       local stealthUntil=player and (player:GetAttribute("EGGRUMBLE_StealthUntil") or 0) or 0
       if Policy.canAcquire(kind,now,stealthUntil) then
        best=distance
        closest={id=enemyId,model=model,hum=hum,root=root,player=player}
       end
      end
     end
    end
   end
  end
  if not closest or not stillRunning() or not owner.alive then return end
  local targetState=session.rules.castles[closest.id]
  if not targetState or not Policy.canTarget(session.mode,owner,targetState)
   or closest.hum.Health<=0 then return end
  -- Recheck membership immediately before damage or sensor state mutation.
  -- A human can change rounds between target selection and attack.
  if closest.player and (type(session.isCurrentHuman)~="function"
   or session.isCurrentHuman(closest.player)~=true) then return end
  -- The moment of effect is the only point that consumes the per-castle cooldown.
  last[id][kind]=now
  if kind=="SENSOR" then
   local p=closest.player
   if p then
    p:SetAttribute("EGGRUMBLE_StealthUntil",now)
    p:SetAttribute("EGGRUMBLE_SensorPingUntil",now+1.5)
   end
  else
   closest.hum:TakeDamage(InvulRuntime.filterDamage(closest.hum,Policy.CONFIG[kind].damage,"ENVIRONMENT","LOBBY_HAZARD"))
   if kind=="TRAP" and closest.hum.Health>0 then
    snare(session,closest.model,closest.hum,now,targetState.isAI==true)
   end
  end
  pulse(folder,closest.root.Position,COLORS[kind])
 end
 task.spawn(function()
  while stillRunning() do
   local now=os.clock()
   for id,kinds in pairs(stations) do
    local state=session.rules.castles[id]
    if state and state.alive then
     for _,kind in ipairs(Policy.ORDER) do
      local p=kinds[kind]
      if p and stillRunning() then tickOne(id,state,kind,p,now) end
     end
    end
   end
   task.wait(Policy.TICK_SECONDS)
  end
  if folder.Parent then folder:Destroy() end
 end)
 local function stop()
  active=false
  if folder.Parent then folder:Destroy() end
 end
 session.castleDefenseStop=stop
 return stop
end

return Defense
end)()

local SwarmCombat=require(script.Parent:WaitForChild("EGGRUMBLE_SwarmCombat"))
local InteractionGuard=require(script.Parent:WaitForChild("EGGRUMBLE_InteractionGuard"))
local ResultService=require(script.Parent:WaitForChild("EGGRUMBLE_MatchResultService"))
local RoundReplay=require(script.Parent:WaitForChild("EGGRUMBLE_RoundReplay"))
local CarrierWorldTell=(function()
local Policy=(function()
-- Independent, pure server-truth policy. No Game, UI, attack, rewards or Remote calls.
local Policy = {}
Policy.MAX_CARRIED_EGGS = 3
Policy.MAX_WORLD_VIEW_DISTANCE = 70
Policy.POLL_SECONDS = 0.3

Policy.ARENA_HALO_STUDS = 10

-- The original V3 author places TEAM and BR battlefields 1240 studs apart,
-- each at X width 890. Check their REAL field part bounds rather than trusting
-- the player's present Character (which can be teleported to lobby/other mode).
-- This is purely a read-only display gate, never a physics/egg-gameplay rule.
function Policy.inArenaXZ(x:any, z:any, centerX:any, centerZ:any, sizeX:any, sizeZ:any):boolean
 if type(x) ~= "number" or type(z) ~= "number"
  or type(centerX) ~= "number" or type(centerZ) ~= "number"
  or type(sizeX) ~= "number" or type(sizeZ) ~= "number" then return false end
 if x ~= x or z ~= z or centerX ~= centerX or centerZ ~= centerZ
  or sizeX ~= sizeX or sizeZ ~= sizeZ then return false end
 if sizeX <= 0 or sizeZ <= 0 then return false end
 local halo = Policy.ARENA_HALO_STUDS
 return math.abs(x - centerX) <= sizeX / 2 + halo
  and math.abs(z - centerZ) <= sizeZ / 2 + halo
end

function Policy.shouldShow(phase:string?, winner:any, castle:any, avatarAlive:boolean):boolean
 if phase ~= "ACTIVE" or winner ~= nil or avatarAlive ~= true then return false end
 if type(castle) ~= "table" or castle.alive ~= true then return false end
 local eggs = castle.heldEggs
 return type(eggs) == "number" and eggs == eggs and eggs%1 == 0
  and eggs >= 1 and eggs <= Policy.MAX_CARRIED_EGGS
end

function Policy.caption(eggs:number):string
 assert(type(eggs) == "number" and eggs%1 == 0 and eggs >= 1 and eggs <= 3, "invalid carried eggs")
 return "🥚×"..tostring(eggs)
end
return Policy
end)()
-- Optional V3 PRIVATE GAME enhancement: real, server-derived carried-egg tell.
-- Unique ownership: quality_gameplay/carrier_world_tell_20261116 only.
-- No changes to author-owned Game, UI, roles, bot/neutral AI, inventory, damage or score.
local Players = game:GetService("Players")
local Tell = {}

local function actorFor(session:any, entry:any):Model?
 local bots = session.botActors
 local bot = bots and bots[entry.id]
 if bot and bot:IsA("Model") then return bot end
 if entry.isAI then return nil end
 local userId = tonumber(entry.id)
 local player = userId and Players:GetPlayerByUserId(userId)
 return player and player.Character or nil
end

local function destroyRecord(record:any)
 if record and record.gui then
  -- Destroy even if a different script already detached the Gui. This is
  -- a read-only cosmetic leaf: never leave a stale disconnected instance.
  record.gui:Destroy()
 end
end

local function makeBillboard(root:BasePart, team:string?, aiActor:boolean):(BillboardGui,TextLabel)
 local gui = Instance.new("BillboardGui")
 gui.Name = "EGGRUMBLE_CarrierWorldTell"
 gui.Adornee = root
 gui.AlwaysOnTop = false -- preserve solid cover; never a global wallhack.
 gui.MaxDistance = Policy.MAX_WORLD_VIEW_DISTANCE
 gui.Size = UDim2.fromOffset(88, 27)
 -- The author bot actor already owns a 180x50 BotObjective billboard at
 -- head (root + 2.25 studs) + 3.3 studs. Do not stack another count
 -- directly into that 5.55-stud band; humans keep the near-head marker.
 gui.StudsOffsetWorldSpace = Vector3.new(0, if aiActor then 10.2 else 4, 0)
 local text = Instance.new("TextLabel")
 text.Name = "Count"
 text.Size = UDim2.fromScale(1,1)
 text.BackgroundTransparency = 0.22
 text.BorderSizePixel = 0
 text.TextScaled = true
 text.Font = Enum.Font.GothamBold
 text.TextColor3 = Color3.fromRGB(255,250,203)
 text.BackgroundColor3 = if team=="RED" then Color3.fromRGB(112,44,47)
  elseif team=="BLUE" then Color3.fromRGB(38,66,119)
  else Color3.fromRGB(79,61,101)
 text.Parent = gui
 gui.Parent = root
 return gui,text
end

function Tell.start(session:any):boolean
 assert(session and session.world and session.rules and session.roster, "server match session required")
 if session._carrierWorldTellStarted then return false end
 -- Server-only optional RC rollback switch. false means do not start; nil keeps
 -- existing preview behavior. Never derive this state from a client Remote.
 if session.carrierWorldTellEnabled == false then return false end
 if session.rules.phase ~= "ACTIVE" or session.rules.winner ~= nil then return false end
 -- Author-owned V3 field part is the one physical arena identity. If missing,
 -- fail closed: never emit a guessed badge in the lobby or another mode.
 local field = session.world:FindFirstChild("TacticalBattlefield")
 if not field or not field:IsA("BasePart")
  or field.Parent ~= session.world then return false end
 session._carrierWorldTellStarted = true
 local records:{[string]:any} = {}
 local faulted:{[string]:boolean} = {}
 task.spawn(function()
  -- This is optional visual QA. A malformed/replaced actor Model must not
  -- leave the session stuck "started" or leak labels into future rounds.
  -- Catch faults INSIDE our own spawned observer, then always clean up.
  local ok, observerError = pcall(function()
   while session.world.Parent ~= nil and field.Parent == session.world
   and session.rules.phase == "ACTIVE" and session.rules.winner == nil
   and session.carrierWorldTellEnabled ~= false do
   -- The host can alter its current participants before a whole world is
   -- retired. Never leave an old avatar billboard for a seat no longer
   -- present in the match's CURRENT server roster.
   local activeIds:{[string]:boolean} = {}
   for _,entry in ipairs(session.roster) do
    local id = tostring(entry.id)
    activeIds[id] = true
    -- One malformed avatar must not blank the other 15 player markers.
    -- Isolate its cosmetic inspection, not the original game/Rules code.
    local seatOk,seatError = pcall(function()
    local castle = session.rules.castles[id]
    local actor = actorFor(session,entry)
    local root = actor and actor:FindFirstChild("HumanoidRootPart")
    local humanoid = actor and actor:FindFirstChildOfClass("Humanoid")
    local rootPart = if root and root:IsA("BasePart") then root else nil
    local alive = humanoid ~= nil and humanoid.Health > 0 and rootPart ~= nil
    local withinThisArena = rootPart ~= nil and Policy.inArenaXZ(
     rootPart.Position.X, rootPart.Position.Z,
     field.Position.X, field.Position.Z, field.Size.X, field.Size.Z)
    local visible = Policy.shouldShow(
     session.rules.phase,session.rules.winner,castle,alive and withinThisArena)
    local old = records[id]
    if not visible or not rootPart then
     if old then destroyRecord(old);records[id]=nil end
    else
     if old and (old.root ~= rootPart
      or old.gui.Parent ~= rootPart or old.gui.Adornee ~= rootPart
      or old.label.Parent ~= old.gui) then
      -- External appearance cleanup can remove/reparent only this billboard
      -- while the avatar and heldEggs remain unchanged. Recreate it once;
      -- never reset item amounts, match time or other game state.
      destroyRecord(old);old=nil;records[id]=nil
     end
     if not old then
      -- Actor may be a takeover bot even when the original roster was human.
      local botModel = session.botActors and session.botActors[entry.id]
      local gui,label = makeBillboard(rootPart,castle.team,botModel == actor)
      old = {root=rootPart,gui=gui,label=label,count=0}
      records[id] = old
     end
     -- Restore only cosmetic invariants if another server-side visual
     -- system modified them. A count cache alone would leave a misleading
     -- label after text edits; AlwaysOnTop/MaxDistance drift can reveal an
     -- objective through walls or from across the map.
     if old.gui.AlwaysOnTop ~= false then old.gui.AlwaysOnTop = false end
     if old.gui.MaxDistance ~= Policy.MAX_WORLD_VIEW_DISTANCE then
      old.gui.MaxDistance = Policy.MAX_WORLD_VIEW_DISTANCE
     end
     if old.gui.Enabled == false then old.gui.Enabled = true end
     if old.label.Visible == false then old.label.Visible = true end
     local caption = Policy.caption(castle.heldEggs)
     if old.count ~= castle.heldEggs or old.label.Text ~= caption then
      old.label.Text = caption
      old.count = castle.heldEggs
     end
    end
    end)
    if seatOk then
     faulted[id] = nil
    else
     local damaged = records[id]
     if damaged then
      -- Never let a broken cosmetic Instance abort other seats' inspection.
      pcall(destroyRecord,damaged)
      records[id] = nil
     end
     if not faulted[id] then
      faulted[id] = true
      warn("[GQ511] optional carrier actor label isolated: "..tostring(seatError))
     end
    end
   end
   -- Purge retired roster slots, including their one-per-failure warning
   -- state. Only this optional cosmetic state is cleaned; original castle,
   -- egg, item, death, AI and match ownership are authoritative elsewhere.
   for id,record in pairs(records) do
    if not activeIds[id] then
     pcall(destroyRecord,record)
     records[id] = nil
    end
   end
   for id in pairs(faulted) do
    if not activeIds[id] then faulted[id] = nil end
   end
   task.wait(Policy.POLL_SECONDS)
   end
  end)
  -- The battlefield can be removed BEFORE the parent arena is removed.
  -- A detached or reparented floor also ends the visual loop and scrubs all
  -- character-root labels, without changing the actual match/egg economy.
  -- Human avatars survive the arena; never leak a label into lobby/another mode.
  for _,record in pairs(records) do destroyRecord(record) end
  session._carrierWorldTellStarted = nil
  if not ok then
   -- Distinct from original engine errors; never change game Rules or attempt
   -- a silent restart of an optional UI when its dependencies are unhealthy.
   warn("[GQ511] optional carrier label observer stopped safely: "..tostring(observerError))
  end
 end)
 return true
end

return Tell
end)()

-- MATCH_DEADLINE_DRAW_499 BEGIN ORIGINAL #499 POLICY (signed blob 7d1b2dd8d341164a2d8759d5511d7aecaeedfdfa)
-- EGGRUMBLE V3, pure server-side timeout boundary. Not production-wired.
-- Reuse the existing Rules state and RoundReplay; never create a second match.
local Deadline={}
Deadline.DEFAULT_SECONDS=900

local function timeOK(t:any):boolean
 return type(t)=="number" and t==t and t>=0 and t<math.huge
end

function Deadline.new(startedAt:number,matchId:string,seconds:number?):any
 assert(timeOK(startedAt),"invalid monotonic start")
 assert(type(matchId)=="string" and #matchId>0,"invalid match identity")
 local duration=seconds or Deadline.DEFAULT_SECONDS
 assert(timeOK(duration) and duration%1==0 and duration>=60 and duration<=3600,"invalid duration")
 return {start=startedAt,matchId=matchId,seconds=duration,consumed=false}
end

local function survivingSides(state:any):number
 if type(state.castles)~="table" then return 0 end
 local sides={}
 for id,castle in pairs(state.castles) do
  if type(castle)=="table" and castle.alive==true then
   local side=if state.mode=="TEAM" then castle.team else id
   if type(side)=="string" and #side>0 then sides[side]=true end
  end
 end
 local total=0
 for _ in pairs(sides) do total+=1 end
 return total
end

function Deadline.check(state:any,lease:any,now:number,matchId:string):(boolean,string)
 if type(state)~="table" or type(lease)~="table" then return false,"INVALID_STATE" end
 if lease.consumed==true then return false,"ALREADY_APPLIED" end
 if state.mode~="TEAM" and state.mode~="BATTLE_ROYALE" then return false,"INVALID_MODE" end
 if type(matchId)~="string" or matchId~=lease.matchId then return false,"STALE_MATCH" end
 if state.phase~="ACTIVE" or state.winner~=nil then return false,"ALREADY_FINISHED" end
 if type(state.events)~="table" or survivingSides(state)<2 then return false,"NO_CONTEST" end
 if not timeOK(now) or not timeOK(lease.start) or not timeOK(lease.seconds)
  or now<lease.start then return false,"INVALID_CLOCK" end
 if now-lease.start<lease.seconds then return false,"BEFORE_DEADLINE" end
 return true,"TIME_LIMIT"
end

-- Fallback DRAW only when neither side has legitimately won. A true
-- all-castles victory continues to be decided by the original CastleMatchRules.
-- The original ResultService/Replay sees a normal FINISHED round; no castle
-- HP, egg inventory, team deposits, individual KOs, or rewards are fabricated.
function Deadline.expire(state:any,lease:any,now:number,matchId:string):(boolean,string)
 local allowed,reason=Deadline.check(state,lease,now,matchId)
 if not allowed then return false,reason end
 lease.consumed=true
 state.winner="DRAW"
 state.phase="FINISHED"
 table.insert(state.events,{type="TIME_LIMIT_DRAW",mode=state.mode,matchId=matchId,
  elapsed=math.floor(now-lease.start)})
 return true,"TIME_LIMIT_DRAW"
end

-- MATCH_DEADLINE_DRAW_499 END ORIGINAL POLICY
local SevenRoleCombat=require(script.Parent:WaitForChild("EGGRUMBLE_SevenRoleCombat"))
local InvulRuntime=require(script.Parent:WaitForChild("EGGRUMBLE_InvulRuntime"))
local NaturalRegen=require(script.Parent:WaitForChild("EGGRUMBLE_NaturalRegen"))
-- GQ522_ORIGINAL_BUILDER_WALL_ONLY_INLINE_RC31
local BuilderConstruction
do
-- Pure numeric checks used by the server-only BUILDER construction ability.
-- No service, damage, score, data store, remote, or Roblox instance authority.
local Policy={}
Policy.LIFETIME=9
Policy.MAX_PER_HERO=2
Policy.MAX_PER_SESSION=12
Policy.CD={WALL=13,BRIDGE=17}
local function finite(n)
 return type(n)=="number" and n==n and n<math.huge and n>-math.huge
end
function Policy.capacity(total,own)
 return finite(total) and finite(own) and total>=0 and own>=0
  and total<Policy.MAX_PER_SESSION and own<Policy.MAX_PER_HERO
end
function Policy.cooldown(kind,now,last)
 return Policy.CD[kind]~=nil and finite(now) and finite(last)
  and now-last>=Policy.CD[kind]
end
function Policy.inField(x,z,halfX,halfZ)
 return finite(x) and finite(z) and finite(halfX) and finite(halfZ)
  and halfX>24 and halfZ>24
  and math.abs(x)<halfX-24 and math.abs(z)<halfZ-24
end
function Policy.support(nearY,farY,originY)
 return finite(nearY) and finite(farY) and finite(originY)
  and math.abs(nearY-originY)<=7 and math.abs(farY-originY)<=7
  and math.abs(nearY-farY)<=3
end
function Policy.safeDistance(distance)
 return finite(distance) and distance>=51
end
-- Bridge is for crossing an actual gap or lowered crossing, never flat grass.
-- Require both anchor banks via Policy.support; midpoint must be missing or
-- at least 4 studs below the LOWER bank. NaN/inf fails closed.
function Policy.bridgeGap(midY,lowerBankY)
 if not finite(lowerBankY) then return false end
 if midY==nil then return true end
 return finite(midY) and lowerBankY-midY>=4
end
-- Global overlap must catch noncollidable Humanoids and foreign copied floors.
-- Fail closed for unknown CanCollide state.
function Policy.blocksPlacement(canCollide,ownGround,isHumanoid)
 return isHumanoid==true or (canCollide~=false and ownGround~=true)
end
-- EGGRUMBLE V3: independent, server-only, default-OFF temporary wall/bridge.
-- #482 author owns Game/Combat; #220 alone owns formal RC integration.
-- No Remote, DataStore, score, damage, egg, or alternative Game introduced.
local Players=game:GetService("Players")
-- GQ522 Policy is inlined below (original source preserved)
local Build={}
Build.DEFAULT_ENABLED=false
local bySession:{[any]:any}=setmetatable({},{__mode="k"})

local function getActor(session:any,p:Player):(Model?,BasePart?)
 if typeof(session)~="table" or typeof(session.rules)~="table"
  or session.rules.phase~="ACTIVE" or session.rules.winner~=nil
  or not session.world or not session.world.Parent then return nil,nil end
 if typeof(session.mode)~="string" or (session.mode~="TEAM" and session.mode~="BATTLE_ROYALE") then return nil,nil end
 if not p or p.Parent~=Players or Players:GetPlayerByUserId(p.UserId)~=p then return nil,nil end
 if p:GetAttribute("EGGRUMBLE_Role")~="BUILDER"
  or p:GetAttribute("EGGRUMBLE_Eliminated")==true
  or p:GetAttribute("EGGRUMBLE_QueuedMode")~=session.mode then return nil,nil end
 local owner=session.rules.castles and session.rules.castles[tostring(p.UserId)]
 if not owner or owner.isAI or not owner.alive or (owner.heldEggs or 0)>0 then return nil,nil end
 local present=false
 for _,entry in ipairs(session.roster or {}) do
  if tostring(entry.id)==tostring(p.UserId) and entry.isAI==false then present=true;break end
 end
 if not present then return nil,nil end
 -- Reuse the original #531 Host live-match identity fence. An old roster/castle
 -- can survive a same-mode rejoin; queued mode and role alone are insufficient.
 if typeof(session.isCurrentHuman)~="function" then return nil,nil end
 local membershipOK,currentHuman=pcall(session.isCurrentHuman,p)
 if not membershipOK or currentHuman~=true then return nil,nil end
 local char=p.Character
 local humanoid=char and char:FindFirstChildOfClass("Humanoid")
 local root=char and char:FindFirstChild("HumanoidRootPart")
 if not char or not humanoid or humanoid.Health<=0
  or not root or not root:IsA("BasePart") then return nil,nil end
 return char,root
end

local function fieldContains(session:any,pos:Vector3):boolean
 local field=session.world:FindFirstChild("TacticalBattlefield")
 if not field or not field:IsA("BasePart") then return false end
 local p=field.CFrame:PointToObjectSpace(pos)
 return Policy.inField(p.X,p.Z,field.Size.X/2,field.Size.Z/2)
end

local function groundAt(session:any,at:Vector3):(Vector3?,BasePart?)
 local params=RaycastParams.new()
 params.FilterType=Enum.RaycastFilterType.Include
 params.FilterDescendantsInstances={session.world}
 params.RespectCanCollide=true
 params.IgnoreWater=true
 local hit=workspace:Raycast(at+Vector3.new(0,16,0),Vector3.new(0,-50,0),params)
 if not hit or not hit.Instance:IsA("BasePart") or not hit.Instance.CanCollide then return nil,nil end
 local part=hit.Instance
 -- Do not build on players, castles, roofs, movable items or an existing temporary bridge.
 if part.Name~="TacticalBattlefield" and not part.Name:match("^TacticalRoute_")
  and part.Name~="ValleyOverlook" then return nil,nil end
 return hit.Position,part
end

local function exclusion(session:any,pos:Vector3):boolean
 for _,point in pairs(session.castleLocations or {}) do
  if typeof(point)=="Vector3" and not Policy.safeDistance((point-pos).Magnitude) then return true end
 end
 local params=OverlapParams.new()
 params.FilterType=Enum.RaycastFilterType.Include
 params.FilterDescendantsInstances={session.world}
 params.MaxParts=0
 for _,other in ipairs(workspace:GetPartBoundsInRadius(pos,14,params)) do
  local n=other.Name
  if n:find("Egg") or n:find("Gate") or n:find("Vault") or n:find("FieldItem")
   or n:find("DecorStation") or n:find("Released") or n:find("PORTAL") then return true end
 end
 return false
end

local function sessionState(session:any):any
 local s=bySession[session]
 if not s then s={entries={},last={},serial=0};bySession[session]=s end
 return s
end
local function count(s:any,userId:number):(number,number)
 local total,own=0,0
 for id,entry in pairs(s.entries) do
  if not entry.part or not entry.part.Parent then
   s.entries[id]=nil
  else
   total+=1
   if entry.userId==userId then own+=1 end
  end
 end
 return total,own
end

-- Independent fallback when the original Game's closeRound hook has not been
-- connected yet. Only one heartbeat exists per real session, and only while
-- there are active constructs. It does NOT create a second Game/Remote/loop.
local function monitorSession(session:any,s:any):()
 if s.monitoring then return end
 s.monitoring=true
 local function tick()
  if bySession[session]~=s then return end
  if not session.world or not session.world.Parent or not session.rules
   or session.rules.phase~="ACTIVE" or session.rules.winner~=nil then
   -- The original author may also call clear(); both paths are idempotent.
   Build.clear(session)
   return
  end
  local total=count(s,-1)
  if total==0 then
   s.monitoring=false
   return
  end
  task.delay(0.25,tick)
 end
 task.delay(0.25,tick)
end

function Build.place(session:any,p:Player,kind:string,serverEnabled:boolean?):(boolean,string)
 -- This opt-in flag is passed ONLY by the original server-owned skill dispatcher.
 if serverEnabled~=true then return false,"FEATURE_OFF" end
 if kind~="WALL" and kind~="BRIDGE" then return false,"INVALID_KIND" end
 local char,root=getActor(session,p)
 if not char or not root then return false,"NOT_AUTHORIZED" end
 local s=sessionState(session)
 local total,own=count(s,p.UserId)
 if not Policy.capacity(total,own) then return false,"BUILD_CAP" end
 local now=os.clock()
 local key=tostring(p.UserId)..":"..kind
 if not Policy.cooldown(kind,now,s.last[key] or -100000) then return false,"COOLDOWN" end
 local forward=root.CFrame.LookVector
 local direction=Vector3.new(forward.X,0,forward.Z)
 if direction.Magnitude<0.15 then return false,"AIM_INVALID" end
 direction=direction.Unit
 local near=groundAt(session,root.Position+direction*7)
 local far=groundAt(session,root.Position+direction*(if kind=="WALL" then 12 else 24))
 if not near or not far then return false,"NO_SUPPORT" end
 if not Policy.support(near.Y,far.Y,root.Position.Y) then return false,"UNSAFE_SLOPE" end
 -- A bridge over intact grass is a useless platform, not a crossing.
 -- Validate the MIDPOINT in the same active arena, not a client-provided hit.
 -- Ground under a riverbed can be lower; an actual gap yields nil.
 if kind=="BRIDGE" then
  local middle=groundAt(session,root.Position+direction*15.5)
  if not Policy.bridgeGap(if middle then middle.Y else nil,math.min(near.Y,far.Y)) then
   return false,"NO_GAP"
  end
 end
 local center=(near+far)*0.5
 if not fieldContains(session,center) or not fieldContains(session,near)
  or not fieldContains(session,far) then return false,"FIELD_BOUNDS" end
 if exclusion(session,center) or exclusion(session,near) or exclusion(session,far) then
  return false,"OBJECTIVE_BLOCK"
 end
 local dims=if kind=="WALL" then Vector3.new(13,10,2.4) else Vector3.new(10,1.2,20)
 local cy=if kind=="WALL" then math.max(near.Y,far.Y)+dims.Y/2 else math.max(near.Y,far.Y)+0.7
 local at=Vector3.new(center.X,cy,center.Z)
 local cf=CFrame.lookAt(at,at+direction)
 -- No overlapping player models, solid obstacles, or other walls/bridges.
 local params=OverlapParams.new()
 -- Include characters parented to Workspace, not only the per-mode arena Folder.
 -- A server-owned Player character is normally NOT under session.world.
 params.FilterType=Enum.RaycastFilterType.Include
 params.FilterDescendantsInstances={workspace}
 params.MaxParts=0
 for _,other in ipairs(workspace:GetPartBoundsInBox(cf,dims+Vector3.new(1,1,1),params)) do
  -- Many Humanoid body parts are CanCollide=false; they must still block construction.
  local model=other:FindFirstAncestorOfClass("Model")
  local isHumanoid=model~=nil and model:FindFirstChildOfClass("Humanoid")~=nil
  -- Only the actual session floor/routes are exempt, never copied map objects.
  local isOwnGround=other:IsDescendantOf(session.world)
   and (other.Name=="TacticalBattlefield" or other.Name:match("^TacticalRoute_")~=nil)
  if Policy.blocksPlacement(other.CanCollide,isOwnGround,isHumanoid) then
   return false,if isHumanoid then "HUMANOID_OVERLAP" else "OBSTACLE_OR_CONSTRUCT"
  end
 end
 -- Nothing yields between the final capacity+world guards and creation.
 local part=Instance.new("Part")
 part.Name="EGGRUMBLE_BUILDER_"..kind
 part.Anchored=true;part.CanCollide=true;part.CanTouch=false;part.CanQuery=true
 part.Size=dims;part.CFrame=cf
 part.Material=if kind=="WALL" then Enum.Material.Slate else Enum.Material.WoodPlanks
 part.Color=if kind=="WALL" then Color3.fromRGB(116,133,150) else Color3.fromRGB(159,122,81)
 part:SetAttribute("EGGRUMBLE_Temporary",true)
 part:SetAttribute("EGGRUMBLE_ConstructOwner",p.UserId)
 part.Parent=session.world
 s.serial+=1
 local id=s.serial
 s.entries[id]={part=part,userId=p.UserId}
 s.last[key]=now
 task.delay(Policy.LIFETIME,function()
  local entry=s.entries[id]
  if entry then
   s.entries[id]=nil
   if entry.part and entry.part.Parent then entry.part:Destroy() end
  end
 end)
 monitorSession(session,s)
 return true,kind
end
-- Add server-owned Tool input to the ORIGINAL role system. This is not a
-- second Game or Remote: the original Host calls this after HeroCombat.equip.
-- Preserves original BUILDER A/B/C skills, including its turret.
function Build.equip(session:any,p:Player,serverEnabled:boolean?,bridgeEnabled:boolean?):(boolean,string)
 if serverEnabled~=true then return false,"FEATURE_OFF" end
 local character=getActor(session,p)
 if not character then return false,"NOT_AUTHORIZED" end
 local backpack=p:FindFirstChildOfClass("Backpack")
 if not backpack then return false,"NO_BACKPACK" end
 local prefix="EGGRUMBLE_SKILL_CONSTRUCT_"
 -- Respawn/re-equip may be called twice. Never leave old callbacks/tools live.
 for _,container in ipairs({backpack,character}) do
  for _,tool in ipairs(container:GetChildren()) do
   if tool:IsA("Tool") and string.sub(tool.Name,1,#prefix)==prefix then
    tool:Destroy()
   end
  end
 end
 -- A bridge Tool is hidden until a real authored crossing is present.
 -- WALL-only is the safe private-RC default; no misleading unusable bridge button.
 local kinds=if bridgeEnabled==true then {"WALL","BRIDGE"} else {"WALL"}
 for _,kind in ipairs(kinds) do
  local tool=Instance.new("Tool")
  tool.Name=prefix..kind
  tool.ToolTip=if kind=="WALL" then "建築士｜防壁（9秒・再使用13秒）"
   else "建築士｜橋（真の溝のみ・9秒・再使用17秒）"
  tool.RequiresHandle=false
  tool.CanBeDropped=false
  local originalCharacter=character
  tool.Activated:Connect(function()
   -- Roblox's existing Tool/equip transport is the ONLY input. No client
   -- coordinates, new Remote, duplicate HP/damage/score/Store authority.
   if p.Character~=originalCharacter or tool.Parent~=originalCharacter then return end
   Build.place(session,p,kind,true)
  end)
  tool.Parent=backpack
 end
 return true,"TOOLS_READY"
end

function Build.clear(session:any):()
 local s=bySession[session]
 if not s then return end
 for id,entry in pairs(s.entries) do
  if entry.part and entry.part.Parent then entry.part:Destroy() end
  s.entries[id]=nil
 end
 bySession[session]=nil
end

BuilderConstruction=Build
end

-- Existing ITEM author remains the one and only effect/collection implementation.
local FieldItems=require(script.Parent:WaitForChild("EGGRUMBLE_FieldItemPickups"))
local GQ802StageManifest=require(script.Parent:WaitForChild("GQ802_StageManifestPolicy"))
local GQ802StageBlueprint=require(script.Parent:WaitForChild("GQ802_StageTileBlueprintPolicy"))
local GQ802StageVisuals=require(script.Parent:WaitForChild("GQ802_StageTileVisualRenderer"))
local RaidItemIntake=require(script.Parent:WaitForChild("EGGRUMBLE_RaidItemIntake"))
local NeutralStoneGiant=require(script.Parent:WaitForChild("EGGRUMBLE_NeutralStoneGiant"))
local BossSessionFence=require(script.Parent:WaitForChild("EGGRUMBLE_BossSessionFence"))
-- GQ528 PRIVATE ON only: one shared allocation across both active match sessions.
local GQDualBudget=require(script.Parent:WaitForChild("EGGRUMBLE_DualModeNeutralBudget"))
local gqDualBudget=GQDualBudget.new(128,96,32)
local spawn=workspace:FindFirstChildWhichIsA("SpawnLocation",true)::SpawnLocation?
local root=spawn and spawn.Position or Vector3.new(0,4,0)
local folder=Instance.new("Folder");folder.Name="EGGRUMBLE_LOBBY_CASTLE_MODES_PREVIEW";folder.Parent=workspace
local queues:{[string]:{Player}}={TEAM={},BATTLE_ROYALE={}}
local sessions:{[string]:any}={}
local joined:{[number]:string}={}
local chosenDefense:{[number]:string}={}
local chosenRole:{[number]:string}={}
local queueEpoch:{[string]:number}={TEAM=0,BATTLE_ROYALE=0}
local MODE_SEATS=16 -- humans + AI combined; change only after measured server/client QA
local COUNTDOWN=12 -- seconds for private preview only
-- This is presentation state only, not a second countdown or game clock.
local queueStartedAt:{[string]:number}={}
local queueBoards:{[string]:TextLabel}={}

-- GQ646_LOBBY_SAFE_SPAWN_BEGIN: isolated from both battlefields and role/queue writers.
-- The original V3 lobby constructs gates and role stands, but no supporting floor.
local lobbyGround=Instance.new("Part")
lobbyGround.Name="GQ646_LOBBY_SAFE_GROUND"
lobbyGround.Anchored=true
lobbyGround.Size=Vector3.new(154,2,156)
lobbyGround.Position=root+Vector3.new(0,-5,21)
lobbyGround.Material=Enum.Material.Grass
lobbyGround.Color=Color3.fromRGB(88,139,104)
lobbyGround.CanCollide=true
lobbyGround.Parent=folder
local lobbySpawn=Instance.new("SpawnLocation")
lobbySpawn.Name="GQ646_LOBBY_NEUTRAL_SPAWN"
lobbySpawn.Anchored=true
lobbySpawn.Size=Vector3.new(12,1,12)
lobbySpawn.Position=root+Vector3.new(0,-2,-27)
lobbySpawn.Neutral=true
lobbySpawn.Enabled=true
lobbySpawn.AllowTeamChangeOnTouch=false
lobbySpawn.Duration=0
lobbySpawn.Material=Enum.Material.SmoothPlastic
lobbySpawn.Color=Color3.fromRGB(232,230,178)
lobbySpawn.CanCollide=true
lobbySpawn.Parent=folder
local function bindGQ646LobbyCharacter(player:Player)
 local function tryPlace(character:Model)
  task.defer(function()
   if not player.Parent or player.Character~=character then return end
   -- The match's existing respawn handler owns every in-session character.
   local mode=joined[player.UserId]
   if mode and sessions[mode] then return end
   local hrp=character:FindFirstChild("HumanoidRootPart") or character:WaitForChild("HumanoidRootPart",6)
   local humanoid=character:FindFirstChildOfClass("Humanoid")
   if not hrp or not hrp:IsA("BasePart") or not humanoid or humanoid.Health<=0 then return end
   if player.Character~=character then return end
   mode=joined[player.UserId]
   if mode and sessions[mode] then return end
   hrp.CFrame=CFrame.new(root+Vector3.new(0,5,-27))
  end)
 end
 player.CharacterAdded:Connect(tryPlace)
 if player.Character then tryPlace(player.Character) end
end
Players.PlayerAdded:Connect(bindGQ646LobbyCharacter)
for _,presentPlayer in ipairs(Players:GetPlayers()) do
 bindGQ646LobbyCharacter(presentPlayer)
end
-- GQ646_LOBBY_SAFE_SPAWN_END

local function block(parent:Instance,name:string,pos:Vector3,size:Vector3,color:Color3):Part
 local p=Instance.new("Part");p.Name=name;p.Size=size;p.Position=pos;p.Anchored=true
 p.Color=color;p.Material=Enum.Material.SmoothPlastic;p.Parent=parent
 return p
end
local function board(at:BasePart,label:string)
 local b=Instance.new("BillboardGui");b.Size=UDim2.fromOffset(230,82);b.StudsOffset=Vector3.new(0,4.5,0)
 b.AlwaysOnTop=true;b.Parent=at
 local t=Instance.new("TextLabel");t.Size=UDim2.fromScale(1,1);t.TextScaled=true;t.TextWrapped=true
 t.BackgroundColor3=Color3.fromRGB(24,27,43);t.BackgroundTransparency=.12
 t.TextColor3=Color3.new(1,1,1);t.Font=Enum.Font.GothamBold;t.Text=label;t.Parent=b
end
-- GQ539 LOBBY ONLY: preserve original world board authority and #547 castle/vault fix.
-- Reuse the existing BillboardGui; no duplicate labels, Game, Remote, or core HP logic.
local function nearbyBoard(at:BasePart,label:string,maxDistance:number):()
 board(at,label)
 local gui=at:FindFirstChildOfClass("BillboardGui")
 if not gui then return end
 gui.AlwaysOnTop=false
 gui.MaxDistance=math.clamp(maxDistance,16,52)
 gui.Size=UDim2.fromOffset(174,56)
 gui.StudsOffsetWorldSpace=Vector3.new(0,3.2,0)
 local title=gui:FindFirstChildOfClass("TextLabel")
 if title then
  title.TextScaled=false
  title.TextSize=14
  title.BackgroundTransparency=.54
 end
end
local function prompt(at:BasePart,action:string,subject:string,callback:(Player)->())
 local p=Instance.new("ProximityPrompt");p.ActionText=action;p.ObjectText=subject
 p.HoldDuration=.2;p.MaxActivationDistance=14;p.RequiresLineOfSight=false;p.Parent=at
 p.Triggered:Connect(function(actor:Player)
  -- All client-originated prompt interactions are server checked, including castle HP damage.
  if InteractionGuard.allow(actor,at,action,at.Name) then callback(actor) end
 end)
end
-- Reuse existing TEAM/BR portal BillboardGui; never create a second HUD.
local function refreshQueueBoard(mode:string)
 local label=queueBoards[mode]
 if not label then return end
 local prefix=if mode=="TEAM" then "TEAM｜味方の城を守る" else "BR｜最後の城が勝者"
 if sessions[mode] then
  label.Text=prefix.."\n試合中｜次の試合を待つ"
  return
 end
 local waiting=queues[mode]
 local count=waiting and #waiting or 0
 if count==0 then
  label.Text=prefix.."\n参加する｜1人でも開始"
  return
 end
 local started=queueStartedAt[mode] or time()
 local remaining=math.max(0,math.ceil(COUNTDOWN-math.max(0,time()-started)))
 label.Text=prefix.."\n"..count.."/"..MODE_SEATS.."人｜開始まで"..remaining.."秒"
end
local function getCastlePoint(mode:string,index:number):Vector3
 if mode=="TEAM" then
  -- Strict RED west / BLUE east castle districts. Human roster alternates team colors.
  local isRed=index%2==1
  local localIndex=math.floor((index-1)/2)
  local col=localIndex%2;local row=math.floor(localIndex/2)
  local x=if isRed then -885+col*124 else -475+col*124
  return root+Vector3.new(x,2,260+row*146)
 end
 local base=root+Vector3.new(620,2,0)
 local col=(index-1)%4;local row=math.floor((index-1)/4)
 return base+Vector3.new((col-1.5)*122,0,280+row*112)
end
-- GQ8_HUMAN_SIEGE_PACING_BEGIN
-- Only server-confirmed prompt siege is paced, per human and per target castle.
-- The table is attached to each instance of createWorldCastle, so a replay cannot inherit it.
local SIEGE_ATTACK_COOLDOWN=1.0
local function siegeAttackReady(lastByAttacker:{[string]:number},attackerId:string,now:number):boolean
 if type(now)~="number" or now~=now or now<0 or now==math.huge then return false end
 local previous=lastByAttacker[attackerId]
 return previous==nil or (now>=previous and now-previous>=SIEGE_ATTACK_COOLDOWN)
end
-- GQ8_HUMAN_SIEGE_PACING_END
local function createWorldCastle(session:any,entry:any,index:number)
 local model=Instance.new("Model");model.Name="Castle_"..entry.id;model.Parent=session.world
 local at=getCastlePoint(session.mode,index)
 session.castleLocations[entry.id]=at
 local side=if session.mode=="TEAM" then entry.team else (if index%2==1 then "RED" else "BLUE")
 local tint=if side=="RED" then Color3.fromRGB(207,92,86) else Color3.fromRGB(87,146,218)
 local ground=block(model,"StandardFoundation",at+Vector3.new(0,-2,0),Vector3.new(72,3,72),tint)
 -- Equal walkable entrance approach to every personal castle; not a strength upgrade.
 local ramp=block(model,"CastleAccessRamp",at+Vector3.new(0,-3.15,-45),
  Vector3.new(11,.8,20),Color3.fromRGB(153,145,128))
 ramp.CFrame=CFrame.new(at+Vector3.new(0,-3.15,-45))
  *CFrame.Angles(-math.atan(4.5/20),0,0)
 ramp.Material=Enum.Material.Slate
 -- Hollow, traversable standard castle shell: every owner gets the same entrance and geometry.
 local core=block(model,"StandardCore",at+Vector3.new(0,14,0),Vector3.new(30,2,27),Color3.fromRGB(172,166,147))
 core.Material=Enum.Material.Brick
 local left=block(model,"CastleSideLeft",at+Vector3.new(-15,6,0),Vector3.new(2,12,26),Color3.fromRGB(160,154,145))
 local right=block(model,"CastleSideRight",at+Vector3.new(15,6,0),Vector3.new(2,12,26),Color3.fromRGB(160,154,145))
 local back=block(model,"CastleBackWall",at+Vector3.new(0,6,13),Vector3.new(30,12,2),Color3.fromRGB(160,154,145))
 local frontL=block(model,"CastleFrontLeft",at+Vector3.new(-10,6,-13),Vector3.new(10,12,2),Color3.fromRGB(160,154,145))
 local frontR=block(model,"CastleFrontRight",at+Vector3.new(10,6,-13),Vector3.new(10,12,2),Color3.fromRGB(160,154,145))
 local door=block(model,"SiegeGate",at+Vector3.new(0,4,-13),Vector3.new(9,8,1.3),Color3.fromRGB(96,69,56))
 door.Transparency=.45;door.CanCollide=false -- open gate permits both human and bot approach
 for _,dx in ipairs({-26,26}) do
  for _,dz in ipairs({-26,26}) do
   block(model,"Tower",at+Vector3.new(dx,9,dz),Vector3.new(9,18,9),Color3.fromRGB(137,137,142))
  end
 end
 local banner=block(model,"OwnerFlag",at+Vector3.new(0,18,0),Vector3.new(6,9,.8),Color3.fromRGB(228,190,110))
 board(core,(entry.isAI and "AI " or "")..entry.id.." の城\n卵×3 / HP1000")
 local coreBoard=core:FindFirstChildOfClass("BillboardGui")
 if coreBoard then
  coreBoard.AlwaysOnTop=false
  coreBoard.MaxDistance=65
  coreBoard.Size=UDim2.fromOffset(160,48)
 end
 session.castleModels[entry.id]={model=model,core=core,banner=banner,door=door}
 local lastHumanSiegeAt:{[string]:number}={}
 prompt(door,"攻城攻撃","敵城を攻める",function(p)
  if joined[p.UserId]~=session.mode or sessions[session.mode]~=session
   or not session.rules or type(session.isCurrentHuman)~="function"
   or session.isCurrentHuman(p)~=true then return end
  local state=session.rules
  if state.phase~="ACTIVE" then return end
  local from=tostring(p.UserId)
  local src=state.castles[from]
  if not src or not src.alive then return end
  local now=os.clock()
  if not siegeAttackReady(lastHumanSiegeAt,from,now) then return end
  local ok,res=pcall(function() return session.castleSiegeAttack(entry.id,from,120,true) end)
  if not ok then return end
  lastHumanSiegeAt[from]=now -- commit only after a valid server-authoritative hit
  session.refresh()
  if res.fallen then session.releaseEggs(entry.id,at,res.releasedEggIds) end
 end)
 local deco=block(model,"DecorStation",at+Vector3.new(18,2,-18),Vector3.new(5,4,4),Color3.fromRGB(214,158,97))
 prompt(deco,"旗の装飾変更","自分の城",function(p)
  if not session.rules or tostring(p.UserId)~=entry.id
   or sessions[session.mode]~=session or type(session.isCurrentHuman)~="function"
   or session.isCurrentHuman(p)~=true then return end
  local current=session.rules.castles[entry.id].decoration
  local nextColor=if current=="STONE" then "GOLD" elseif current=="GOLD" then "CYAN" else "STONE"
  if pcall(function() Rules.decorate(session.rules,entry.id,tostring(p.UserId),nextColor) end) then
   banner.Color=if nextColor=="GOLD" then Color3.fromRGB(240,199,70) elseif nextColor=="CYAN" then Color3.fromRGB(73,210,230) else Color3.fromRGB(180,180,180)
  end
 end)
 local deposit=block(model,"OwnEggDeposit",at+Vector3.new(-16,2,-18),Vector3.new(5,3,4),Color3.fromRGB(229,213,125))
 prompt(deposit,"卵を納入","自分の城",function(p)
  -- GQ_DEPOSIT_CURRENT_MATCH_586: old-mode/retired-session deposit is forbidden.
  if tostring(p.UserId)~=entry.id or joined[p.UserId]~=session.mode
   or sessions[session.mode]~=session or not session.rules then return end
  local c=session.rules.castles[entry.id]
  if c.alive and c.heldEggs>0 then
   local ok=pcall(function() Rules.depositEggs(session.rules,entry.id,c.heldEggs) end)
   if ok then session.refresh() end
  end
 end)
 local vault=block(model,"EggVault",at+Vector3.new(0,3,6),Vector3.new(6,5,6),Color3.fromRGB(218,181,75))
 board(vault,"卵倉庫")
 local vaultBoard=vault:FindFirstChildOfClass("BillboardGui")
 if vaultBoard then
  vaultBoard.AlwaysOnTop=false
  vaultBoard.MaxDistance=40
  vaultBoard.Size=UDim2.fromOffset(115,36)
 end
 prompt(vault,"敵の卵を奪取","卵3個から1個ずつ",function(p)
  if not session.rules or joined[p.UserId]~=session.mode
   or sessions[session.mode]~=session or type(session.isCurrentHuman)~="function"
   or session.isCurrentHuman(p)~=true then return end
  pcall(function() Rules.takeEggs(session.rules,tostring(p.UserId),1,entry.id) end)
  session.refresh()
 end)
end

local function startSession(mode:string)
 local state=sessions[mode]
 if state then return end
 local queue=queues[mode];if #queue==0 then return end
 local humans={}
 for _,p in ipairs(queue) do
  if p.Parent and joined[p.UserId]==mode then table.insert(humans,tostring(p.UserId)) end
 end
 if #humans==0 then return end
 local roster=Rules.makeRoster(mode,humans,MODE_SEATS)
 local session={
  mode=mode,roster=roster,rules=Rules.new(mode,roster,24),
  castleLocations={},castleModels={},world=Instance.new("Folder"),groundY=root.Y-3,
   lifeConnections={},walkBaseline={},
  }
  session.neutralBudget=gqDualBudget
  session.neutralBudgetEpoch=gqDualBudget:begin(mode)
 session.world.Name=mode.."_Arena";session.world.Parent=folder
 local worldX=mode=="TEAM" and -620 or 620
 local floor=block(session.world,"TacticalBattlefield",root+Vector3.new(worldX,-4,465),Vector3.new(890,2,1050),Color3.fromRGB(96,126,83))
 floor.Material=Enum.Material.Grass
 -- Moveable routes between personal fortresses; demo geometry only, not a finished detailed terrain.
 for j=1,3 do
  -- Three west-east infiltration corridors: northern ridge, river ford and forest flank.
  local lane=block(session.world,"TacticalRoute_"..j,root+Vector3.new(worldX,-2.75,295+(j-1)*170),
   Vector3.new(835,.7,23),Color3.fromRGB(152,133,99))
  lane.Material=Enum.Material.Ground
 end
 if mode=="TEAM" then
  -- GQ ridge access: preserve the stone shoulders, expose the middle route and SHIELD.
  -- The 24-stud clear passage remains wide enough for humans and AI.
  local centerPassage=24
  local sideWidth=(54-centerPassage)/2
  for _,side in ipairs({-1,1}) do
   local ridgeOffset=side*(centerPassage/2+sideWidth/2)
   local ridge=block(session.world,if side==-1 then "CentralRidge" else "CentralRidgeRight",
    root+Vector3.new(-620+ridgeOffset,15,475),Vector3.new(sideWidth,34,190),Color3.fromRGB(105,103,93))
   ridge.Material=Enum.Material.Slate
  end
  local valley=block(session.world,"ValleyOverlook",root+Vector3.new(-610,5,695),
   Vector3.new(85,11,30),Color3.fromRGB(118,130,94))
  valley.Material=Enum.Material.Rock
  for n=1,7 do
   local x=-800+(n%4)*38
   local z=470+math.floor(n/4)*110+(if n==1 then 18 else 0)
   local tree=block(session.world,"ForestAmbushCover_"..n,root+Vector3.new(x,11,z),
    Vector3.new(7,24,7),Color3.fromRGB(66,104,65))
   tree.Material=Enum.Material.Grass
  end
 end
 sessions[mode]=session
 refreshQueueBoard(mode)
  -- GQ_V3_ITEM_MODE_OWNERSHIP_20261116: no second match/ITEM authority.
  session.canCollectWorldItem=function(actor:Player):boolean
   return actor.Parent~=nil
    and sessions[mode]==session
    and joined[actor.UserId]==mode
    and session.rules~=nil
    and session.rules.phase=="ACTIVE"
  end
  -- Authoritative host-only membership fence for BotActors hero hits.
  -- Never trust a stale castle ID or a client-side teleport as proof of participation.
  session.isCurrentHuman=function(player:Player):boolean
   return sessions[mode]==session and session.rules.phase=="ACTIVE"
    and joined[player.UserId]==mode and player.Parent==Players
    and session.rules.castles[tostring(player.UserId)]~=nil
    and session.rules.castles[tostring(player.UserId)].isAI~=true
  end
 -- Clean up only this finished match; queues and matches for the other mode survive.
 session.closeRound=function(abandoned:boolean?)
  if sessions[mode]~=session or (not abandoned and session.rules.phase~="FINISHED") then return end
   if abandoned then session.rules.phase="ABANDONED" end
  if session.guardians then session.guardians.shutdown() end
   -- Idempotent even if the horde folder was destroyed first.
   if session.neutralBudgetEpoch then
    gqDualBudget:retire(mode,session.neutralBudgetEpoch)
    session.neutralBudgetEpoch=nil
   end
  for _,connection in ipairs(session.lifeConnections) do connection:Disconnect() end
  for _,entry in ipairs(session.roster) do
   if not entry.isAI then
    local player=Players:GetPlayerByUserId(tonumber(entry.id) or -1)
    if player and joined[player.UserId]==mode then
     joined[player.UserId]=nil
     SevenRoleCombat.clear(player)
     InteractionGuard.clear(player) -- avoid prompt cooldown state leaking across rounds
     RoundReplay.resetHuman(player,root+Vector3.new(0,8,-5),session.walkBaseline[tostring(player.UserId)])
    end
   end
  end
  BuilderConstruction.clear(session)
  if session.castleDefenseStop then session.castleDefenseStop() end
   GQ802StageVisuals.clear(session.world)
  if session.world.Parent then session.world:Destroy() end
  sessions[mode]=nil
  queues[mode]={}
  queueStartedAt[mode]=nil
  queueEpoch[mode]+=1
  refreshQueueBoard(mode)
 end
 for _,entry in ipairs(roster) do
  if not entry.isAI then
   local p=Players:GetPlayerByUserId(tonumber(entry.id) or -1)
   if p then
    local module=chosenDefense[p.UserId] or "SENSOR"
    Rules.loadDefense(session.rules,entry.id,{module})
   end
  else Rules.loadDefense(session.rules,entry.id,{"SENSOR"}) end
 end
 session.releaseEggs=function(ownerId:string,at:Vector3,eggIds:{string})
  for i,eggId in ipairs(eggIds) do
   local egg=block(session.world,"ReleasedEgg_"..eggId,at+Vector3.new((i-2)*3,4,-17),Vector3.new(2,3,2),Color3.fromRGB(245,219,94))
   egg.Shape=Enum.PartType.Ball
   prompt(egg,"拾う","解放された卵",function(p)
    if joined[p.UserId]~=mode or egg.Parent==nil then return end
    if pcall(function() Rules.takeFieldEgg(session.rules,tostring(p.UserId),eggId) end) then egg:Destroy() end
   end)
  end
 end

 -- A defeated carrier drops physical eggs; never leave an invisible stock increase.
 -- The Rules module owns the count mutation and is idempotent after the first drop.
 session.dropCarrierEggs=function(ownerId:string,at:Vector3):number
  if session.rules.phase~="ACTIVE" then return 0 end
  local carrier=session.rules.castles[ownerId]
  if not carrier or not carrier.alive or carrier.heldEggs<=0 then return 0 end
  local dropped,dropIds=Rules.onCarrierEliminated(session.rules,ownerId)
  if dropped>0 then
   local home=session.castleLocations[ownerId]
   local safe=DropBounds.recover(mode,root.X,root.Z,at.X,at.Z,
    home and home.X or nil,home and home.Z or nil)
   local landing=Vector3.new(safe.x,session.groundY or at.Y,safe.z+17)
   session.releaseEggs(ownerId,landing,dropIds)
   session.refresh()
  end
  return dropped
 end
 session.refresh=function()
  if session.guardians then session.guardians.refresh() end
  for id,bits in pairs(session.castleModels) do
   local c=session.rules.castles[id]
   if c then
    bits.core.Color=if c.alive then Color3.fromRGB(172,166,147) else Color3.fromRGB(59,54,55)
    local gui=bits.core:FindFirstChildOfClass("BillboardGui")
    local t=gui and gui:FindFirstChildOfClass("TextLabel")
    if t then t.Text=(c.isAI and "AI " or "")..id.."\nHP"..math.floor(c.hp).." / 卵"..c.vaultEggs end
   end
  end
  for _,player in ipairs(queue) do
   if player.Parent and joined[player.UserId]==mode then
    local c=session.rules.castles[tostring(player.UserId)]
    if c and not c.alive and player:GetAttribute("EGGRUMBLE_Eliminated")~=true then
     player:SetAttribute("EGGRUMBLE_Eliminated",true)
     local ch=player.Character
     local rootPart=ch and ch:FindFirstChild("HumanoidRootPart")::BasePart?
     if rootPart then rootPart.CFrame=CFrame.new(root+Vector3.new(0,12,-35)) end
     SevenRoleCombat.clear(player)
    end
   end
  end
  if session.rules.winner~=nil then
   -- Short factual result shown exactly once, never a permanent play-blocking HUD.
   ResultService.showIfFinished(session,queue,mode)
   RoundReplay.schedule(session,session.closeRound)
   print("[EGGRUMBLE "..mode.."] Castle elimination winner:",session.rules.winner)
  end
 end
 session.castleSiegeAttack=SiegeBridge.attach(session,Rules)
 session.guardians=GuardianRuntime.attach(session,chosenRole)
 for idx,entry in ipairs(roster) do createWorldCastle(session,entry,idx) end
 -- Field eggs available in both modes, not single/multi mode toggles.
 local rowZ=if mode=="TEAM" then {338,506,610} else {338,448,676}
 for i=1,24 do
  local col=(i-1)%8;local row=math.floor((i-1)/8)
  local worldX=mode=="TEAM" and -620 or 620
  local at=root+Vector3.new(worldX+(col-3.5)*93,3,rowZ[row+1])
  local eggId="FIELD_"..i
  -- Two mirrored rare field eggs; game-owned FIELD_4/5 tokens unchanged.
  local rareFieldEgg=i==4 or i==5
  local eggTint=if rareFieldEgg then Color3.fromRGB(174,119,210) else Color3.fromRGB(238,214,108)
  local egg=block(session.world,"FieldEgg_"..i,at,Vector3.new(2.6,3.3,2.6),eggTint)
  egg.Shape=Enum.PartType.Ball
  if rareFieldEgg then egg.Material=Enum.Material.Glass end
  prompt(egg,"卵を拾う",(if rareFieldEgg then "レア卵｜60点" else "フィールドの卵"),function(p)
   if joined[p.UserId]~=mode or egg.Parent==nil then return end
   if pcall(function() Rules.takeFieldEgg(session.rules,tostring(p.UserId),eggId) end) then egg:Destroy() end
  end)
 end
  -- One trusted visual stage seed/manifest per real session, never a client Remote.
  -- Optional visual error keeps original castles, eggs and three routes playable.
  local visualOK,visualError=pcall(function()
   local stageMode=if mode=="BATTLE_ROYALE" then "BR" else "TEAM"
   local stageSeed=Random.new():NextInteger(1,2147483646)
   local stageManifest,reason=GQ802StageManifest.build(stageSeed,stageMode,#roster)
   if not stageManifest then error(reason or "INVALID_STAGE_SEED") end
   local stageRoot,renderError=GQ802StageVisuals.render(session.world,floor,
    stageManifest,GQ802StageManifest,GQ802StageBlueprint)
   if not stageRoot then error(renderError or "NO_STAGE_VISUAL") end
   session.GQ802StageSeed=stageSeed
   session.GQ802StageRoot=stageRoot
  end)
  if not visualOK then
   warn("[GQ802] Stage visuals OFF; legacy match kept:",visualError)
  end
 Rules.start(session.rules)
 -- GQ499 original-author 900s deadline; same Host, same Rules, no new Game.
 local deadlineId=mode..":"..tostring(session)
 local deadlineLease=Deadline.new(os.clock(),deadlineId)
 session.deadlineLease=deadlineLease
 task.spawn(function()
  while sessions[mode]==session and session.rules.phase=="ACTIVE" and session.world.Parent do
   local expired=Deadline.expire(session.rules,deadlineLease,os.clock(),deadlineId)
   if expired then
    session.refresh() -- existing result/round replay, no second scoreboard
    break
   end
   task.wait(.5)
  end
 end)
 -- Connect existing HEAL/DASH/SHIELD world pickups to *both* actual match modes,
 -- without spawning separate item preview worlds or inventing a second inventory.
 local itemsOK,itemCountOrError=pcall(function()
  return RaidItemIntake.start(session,root,FieldItems)
 end)
 if itemsOK then
  session.fieldItemCount=itemCountOrError
  session.itemIntakeStatus="READY"
 else
  session.fieldItemCount=0
  session.itemIntakeStatus="YELLOW_ITEM_OPTIONAL"
  warn("[EGGRUMBLE ITEM INTAKE] optional field-item failure; core egg/castle match continues:",itemCountOrError)
 end
 -- ORIGINAL author StoneGiant per real session; never cross-hit the other mode.
 -- Optional source fail = YELLOW; castle/eggs and neutral horde are still playable.
 local bossX=if mode=="TEAM" then -620 else 620
 local bossOK,bossOrError=pcall(function()
  return NeutralStoneGiant.spawn(session.world,
   root+Vector3.new(bossX+100,-3,590),{
    isMatchActive=function()
     return BossSessionFence.active(mode,session,sessions)
    end,
    canEngage=function(player:Player)
     return BossSessionFence.mayEngage(mode,session,sessions,joined,
      player.UserId,player:GetAttribute("EGGRUMBLE_Eliminated")==true)
    end,
    onDefeat=function(player:Player)
     -- Dedicated boss credit, NOT falsely counted as regular Humanoid.Died KO.
     session.bossDefeats=(session.bossDefeats or 0)+1
     local total=player:GetAttribute("EGGRUMBLE_BossDefeats") or 0
     player:SetAttribute("EGGRUMBLE_BossDefeats",total+1)
    end,
   })
 end)
 if bossOK then
  session.boss=bossOrError
  session.bossStatus="READY"
 else
  local orphan=session.world:FindFirstChild("NEUTRAL_BOSS_STONE_GIANT")
  if orphan then orphan:Destroy() end
  session.bossStatus="YELLOW_BOSS_OPTIONAL"
  warn("[EGGRUMBLE BOSS] optional boss source failed; core match continues:",bossOrError)
 end
 for _,p in ipairs(queue) do
  if p.Parent and joined[p.UserId]==mode then
   -- Persist only for this one server-owned session; never trust client attributes.
   session.walkBaseline[tostring(p.UserId)]=RoundReplay.captureWalkBaseline(p)
   local ch=p.Character;local rootPart=ch and ch:FindFirstChild("HumanoidRootPart")::BasePart?
   local idx=table.find(humans,tostring(p.UserId))
   if rootPart and idx then rootPart.CFrame=CFrame.new(getCastlePoint(mode,idx)+Vector3.new(0,7,-45)) end
  end
 end
 -- Drop carried eggs on every human death, including post-respawn deaths.
 -- CharacterAdded reconnects only for this one preview session; no new Remote/Game.
 for _,player in ipairs(queue) do
  if player.Parent and joined[player.UserId]==mode then
   local function bindCarrierLife(character:Model)
    local humanoid=character:FindFirstChildOfClass("Humanoid") or character:WaitForChild("Humanoid",5)
    if humanoid and humanoid:IsA("Humanoid") then
     table.insert(session.lifeConnections,humanoid.Died:Connect(function()
      -- Reject old Humanoid.Died after respawn; only the current avatar owns these eggs.
      if joined[player.UserId]~=mode or sessions[mode]~=session
       or player.Character~=character or session.rules.phase~="ACTIVE" then return end
      local rootPart=character:FindFirstChild("HumanoidRootPart")::BasePart?
      local fallback=session.castleLocations[tostring(player.UserId)] or root
      session.dropCarrierEggs(tostring(player.UserId),rootPart and rootPart.Position or fallback)
     end))
    end
   end
   table.insert(session.lifeConnections,player.CharacterAdded:Connect(bindCarrierLife))
   if player.Character then task.spawn(bindCarrierLife,player.Character) end
  end
 end
 -- Actual anchored 3D bot actors roam between castles and must reach their goal
 -- before stealing/depositing eggs or damaging the castle. No remote numerical sieges.
 BotActors.start(session,Rules)
 -- GQ500_ORIGINAL_LIVE_CASTLE_DEFENSE_INLINE_20261117
 -- Reuse original #500 Policy and Live; optional Studio-only, no parallel Game.
 local DEFENSE_V1_ENABLED=true
 if DEFENSE_V1_ENABLED then
  local defenseOK,defenseError=pcall(function() CastleDefense.start(session) end)
  if not defenseOK then
   if session.castleDefenseStop then session.castleDefenseStop() end
   warn("[EGGRUMBLE CASTLE DEFENSE] YELLOW_OPTIONAL source fail:",defenseError)
  end
 end
 CarrierWorldTell.start(session)
 SwarmCombat.start(session)
 -- All seven roles now use the SAME neutral, AI-duel, castle/egg V3 session.
 -- Select role in the lobby; default 武神 if the human enters a portal immediately.
 for _,p in ipairs(queue) do
  if p.Parent and joined[p.UserId]==mode then
   local role=chosenRole[p.UserId] or "WARRIOR"
   SevenRoleCombat.equip(session,p,role)
   InvulRuntime.attach(session,p,role)
   NaturalRegen.attach(session,p,role)
   if role=="BUILDER" then
    BuilderConstruction.equip(session,p,true,false) -- only WALL, BRIDGE remains OFF
   end
   table.insert(session.lifeConnections,p.CharacterAdded:Connect(function(character)
    task.delay(.8,function()
     if p.Parent and joined[p.UserId]==mode and p.Character==character
      and sessions[mode]==session and session.rules.phase=="ACTIVE" then
      local id=tostring(p.UserId)
      local castle=session.rules.castles[id]
      local home=session.castleLocations[id]
      if castle and castle.alive and home then
       -- Wait for a physical live Avatar before entering the same castle match.
       -- The helper rejects stale characters, dead Humanoids and destroyed castles.
       local rootPart=character:FindFirstChild("HumanoidRootPart")
        or character:WaitForChild("HumanoidRootPart",5)
       if rootPart and RoundReplay.returnToActiveCastle(session,p,character,home+Vector3.new(0,7,-45)) then
        -- Reset only the previous avatar's stealth, after valid physical return.
        p:SetAttribute("EGGRUMBLE_StealthUntil",nil)
        SevenRoleCombat.equip(session,p,role)
        InvulRuntime.attach(session,p,role)
        NaturalRegen.attach(session,p,role)
   if role=="BUILDER" then
    BuilderConstruction.equip(session,p,true,false) -- only WALL, BRIDGE remains OFF
   end
       end
      end
     end
    end)
   end))
  end
 end

end

local function joinQueue(mode:string,p:Player)
 if sessions[mode] then return end
 -- GQ8_ROLE_SELECTION_ACK_BEGIN: require an explicit role-stand action.
 -- No new READY owner, queue timer, Remote or UI layer.
 if chosenRole[p.UserId]==nil then
  p:SetAttribute("EGGRUMBLE_RoleSelectionRequired",true)
  return
 end
 p:SetAttribute("EGGRUMBLE_RoleSelectionRequired",nil)
 -- GQ8_ROLE_SELECTION_ACK_END
 local previous=joined[p.UserId]
 if previous then
  -- Joining the same gate cancels; choosing the other switches mode while waiting.
  -- Never remove a player from a live match.
  if sessions[previous] then return end
  if not RoundReplay.leaveWaitingQueue(previous,p,queues,joined,queueEpoch,sessions) then return end
  if #queues[previous]==0 then queueStartedAt[previous]=nil end
  refreshQueueBoard(previous)
  p:SetAttribute("EGGRUMBLE_QueuedMode",nil)
  if previous==mode then return end
 end
 joined[p.UserId]=mode
 table.insert(queues[mode],p)
 p:SetAttribute("EGGRUMBLE_QueuedMode",mode)
 if #queues[mode]==1 then
  queueStartedAt[mode]=time()
  local expectedEpoch=queueEpoch[mode]
  -- Visual ticker observes the author-owned queue epoch; it cannot start a match.
  task.spawn(function()
   for _=1,COUNTDOWN do
    if queueEpoch[mode]~=expectedEpoch or sessions[mode] or #queues[mode]==0 then return end
    refreshQueueBoard(mode)
    task.wait(1)
   end
  end)
  task.delay(COUNTDOWN,function()
   if RoundReplay.canStartCountdown(mode,expectedEpoch,queues,queueEpoch,sessions) then
    startSession(mode)
   end
  end)
 end
 refreshQueueBoard(mode)
 if #queues[mode]>=MODE_SEATS then
  startSession(mode)
  refreshQueueBoard(mode)
 end
end
-- Seven job-selection stands: small world prompts, no permanent large HUD.
for i,role in ipairs(SevenRoleCombat.roleOrder()) do
 local data=SevenRoleCombat.info(role)
 local stand=block(folder,"ROLE_"..role,root+Vector3.new((i-4)*9,1,69),Vector3.new(5,4,5),data.color)
 nearbyBoard(stand,data.name.."\n"..data.weapon,24)
 prompt(stand,"職業選択",data.name,function(p)
  if joined[p.UserId] and sessions[joined[p.UserId]] then return end
  chosenRole[p.UserId]=role
  p:SetAttribute("EGGRUMBLE_RoleSelectionRequired",nil)
  p:SetAttribute("EGGRUMBLE_SelectedRole",role)
 end)
end
local gateTeam=block(folder,"TEAM_PORTAL",root+Vector3.new(-12,6,28),Vector3.new(9,12,2),Color3.fromRGB(206,74,67))
local gateBR=block(folder,"BATTLE_ROYALE_PORTAL",root+Vector3.new(12,6,28),Vector3.new(9,12,2),Color3.fromRGB(79,132,230))
nearbyBoard(gateTeam,"EGGRUMBLE\nチーム戦｜全味方城陥落で敗北",44)
nearbyBoard(gateBR,"EGGRUMBLE\nバトルロワイヤル｜最後の城が勝者",44)
-- Link exactly the original labels (#539 controls their distance/occlusion).
for mode,gate in pairs({TEAM=gateTeam,BATTLE_ROYALE=gateBR}) do
 local bb=gate:FindFirstChildOfClass("BillboardGui")
 local txt=bb and bb:FindFirstChildOfClass("TextLabel")
 if txt and txt:IsA("TextLabel") then queueBoards[mode]=txt end
 refreshQueueBoard(mode)
end
prompt(gateTeam,"参加する","職業選択後｜チーム戦（再操作で解除）",function(p) joinQueue("TEAM",p) end)
prompt(gateBR,"参加する","職業選択後｜BR戦（再操作で解除）",function(p) joinQueue("BATTLE_ROYALE",p) end)
for i,name in ipairs({"HARDENED","REPAIR","TURRET","TRAP","SENSOR"}) do
 local stand=block(folder,"DEFENSE_"..name,root+Vector3.new((i-3)*9,1,47),Vector3.new(5,3,5),Color3.fromRGB(149,164,121))
 nearbyBoard(stand,name.."\n出撃前の防衛選択",25)
 prompt(stand,"装備する","全員同一防衛予算",function(p)
  if joined[p.UserId]==nil or sessions[joined[p.UserId]]==nil then
   chosenDefense[p.UserId]=name
   p:SetAttribute("EGGRUMBLE_DefenseLoadout",name)
  end
 end)
end
Players.PlayerRemoving:Connect(function(p)
 InteractionGuard.clear(p)
 local mode=joined[p.UserId]
 if mode and not sessions[mode] then
  -- Cancel countdown if the last queued human disconnects; the next entrant
  -- must receive a fresh full COUNTDOWN rather than inherit the stale timer.
  RoundReplay.leaveWaitingQueue(mode,p,queues,joined,queueEpoch,sessions)
  if #queues[mode]==0 then queueStartedAt[mode]=nil end
  refreshQueueBoard(mode)
 end
 joined[p.UserId]=nil
 chosenDefense[p.UserId]=nil
 chosenRole[p.UserId]=nil
 SevenRoleCombat.clear(p)
 if mode and sessions[mode] and sessions[mode].rules.phase=="ACTIVE" then
  local scene=sessions[mode]
  local ch=p.Character
  local rootPart=ch and ch:FindFirstChild("HumanoidRootPart")::BasePart?
  scene.dropCarrierEggs(tostring(p.UserId),rootPart and rootPart.Position or scene.castleLocations[tostring(p.UserId)] or root)
  -- If no human remains, retire the bot-only arena immediately instead of
  -- trapping the next player behind an occupied session forever.
  local abandoned=RoundReplay.abandonIfEmpty(scene,joined,function()
   scene.closeRound(true)
  end)
  -- Preserve an existing match by transferring a disconnected castle to AI.
  if not abandoned and scene.takeover then scene.takeover(tostring(p.UserId)) end
 end
end)
print("[EGGRUMBLE V3] Studio-only two mode gates; moving AI actors, shared horde and castle multi-egg combat; real platform matchmaking/production AI UNIMPLEMENTED")

do -- GQ506_RESPAWN_GRACE_SINGLE_HOST_20261117: immutable original R13 ServerScript in single existing Host
-- Optional EGGRUMBLE V3, private-Studio-only respawn fairness.
-- One isolated ServerScript. It does NOT touch original combat/egg/lobby modules.
-- The original 21-source #482 server remains the ONLY game/session authority.
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ProximityPromptService = game:GetService("ProximityPromptService")
local Workspace = game:GetService("Workspace")
if not RunService:IsStudio() then return end

local WORLD_NAME = "EGGRUMBLE_LOBBY_CASTLE_MODES_PREVIEW"
local GRACE_SECONDS = 2.25
local RESPAWN_TICKET_SECONDS = 12
local SPAWN_BIND_DELAY = 0.95
local MAX_HOME_DISTANCE = 85
local FALLEN_CORE_COLOR = Color3.fromRGB(59, 54, 55)
type ShieldState = {
    character: Model,
    shield: ForceField,
    connections: {RBXScriptConnection},
}
local live: {[Player]: ShieldState} = {}
type RespawnTicket = { arena: Instance, mode: string, expiresAt: number }
local tickets: {[Player]: RespawnTicket} = {}

local function clear(player: Player)
    local state = live[player]
    if not state then return end
    live[player] = nil
    for _, connection in ipairs(state.connections) do
        connection:Disconnect()
    end
    if state.shield.Parent then state.shield:Destroy() end
end

-- This pure game-session guard deliberately allows a DYING avatar: the Died
-- event fires after Humanoid.Health reaches 0. Never infer death from spawn alone.
local function currentArena(player: Player, character: Model): Instance?
    if player.Parent ~= Players or player.Character ~= character then return nil end
    if player:GetAttribute("EGGRUMBLE_Eliminated") == true then return nil end
    local mode = player:GetAttribute("EGGRUMBLE_QueuedMode")
    if mode ~= "TEAM" and mode ~= "BATTLE_ROYALE" then return nil end
    local scenes = Workspace:FindFirstChild(WORLD_NAME)
    local arena = scenes and scenes:FindFirstChild(mode .. "_Arena")
    if not arena then return nil end
    local castle = arena:FindFirstChild("Castle_" .. tostring(player.UserId))
    if not castle or not castle:IsA("Model") then return nil end
    local core = castle:FindFirstChild("StandardCore")
    if not core or not core:IsA("BasePart") or core.Color == FALLEN_CORE_COLOR then return nil end
    return arena
end

local function originArena(player: Player, character: Model): Instance?
    local arena = currentArena(player, character)
    if not arena then return nil end
    local castle = arena:FindFirstChild("Castle_" .. tostring(player.UserId))
    local core = castle and castle:FindFirstChild("StandardCore")
    local human = character:FindFirstChildOfClass("Humanoid")
    local root = character:FindFirstChild("HumanoidRootPart")
    if not core or not human or human.Health <= 0 or not root or not root:IsA("BasePart") then
        return nil
    end
    -- Require the original #482 returnToActiveCastle location; never grant
    -- protection in a lobby, on an enemy route or in a stale round.
    if (root.Position - core.Position).Magnitude > MAX_HOME_DISTANCE then return nil end
    return arena
end

local function install(player: Player, character: Model)
    clear(player)
    local arena = originArena(player, character)
    if not arena then return end
    if character:FindFirstChildOfClass("ForceField") then
        -- Respect Roblox/other author-owned ForceFields, never steal or extend them.
        return
    end
    local shield = Instance.new("ForceField")
    shield.Name = "EGGRUMBLE_GQ_RespawnGrace"
    shield.Visible = false -- no extra glow in #485's high-quality field art
    shield.Parent = character
    local state: ShieldState = {character = character, shield = shield, connections = {}}
    live[player] = state
    local function revoke()
        if live[player] == state then clear(player) end
    end
    -- Equipping any combat tool ends protection BEFORE the next attack;
    -- do not allow protected aggressive duels or carrying eggs into a siege.
    table.insert(state.connections, character.ChildAdded:Connect(function(instance: Instance)
        if instance:IsA("Tool") then revoke() end
    end))
    for _, instance in ipairs(character:GetChildren()) do
        if instance:IsA("Tool") then
            revoke()
            return
        end
    end
    local humanoid = character:FindFirstChildOfClass("Humanoid")
    if humanoid then
        table.insert(state.connections, humanoid.Died:Connect(revoke))
    end
    table.insert(state.connections, player:GetAttributeChangedSignal("EGGRUMBLE_Eliminated"):Connect(function()
        if player:GetAttribute("EGGRUMBLE_Eliminated") == true then revoke() end
    end))
    table.insert(state.connections, player:GetAttributeChangedSignal("EGGRUMBLE_QueuedMode"):Connect(function()
        if originArena(player, character) ~= arena then revoke() end
    end))
    task.delay(GRACE_SECONDS, revoke)
    task.spawn(function()
        -- Bounded 0.1s checks; no persistent loop across a round or another life.
        local deadline = os.clock() + GRACE_SECONDS
        while live[player] == state and os.clock() < deadline do
            task.wait(0.1)
            if live[player] ~= state then return end
            if originArena(player, character) ~= arena then
                revoke()
                return
            end
        end
        revoke()
    end)
end

local function watch(player: Player)
    local function bindCharacter(character: Model)
        clear(player)
        -- Only an actual server-observed Humanoid.Died in a live, same-mode
        -- personal-castle session can authorize the NEXT character.
        local function bindDeath(humanoid: Humanoid?)
            if not humanoid or not humanoid:IsA("Humanoid") then return end
            humanoid.Died:Connect(function()
                clear(player)
                local arena = currentArena(player, character)
                local mode = player:GetAttribute("EGGRUMBLE_QueuedMode")
                if arena and (mode == "TEAM" or mode == "BATTLE_ROYALE") then
                    tickets[player] = {
                        arena = arena,
                        mode = mode,
                        expiresAt = os.clock() + RESPAWN_TICKET_SECONDS,
                    }
                else
                    tickets[player] = nil
                end
            end)
        end
        local immediate = character:FindFirstChildOfClass("Humanoid")
        if immediate then
            bindDeath(immediate :: Humanoid)
        else
            task.spawn(function()
                bindDeath(character:WaitForChild("Humanoid", 5) :: Humanoid?)
            end)
        end
        task.delay(SPAWN_BIND_DELAY, function()
            if player.Character ~= character then return end
            local ticket = tickets[player]
            -- Single-use: a delayed callback cannot grant the same death twice.
            tickets[player] = nil
            if not ticket or os.clock() > ticket.expiresAt then return end
            if player:GetAttribute("EGGRUMBLE_QueuedMode") ~= ticket.mode then return end
            if currentArena(player, character) ~= ticket.arena then return end
            install(player, character)
        end)
    end
    player.CharacterAdded:Connect(bindCharacter)
    -- Script may attach to a player whose initial character already exists.
    if player.Character then bindCharacter(player.Character) end
    player.CharacterRemoving:Connect(function()
        -- An actual death ticket must survive removal of its old avatar.
        clear(player)
    end)
    player:GetAttributeChangedSignal("EGGRUMBLE_QueuedMode"):Connect(function()
        local ticket = tickets[player]
        if ticket and player:GetAttribute("EGGRUMBLE_QueuedMode") ~= ticket.mode then
            tickets[player] = nil
        end
    end)
end

ProximityPromptService.PromptTriggered:Connect(function(_prompt: ProximityPrompt, player: Player)
    -- Egg theft, items, castle siege, ability stands: first world interaction
    -- ends the respawn defense without modifying any original prompt callback.
    clear(player)
end)
Players.PlayerRemoving:Connect(function(player: Player)
    tickets[player] = nil
    clear(player)
end)
for _, player in ipairs(Players:GetPlayers()) do
    watch(player)
end
Players.PlayerAdded:Connect(watch)
print("[EGGRUMBLE_GQ_RESPAWN] optional short anti-camp grace: no server rule override")

end
